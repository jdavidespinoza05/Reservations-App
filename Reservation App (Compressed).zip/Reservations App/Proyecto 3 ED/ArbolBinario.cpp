#include "pch.h"
#include "ArbolBinario.h"

ArbolBinario::ArbolBinario() {
    raiz = nullptr;
    ultimoNodoInsertado = nullptr; 
}

NodoBinario^ ArbolBinario::insertarCliente(NodoBinario^ nodo, String^ codPais, int llave, String^ nombre) {
    if (nodo == nullptr) {
        ultimoNodoInsertado = gcnew NodoBinario(llave, nombre, codPais); // Guarda el �ltimo nodo insertado
        return ultimoNodoInsertado; // Retorna el nuevo nodo
    }

    if (llave < nodo->llave) {
        nodo->izquierdo = insertarCliente(nodo->izquierdo, codPais, llave, nombre); 
    }
    else if (llave > nodo->llave) {
        nodo->derecho = insertarCliente(nodo->derecho, codPais, llave, nombre); 
    }
    else {
        return nodo; // Llave duplicada, no se inserta
    }

    return nodo; // Retorna el nodo sin cambios
}

NodoBinario^ ArbolBinario::insertarP(NodoBinario^ nodo, int llave, String^ nombre) {
    if (nodo == nullptr) {
        ultimoNodoInsertado = gcnew NodoBinario(llave, nombre); // Guarda el �ltimo nodo insertado
        return ultimoNodoInsertado; // Retorna el nuevo nodo
    }

    if (llave < nodo->llave) {
        nodo->izquierdo = insertarP(nodo->izquierdo, llave, nombre);
    }
    else if (llave > nodo->llave) {
        nodo->derecho = insertarP(nodo->derecho, llave, nombre);
    }
    else {
        return nodo; // Llave duplicada, no se inserta
    }

    return nodo; // Retorna el nodo sin cambios
}

NodoBinario^ ArbolBinario::insertarHotel(NodoBinario^ nodo, String^ codPais, int llave, String^ nombre, String^ cant) {
    if (nodo == nullptr) {
        ultimoNodoInsertado = gcnew NodoBinario(llave, nombre, codPais, cant); // Guarda el �ltimo nodo insertado
        return ultimoNodoInsertado; // Retorna el nuevo nodo
    }

    if (llave < nodo->llave) {
        nodo->izquierdo = insertarHotel(nodo->izquierdo, codPais, llave, nombre, cant);
    }
    else if (llave > nodo->llave) {
        nodo->derecho = insertarHotel(nodo->derecho, codPais, llave, nombre, cant);
    }
    else {
        return nodo; // Llave duplicada, no se inserta
    }

    return nodo; // Retorna el nodo sin cambios
}


NodoBinario^ ArbolBinario::insertarPiso(NodoBinario^ nodo, String^ codPais, String^ codHotel, int llave, String^ nombre, String^ cant) {
    if (nodo == nullptr) {
        ultimoNodoInsertado = gcnew NodoBinario(llave, nombre, codPais, codHotel, cant); // Guarda el �ltimo nodo insertado
        return ultimoNodoInsertado; // Retorna el nuevo nodo
    }

    if (llave < nodo->llave) {
        nodo->izquierdo = insertarPiso(nodo->izquierdo, codPais, codHotel, llave, nombre, cant);
    }
    else if (llave > nodo->llave) {
        nodo->derecho = insertarPiso(nodo->derecho, codPais, codHotel, llave, nombre, cant);
    }
    else {
        return nodo; // Llave duplicada, no se inserta
    }

    return nodo; // Retorna el nodo sin cambios
}


NodoBinario^ ArbolBinario::insertarHab(NodoBinario^ nodo, String^ codPais, String^ codHotel, String^ codPiso, int llave, String^ tipo, String^ num, String^ precio, String^ estado) {
    if (nodo == nullptr) {
        ultimoNodoInsertado = gcnew NodoBinario(llave, codPais, codHotel, codPiso, tipo, num, precio, estado); // Guarda el �ltimo nodo insertado
        return ultimoNodoInsertado; // Retorna el nuevo nodo
    }

    if (llave < nodo->llave) {
        nodo->izquierdo = insertarHab(nodo->izquierdo, codPais, codHotel, codPiso, llave, tipo, num, precio, estado);
    }
    else if (llave > nodo->llave) {
        nodo->derecho = insertarHab(nodo->derecho, codPais, codHotel, codPiso, llave, tipo, num, precio, estado);
    }
    else {
        return nodo; // Llave duplicada, no se inserta
    }

    return nodo; // Retorna el nodo sin cambios
}

NodoBinario^ ArbolBinario::insertarCarro(NodoBinario^ nodo, String^ codPais, String^ codHotel, String^ codPiso, int llave, String^ tipo, String^ num, String^ a�o, String^ precio, String^ estado) {
    if (nodo == nullptr) {
        ultimoNodoInsertado = gcnew NodoBinario(llave, codPais, codHotel, codPiso, tipo, num, precio, estado, a�o); // Guarda el �ltimo nodo insertado
        return ultimoNodoInsertado; // Retorna el nuevo nodo
    }

    if (llave < nodo->llave) {
        nodo->izquierdo = insertarCarro(nodo->izquierdo, codPais, codHotel, codPiso, llave, tipo, num, a�o, precio, estado);
    }
    else if (llave > nodo->llave) {
        nodo->derecho = insertarCarro(nodo->derecho, codPais, codHotel, codPiso, llave, tipo, num, a�o, precio, estado);
    }
    else {
        return nodo; // Llave duplicada, no se inserta
    }

    return nodo; // Retorna el nodo sin cambios
}

NodoBinario^ ArbolBinario::buscar(NodoBinario^ nodo, int llave) {
    if (nodo == nullptr || nodo->llave == llave) {
        return nodo;
    }
    if (llave < nodo->llave) {
        return buscar(nodo->izquierdo, llave);
    }
    return buscar(nodo->derecho, llave);
}

NodoBinario^ ArbolBinario::eliminarP(NodoBinario^ nodo, int llave) {
    if (nodo == nullptr) return nullptr;

    if (llave < nodo->llave) {
        nodo->izquierdo = eliminarP(nodo->izquierdo, llave);
    }
    else if (llave > nodo->llave) {
        nodo->derecho = eliminarP(nodo->derecho, llave);
    }
    else {
        // Nodo encontrado
        if (nodo->izquierdo == nullptr) {
            return nodo->derecho;
        }
        else if (nodo->derecho == nullptr) {
            return nodo->izquierdo;
        }
        // Nodo con dos hijos
        NodoBinario^ temp = encontrarMinimo(nodo->derecho);
        nodo->llave = temp->llave;
        nodo->nombre = temp->nombre;
        nodo->derecho = eliminarP(nodo->derecho, temp->llave);
    }
    return nodo;
}

NodoBinario^ ArbolBinario::eliminarHotel(NodoBinario^ nodo, String^ codPais, int llave) {
    if (nodo == nullptr) return nullptr;

    if (llave < nodo->llave) {
        nodo->izquierdo = eliminarHotel(nodo->izquierdo, codPais, llave);
    }
    else if (llave > nodo->llave) {
        nodo->derecho = eliminarHotel(nodo->derecho, codPais, llave);
    }
    else {
        // Nodo encontrado
        if (nodo->izquierdo == nullptr) {
            return nodo->derecho;
        }
        else if (nodo->derecho == nullptr) {
            return nodo->izquierdo;
        }
        // Nodo con dos hijos
        NodoBinario^ temp = encontrarMinimo(nodo->derecho);
        nodo->llave = temp->llave;
        nodo->nombre = temp->nombre;
        nodo->derecho = eliminarHotel(nodo->derecho, codPais, temp->llave);
    }
    return nodo;
}

NodoBinario^ ArbolBinario::eliminarHotelPais(NodoBinario^ nodo, String^ codPais) {
    if (nodo == nullptr) return nullptr;

    // Recorre el �rbol de manera recursiva para eliminar hoteles que coincidan con el c�digo de pa�s
    nodo->izquierdo = eliminarHotelPais(nodo->izquierdo, codPais);
    nodo->derecho = eliminarHotelPais(nodo->derecho, codPais);

    // Verifica si el nodo actual coincide con el pa�s especificado
    if (nodo->codPais == codPais) {
        // Llamar a eliminarPisosYHabitacionesPorCodigo para cada piso encontrado bajo el hotel especificado
        //NodoBinario^ pisoNodo = nodo;  // Nodo correspondiente al primer piso del hotel
        //while (pisoNodo != nullptr) {
        eliminarPisoHotel(nodo, codPais, nodo->codHotel);
        eliminarHabPiso(nodo, codPais, nodo->codHotel, nodo->codPiso);
            //pisoNodo = pisoNodo->derecho;  // Avanzar a otros pisos en caso de estructura de m�ltiples pisos en el hotel
        //}

        // Despu�s de eliminar los pisos y habitaciones, eliminamos el nodo del hotel en s�
        // Caso 1: Nodo sin hijos
        if (nodo->izquierdo == nullptr && nodo->derecho == nullptr) {
            return nullptr;
        }
        // Caso 2: Nodo con un solo hijo
        else if (nodo->izquierdo == nullptr) {
            return nodo->derecho;
        }
        else if (nodo->derecho == nullptr) {
            return nodo->izquierdo;
        }
        // Caso 3: Nodo con dos hijos
        else {
            NodoBinario^ temp = encontrarMinimo(nodo->derecho);
            nodo->llave = temp->llave;
            nodo->codPais = temp->codPais;
            nodo->codHotel = temp->codHotel;
            nodo->codPiso = temp->codPiso;
            nodo->nombre = temp->nombre;
            nodo->derecho = eliminarHotelPais(nodo->derecho, temp->codPais);
        }
    }

    return nodo;
}


NodoBinario^ ArbolBinario::eliminarPiso(NodoBinario^ nodo, String^ codPais, String^ codHotel, int llave) {
    if (nodo == nullptr) return nullptr;

    if (llave < nodo->llave) {
        nodo->izquierdo = eliminarPiso(nodo->izquierdo, codPais, codHotel, llave);
    }
    else if (llave > nodo->llave) {
        nodo->derecho = eliminarPiso(nodo->derecho, codPais, codHotel, llave);
    }
    else {
        // Nodo encontrado
        if (nodo->izquierdo == nullptr) {
            return nodo->derecho;
        }
        else if (nodo->derecho == nullptr) {
            return nodo->izquierdo;
        }
        // Nodo con dos hijos
        NodoBinario^ temp = encontrarMinimo(nodo->derecho);
        nodo->llave = temp->llave;
        nodo->nombre = temp->nombre;
        nodo->derecho = eliminarPiso(nodo->derecho, codPais, codHotel, temp->llave);
    }
    return nodo;
}

NodoBinario^ ArbolBinario::eliminarPisoHotel(NodoBinario^ nodo, String^ codPais, String^ codHotel) {
    if (nodo == nullptr) return nullptr;

    // Recorre el �rbol de manera recursiva para eliminar nodos que coincidan con los c�digos de pa�s y hotel
    nodo->izquierdo = eliminarPisoHotel(nodo->izquierdo, codPais, codHotel);
    nodo->derecho = eliminarPisoHotel(nodo->derecho, codPais, codHotel);

    // Verifica si el nodo actual coincide con el pa�s y hotel especificados
    if (nodo->codPais == codPais && nodo->codHotel == codHotel) {
        // Llamar a eliminarHabitacionesPorCodigo para cada piso encontrado bajo el hotel especificado
        eliminarHabPiso(nodo, codPais, codHotel, nodo->codPiso);
        // Despu�s de eliminar habitaciones, elimina el nodo del piso (hotel)
        // Caso 1: Nodo sin hijos
        if (nodo->izquierdo == nullptr && nodo->derecho == nullptr) {
            return nullptr;
        }
        // Caso 2: Nodo con un solo hijo
        else if (nodo->izquierdo == nullptr) {
            return nodo->derecho;
        }
        else if (nodo->derecho == nullptr) {
            return nodo->izquierdo;
        }
        // Caso 3: Nodo con dos hijos
        else {
            NodoBinario^ temp = encontrarMinimo(nodo->derecho);
            nodo->llave = temp->llave;
            nodo->codPais = temp->codPais;
            nodo->codHotel = temp->codHotel;
            nodo->codPiso = temp->codPiso;
            nodo->nombre = temp->nombre;
            nodo->derecho = eliminarPisoHotel(nodo->derecho, temp->codPais, temp->codHotel);
        }
    }

    return nodo;
}

NodoBinario^ ArbolBinario::eliminarHab(NodoBinario^ nodo, String^ codPais, String^ codHotel, String^ codPiso, int llave) {
    if (nodo == nullptr) return nullptr;

    if (llave < nodo->llave) {
        nodo->izquierdo = eliminarHab(nodo->izquierdo, codPais, codHotel, codPiso, llave);
    }
    else if (llave > nodo->llave) {
        nodo->derecho = eliminarHab(nodo->derecho, codPais, codHotel, codPiso, llave);
    }
    else {
        // Nodo encontrado
        if (nodo->izquierdo == nullptr) {
            return nodo->derecho;
        }
        else if (nodo->derecho == nullptr) {
            return nodo->izquierdo;
        }
        // Nodo con dos hijos
        NodoBinario^ temp = encontrarMinimo(nodo->derecho);
        nodo->llave = temp->llave;
        nodo->nombre = temp->nombre;
        nodo->derecho = eliminarHab(nodo->derecho, codPais, codHotel, codPiso, temp->llave);
    }
    return nodo;
}

NodoBinario^ ArbolBinario::eliminarHabPiso(NodoBinario^ nodo, String^ codPais, String^ codHotel, String^ codPiso) {
    if (nodo == nullptr) return nullptr;

    // Recorre el �rbol en preorden y aplica la eliminaci�n de nodos que coincidan con los c�digos
    nodo->izquierdo = eliminarHabPiso(nodo->izquierdo, codPais, codHotel, codPiso);
    nodo->derecho = eliminarHabPiso(nodo->derecho, codPais, codHotel, codPiso);

    // Verificar si el nodo actual coincide con los c�digos
    if (nodo->codPais == codPais && nodo->codHotel == codHotel && nodo->codPiso == codPiso) {
        // Caso 1: Nodo sin hijos
        if (nodo->izquierdo == nullptr && nodo->derecho == nullptr) {
            return nullptr;
        }
        // Caso 2: Nodo con un solo hijo
        else if (nodo->izquierdo == nullptr) {
            return nodo->derecho;
        }
        else if (nodo->derecho == nullptr) {
            return nodo->izquierdo;
        }
        // Caso 3: Nodo con dos hijos
        else {
            NodoBinario^ temp = encontrarMinimo(nodo->derecho);
            nodo->llave = temp->llave;
            nodo->codPais = temp->codPais;
            nodo->codHotel = temp->codHotel;
            nodo->codPiso = temp->codPiso;
            nodo->nombre = temp->nombre;
            nodo->derecho = eliminarHab(nodo->derecho, temp->codPais, temp->codHotel, temp->codPiso, temp->llave);
        }
    }

    return nodo;
}


NodoBinario^ ArbolBinario::encontrarMinimo(NodoBinario^ nodo) {
    while (nodo->izquierdo != nullptr) {
        nodo = nodo->izquierdo;
    }
    return nodo;
}

void ArbolBinario::modificarP(int llave, String^ nom) {
    String^ nuevo = nom;
    NodoBinario^ nodo = buscar(llave);
    nodo->nombre = nuevo;
}


void ArbolBinario::modificarHotel(int llave, String^ nom, String^ cant) {
    String^ nuevoN = nom;
    String^ nuevoC = cant;
    NodoBinario^ nodo = buscar(llave);
    nodo->nombre = nuevoN;              //cambio nomrbe
    nodo->cantidad = nuevoC;            //cambio cantidad de estrellas
}

void ArbolBinario::modificarPiso(int llave, String^ nom, String^ cant) {
    String^ nuevoN = nom;
    String^ nuevoC = cant;
    NodoBinario^ nodo = buscar(llave);
    nodo->nombre = nuevoN;              //cambio nombre
    nodo->cantidad = nuevoC;            //cambio cantidad habitaciones
}

void ArbolBinario::modificarHab(int llave, String^ tipoCuarto, String^ numCamas, String^ precioHab, String^ estadoHab) {
    String^ nuevoT = tipoCuarto;
    String^ nuevoNC = numCamas;
    String^ nuevoP = precioHab;
    String^ nuevoE = estadoHab;
    NodoBinario^ nodo = buscar(llave);
    nodo->tipo = nuevoT;
    nodo->num = nuevoNC;
    nodo->precio=nuevoP;
    nodo->estado=nuevoE;
}

void ArbolBinario::modificarCarro(int llave, String^ tipoCuarto, String^ numCamas, String^ anho, String^ precioHab, String^ estadoHab) {
    String^ nuevoT = tipoCuarto;
    String^ nuevoNC = numCamas;
    String^ nuevoA = anho;
    String^ nuevoP = precioHab;
    String^ nuevoE = estadoHab;
    NodoBinario^ nodo = buscar(llave);
    nodo->tipo = nuevoT;
    nodo->num = nuevoNC;
    nodo->anho = nuevoA;
    nodo->precio = nuevoP;
    nodo->estado = nuevoE;
}

//---------------------------------------------------------------------------------------------------------------------------------

void ArbolBinario::insertarCliente(String^ codPais, String^ llaveStr, String^ valor) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        raiz = insertarCliente(raiz, codPais, llave, valor);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

void ArbolBinario::insertarP(String^ llaveStr, String^ valor) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        raiz = insertarP(raiz, llave, valor);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

void ArbolBinario::insertarHotel(String^ codPais, String^ llaveStr, String^ valor, String^ cant) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        raiz = insertarHotel(raiz, codPais, llave, valor, cant); 
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

void ArbolBinario::insertarPiso(String^ codPais, String^ codHotel, String^ llaveStr, String^ valor, String^ cant) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        raiz = insertarPiso(raiz, codPais, codHotel, llave, valor, cant);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

void ArbolBinario::insertarHab(String^ codPais, String^ codHotel, String^ codPiso, String^ llaveStr, String^ tipo, String^ num, String^ precio, String^ estado) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        raiz = insertarHab(raiz, codPais, codHotel, codPiso, llave, tipo, num, precio, estado);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

void ArbolBinario::insertarCarro(String^ codPais, String^ codHotel, String^ codPiso, String^ llaveStr, String^ tipo, String^ num, String^ a�o, String^ precio, String^ estado) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        raiz = insertarCarro(raiz, codPais, codHotel, codPiso, llave, tipo, num, a�o, precio, estado);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

NodoBinario^ ArbolBinario::buscar(int llave) {
    return buscar(raiz, llave);
}

void ArbolBinario::eliminarP(String^ llaveStr) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        raiz = eliminarP(raiz, llave);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

void ArbolBinario::eliminarHotel(String^ codPais, String^ llaveStr) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        raiz = eliminarHotel(raiz, codPais, llave);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

void ArbolBinario::eliminarPiso(String^ codPais, String^ codHotel, String^ llaveStr) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        raiz = eliminarPiso(raiz, codPais, codHotel, llave);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

void ArbolBinario::eliminarHab(String^ codPais, String^ codHotel, String^ codPiso, String^ llaveStr) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        raiz = eliminarHab(raiz, codPais, codHotel, codPiso, llave);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

void ArbolBinario::eliminarHabPiso(String^ codPais, String^ codHotel, String^ codPiso) {
    raiz=eliminarHabPiso(raiz, codPais, codHotel, codPiso);
}

void ArbolBinario::eliminarPisoHotel(String^ codPais, String^ codHotel) {
    raiz = eliminarPisoHotel(raiz, codPais, codHotel);
}

void ArbolBinario::eliminarHotelPais(String^ codPais) {
    raiz = eliminarHotelPais(raiz, codPais);
}

/*
void ArbolBinario::modificarP(String^ llaveStr, String^ valor) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        modificarP(llave, valor);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

void ArbolBinario::modificarHotel(String^ llaveStr, String^ valor, String^ cant) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        modificarHotel(llave, valor, cant);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

void ArbolBinario::modificarPiso(String^ llaveStr, String^ valor, String^ cant) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        modificarPiso(llave, valor, cant);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}

void ArbolBinario::modificarHab(String^ llaveStr, String^ tipo, String^ num, String^ precio, String^ estado) {
    int llave;
    if (Int32::TryParse(llaveStr, llave)) {
        modificarHab(llave, tipo, num, precio, estado);
    }
    else {
        MessageBox::Show("La llave debe ser un n�mero entero.");
    }
}
*/

void ArbolBinario::leerClientes(String^ nombreArchivo) {
    try {
        // Leer todas las l�neas del archivo
        array<String^>^ lineas = System::IO::File::ReadAllLines(nombreArchivo);

        for each (String ^ line in lineas) {
            // Divide la l�nea en llave y nombre
            array<String^>^ partes = line->Split(';');
            if (partes->Length == 3) {
                String^ codPais = partes[0]->Trim();
                String^ llaveStr = partes[1]->Trim();
                String^ nombre = partes[2]->Trim();

                // Intenta insertar en el �rbol
                insertarCliente(codPais, llaveStr, nombre);
            }
        }
    }
    catch (Exception^ e) {
        MessageBox::Show("Error al leer el archivo: " + e->Message);
    }
}

void ArbolBinario::leerPaises(String^ nombreArchivo) {
    try {
        // Leer todas las l�neas del archivo
        array<String^>^ lineas = System::IO::File::ReadAllLines(nombreArchivo);

        for each (String ^ line in lineas) {
            // Divide la l�nea en llave y nombre
            array<String^>^ partes = line->Split(';');
            if (partes->Length == 2) {
                String^ llaveStr = partes[0]->Trim();
                String^ nombre = partes[1]->Trim();

                // Intenta insertar en el �rbol
                insertarP(llaveStr, nombre);
            }
        }
    }
    catch (Exception^ e) {
        MessageBox::Show("Error al leer el archivo: " + e->Message);
    }
}

void ArbolBinario::leerHotel(String^ nombreArchivo) {
    try {
        // Leer todas las l�neas del archivo
        array<String^>^ lineas = System::IO::File::ReadAllLines(nombreArchivo);

        for each (String ^ line in lineas) {
            // Divide la l�nea en llave y nombre
            array<String^>^ partes = line->Split(';');
            if (partes->Length == 4) {
                String^ codPais = partes[0]->Trim();
                String^ llaveStr = partes[1]->Trim();
                String^ nombre = partes[2]->Trim();
                String^ cant = partes[3]->Trim();

                // Intenta insertar en el �rbol
                insertarHotel(codPais, llaveStr, nombre, cant); 
            }
        }
    }
    catch (Exception^ e) {
        MessageBox::Show("Error al leer el archivo: " + e->Message);
    }
}

void ArbolBinario::leerPiso(String^ nombreArchivo) {
    try {
        // Leer todas las l�neas del archivo
        array<String^>^ lineas = System::IO::File::ReadAllLines(nombreArchivo);

        for each (String ^ line in lineas) {
            // Divide la l�nea en llave y nombre
            array<String^>^ partes = line->Split(';');
            if (partes->Length == 5) {
                String^ codPais = partes[0]->Trim();
                String^ codHotel = partes[1]->Trim();
                String^ llaveStr = partes[2]->Trim();
                String^ nombre = partes[3]->Trim();
                String^ cant = partes[4]->Trim();

                // Intenta insertar en el �rbol
                insertarPiso(codPais, codHotel, llaveStr, nombre, cant);
            }
        }
    }
    catch (Exception^ e) {
        MessageBox::Show("Error al leer el archivo: " + e->Message);
    }
}

void ArbolBinario::leerHab(String^ nombreArchivo) {
    try {
        // Leer todas las l�neas del archivo
        array<String^>^ lineas = System::IO::File::ReadAllLines(nombreArchivo);

        for each (String ^ line in lineas) {
            // Divide la l�nea en llave y nombre
            array<String^>^ partes = line->Split(';');
            if (partes->Length == 8) {
                String^ codPais = partes[0]->Trim();
                String^ codHotel = partes[1]->Trim();
                String^ codPiso = partes[2]->Trim();
                String^ llaveStr = partes[3]->Trim();
                String^ tipo = partes[4]->Trim();
                String^ num = partes[5]->Trim();
                String^ precio = partes[6]->Trim();
                String^ estado = partes[7]->Trim();

                // Intenta insertar en el �rbol
                insertarHab(codPais, codHotel, codPiso, llaveStr, tipo, num, precio, estado);
            }
        }
    }
    catch (Exception^ e) {
        MessageBox::Show("Error al leer el archivo: " + e->Message);
    }
}

void ArbolBinario::leerCarro(String^ nombreArchivo) {
    try {
        // Leer todas las l�neas del archivo
        array<String^>^ lineas = System::IO::File::ReadAllLines(nombreArchivo);

        for each (String ^ line in lineas) {
            // Divide la l�nea en llave y nombre
            array<String^>^ partes = line->Split(';');
            if (partes->Length == 9) {
                String^ codPais = partes[0]->Trim();
                String^ codHotel = partes[1]->Trim();
                String^ codPiso = partes[2]->Trim();
                String^ llaveStr = partes[3]->Trim();
                String^ tipo = partes[4]->Trim();
                String^ num = partes[5]->Trim();
                String^ anho = partes[6]->Trim();
                String^ precio = partes[7]->Trim();
                String^ estado = partes[8]->Trim();

                // Intenta insertar en el �rbol
                insertarCarro(codPais, codHotel, codPiso, llaveStr, tipo, num, anho, precio, estado);
            }
        }
    }
    catch (Exception^ e) {
        MessageBox::Show("Error al leer el archivo: " + e->Message);
    }
}

int contarNodosAux(NodoBinario^ nodo) {
    if (nodo == nullptr) {
        return 0; // Si el nodo es nulo, no contamos nada
    }
    // Contamos el nodo actual y hacemos la suma recursiva de los nodos izquierdo y derecho
    return 1 + contarNodosAux(nodo->izquierdo) + contarNodosAux(nodo->derecho);
}

// M�todo p�blico que llama al auxiliar
int ArbolBinario::contarNodos() {
    return contarNodosAux(raiz); // Iniciamos el conteo desde la ra�z
}

String^ ArbolBinario::consultarClientes() {
    String^ resultado = "";
    return consultarClientesRecursivo(raiz, resultado);
}

String^ ArbolBinario::consultarClientesRecursivo(NodoBinario^ nodo, String^% resultado) {
    if (nodo == nullptr) {
        return resultado; // Retorna la cadena si el nodo es nulo
    }

    // Agrega la llave del nodo actual
    resultado += "Codigo de Pais: " + nodo->codPais + "\r\n" +
        "Codigo de Cliente: " + nodo->llave.ToString() + "\r\n"
        + "Nombre: " + nodo->nombre + "\r\n\r\n";  // Agrega un salto de l�nea

    // Recursi�n en los nodos hijos
    consultarClientesRecursivo(nodo->izquierdo, resultado);
    consultarClientesRecursivo(nodo->derecho, resultado);

    return resultado;
}

String^ ArbolBinario::consultarHotel() {
    String^ resultado = "";
    return consultarHotelRecursivo(raiz, resultado);
}

String^ ArbolBinario::consultarHotelRecursivo(NodoBinario^ nodo, String^% resultado) {
    if (nodo == nullptr) {
        return resultado; // Retorna la cadena si el nodo es nulo
    }

    // Agrega la llave del nodo actual
    resultado += "Codigo de Pais: " + nodo->codPais + "\r\n" +
        "Codigo de hotel: " + nodo->llave.ToString() + "\r\n"
        + "Nombre: " + nodo->nombre + "\r\n"
        + "Cantidad de Estrellas: " + nodo->cantidad + "\r\n\r\n";  // Agrega un salto de l�nea

    // Recursi�n en los nodos hijos
    consultarHotelRecursivo(nodo->izquierdo, resultado);
    consultarHotelRecursivo(nodo->derecho, resultado);

    return resultado;
}

String^ ArbolBinario::consultarPiso(String^ codHotel) {
    String^ resultado = "";
    return consultarPisoRecursivo(raiz, resultado, codHotel);
}

String^ ArbolBinario::consultarPisoRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel) {
    if (nodo == nullptr) {
        return resultado; // Retorna la cadena si el nodo es nulo
    }

    if (nodo->codHotel == codHotel)
    {
        resultado += "Codigo de Pais: " + nodo->codPais + "\r\n" +
            "Codigo de hotel: " + nodo->codHotel + "\r\n"
            + "Numero de Piso: " + nodo->llave.ToString() + "\r\n"
            + "Nombre: " + nodo->nombre + "\r\n"
            + "Cantidad de Habitaciones: " + nodo->cantidad + "\r\n\r\n";
    }

    consultarPisoRecursivo(nodo->izquierdo, resultado, codHotel);
    consultarPisoRecursivo(nodo->derecho, resultado, codHotel);

    return resultado;
}

String^ ArbolBinario::consultarHab(String^ codHotel, String^ codPiso) {
    String^ resultado = "";
    return consultarHabRecursivo(raiz, resultado, codHotel, codPiso);
}

String^ ArbolBinario::consultarHabRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel, String^ codPiso) {
    if (nodo == nullptr) {
        return resultado; // Retorna la cadena si el nodo es nulo
    }

    if (nodo->codHotel == codHotel && nodo->codPiso == codPiso)
    {
        resultado += "Codigo de Pais: " + nodo->codPais + "\r\n" +
            "Codigo de hotel: " + nodo->codHotel + "\r\n"
            + "Numero de Piso: " + nodo->codPiso + "\r\n"
            + "Codigo de Habitacion: " + nodo->llave.ToString() + "\r\n"
            + "Tipo de Cuarto: " + nodo->tipo + "\r\n"
            + "Numero de Camas: " + nodo->num + "\r\n"
            + "Precio: " + nodo->precio + "\r\n"
            + "Estado: " + nodo->estado + "\r\n\r\n";
    }

    consultarHabRecursivo(nodo->izquierdo, resultado, codHotel, codPiso);
    consultarHabRecursivo(nodo->derecho, resultado, codHotel, codPiso);

    return resultado;
}

String^ ArbolBinario::cantidadEstrellas(String^ codHotel) {
    String^ resultado = "";
    return cantidadEstrellasRecursivo(raiz, resultado, codHotel);
}

String^ ArbolBinario::cantidadEstrellasRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel) {
    if (nodo == nullptr) {
        return resultado; // Retorna la cadena si el nodo es nulo
    }

    if (nodo->llave.ToString() == codHotel)
    {
        resultado += "Cantidad de estrellas del hotel " + nodo->nombre + ": " + nodo->cantidad + "\r\n\r\n";
    }

    cantidadEstrellasRecursivo(nodo->izquierdo, resultado, codHotel);
    cantidadEstrellasRecursivo(nodo->derecho, resultado, codHotel);

    return resultado;
}

String^ ArbolBinario::cantidadHabs(String^ codHotel, String^ codPiso) {
    String^ resultado = "";
    return cantidadHabsRecursivo(raiz, resultado, codHotel, codPiso);
}

String^ ArbolBinario::cantidadHabsRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel, String^ codPiso) {
    if (nodo == nullptr) {
        return resultado; // Retorna la cadena si el nodo es nulo
    }

    if (nodo->codHotel == codHotel && nodo->llave.ToString() == codPiso)
    {
        resultado += "Cantidad de habitaciones del piso " + nodo->nombre + ": " + nodo->cantidad + "\r\n\r\n";
    }

    cantidadHabsRecursivo(nodo->izquierdo, resultado, codHotel, codPiso);
    cantidadHabsRecursivo(nodo->derecho, resultado, codHotel, codPiso);

    return resultado;
}

NodoBinario^ ArbolBinario::ultimoInsertado() {
    return ultimoNodoInsertado; // Retorna el �ltimo nodo insertado
}

String^ ArbolBinario::consultarPais() {
    String^ resultado = "";
    return consultarPaisRecursivo(raiz, resultado);
}

String^ ArbolBinario::consultarPaisRecursivo(NodoBinario^ nodo, String^% resultado) {
    if (nodo == nullptr) {
        return resultado; // Retorna la cadena si el nodo es nulo
    }

    // Agrega la llave del nodo actual
    resultado += "Codigo de Pais: " + nodo->llave.ToString() + "\r\n" +
        "Nombre: " + nodo->nombre + "\r\n\r\n";  // Agrega un salto de l�nea

    // Recursi�n en los nodos hijos
    consultarPaisRecursivo(nodo->izquierdo, resultado);
    consultarPaisRecursivo(nodo->derecho, resultado);

    return resultado;
}

String^ ArbolBinario::consultarAgencia() {
    String^ resultado = "";
    return consultarAgenciaRecursivo(raiz, resultado);
}

String^ ArbolBinario::consultarAgenciaRecursivo(NodoBinario^ nodo, String^% resultado) {
    if (nodo == nullptr) {
        return resultado; // Retorna la cadena si el nodo es nulo
    }

    // Agrega la llave del nodo actual
    resultado += "Codigo de Pais: " + nodo->codPais + "\r\n" +
        "Identificacion de Agencia: " + nodo->llave.ToString() + "\r\n"
        + "Nombre: " + nodo->nombre + "\r\n"
        + "Cantidad de Vehiculos: " + nodo->cantidad + "\r\n\r\n";  // Agrega un salto de l�nea

    // Recursi�n en los nodos hijos
    consultarAgenciaRecursivo(nodo->izquierdo, resultado);
    consultarAgenciaRecursivo(nodo->derecho, resultado);

    return resultado;
}

String^ ArbolBinario::consultarFlotilla(String^ codHotel) {
    String^ resultado = "";
    return consultarFlotillaRecursivo(raiz, resultado, codHotel);
}

String^ ArbolBinario::consultarFlotillaRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel) {
    if (nodo == nullptr) {
        return resultado; // Retorna la cadena si el nodo es nulo
    }

    if (nodo->codHotel == codHotel)
    {
        resultado += "Codigo de Pais: " + nodo->codPais + "\r\n" +
            "Identificacion de Agencia: " + nodo->codHotel + "\r\n"
            + "Codigo de Flotilla: " + nodo->llave.ToString() + "\r\n"
            + "Nombre: " + nodo->nombre + "\r\n"
            + "Cantidad de Tipos: " + nodo->cantidad + "\r\n\r\n";
    }

    consultarFlotillaRecursivo(nodo->izquierdo, resultado, codHotel);
    consultarFlotillaRecursivo(nodo->derecho, resultado, codHotel);

    return resultado;
}

String^ ArbolBinario::consultarCarro(String^ codHotel, String^ codPiso) {
    String^ resultado = "";
    return consultarCarroRecursivo(raiz, resultado, codHotel, codPiso);
}

String^ ArbolBinario::consultarCarroRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel, String^ codPiso) {
    if (nodo == nullptr) {
        return resultado; // Retorna la cadena si el nodo es nulo
    }

    if (nodo->codHotel == codHotel && nodo->codPiso == codPiso)
    {
        resultado += "Codigo de Pais: " + nodo->codPais + "\r\n" +
            "Identificacion de Agencia: " + nodo->codHotel + "\r\n"
            + "Codigo de Flotilla: " + nodo->codPiso + "\r\n"
            + "Placa: " + nodo->llave.ToString() + "\r\n"
            + "Modelo: " + nodo->tipo + "\r\n"
            + "Numero de Asientos: " + nodo->num + "\r\n"
            + "A�o: " + nodo->anho + "\r\n"
            + "Precio: " + nodo->precio + "\r\n"
            + "Estado: " + nodo->estado + "\r\n\r\n";
    }

    consultarCarroRecursivo(nodo->izquierdo, resultado, codHotel, codPiso);
    consultarCarroRecursivo(nodo->derecho, resultado, codHotel, codPiso);

    return resultado;
}

String^ ArbolBinario::cantidadAsientos(String^ codHotel) {
    String^ resultado = "";
    return cantidadAsientosRecursivo(raiz, resultado, codHotel);
}

String^ ArbolBinario::cantidadAsientosRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel) {
    if (nodo == nullptr) {
        return resultado; // Retorna la cadena si el nodo es nulo
    }

    if (nodo->llave.ToString() == codHotel)
    {
        resultado += "Cantidad de asientos del carro con placa " + nodo->llave + ": " + nodo->num + "\r\n\r\n";
    }

    cantidadAsientosRecursivo(nodo->izquierdo, resultado, codHotel);
    cantidadAsientosRecursivo(nodo->derecho, resultado, codHotel);

    return resultado;
}