#pragma once

#ifndef PRUEBA_H
#define PRUEBA_H

using namespace System;
using namespace System::Windows::Forms;


public ref class Persona {
private:
    String^ nombre;
    int edad;

public:
    // Constructor
    Persona(String^ nombre, int edad);

    // Propiedades
    property String^ Nombre {
        String^ get();
        void set(String^ value);
    }

    property int Edad {
        int get();
        void set(int value);
    }

    // M�todo
    void Saludar();
};
#endif
