#pragma once

#include "nodo.h"  // Aseg�rate de que el archivo nodo.h est� bien referenciado
#include "Comun.h"
#include <string>   // Necesario para trabajar con std::string

using namespace System;  // Necesario para trabajar con tipos de .NET como String

ref class listaSimple
{
public:
    // Constructor y destructor
    listaSimple();
    ~listaSimple();

    // M�todos
    bool vacio();
    void insertarRH(String^ codPais, String^ codH, String^ numP, String^ codHab, String^ codClient, int factura);
    void insertarRC(String^ codPais, String^ codA, String^ codT, String^ codC, String^ codClient, int factura);
    void borrarInicio();
    void borrarPosicion(int pos);
    int largo();
    String^ mostrarH(); 
    String^ mostrarA(); 
    String^ mostrarFacturaH(String^ codClient);
    String^ mostrarFacturaA(String^ codClient);
    bool buscar(String^ cod);
    int buscarPos(String^ codCliente);
    nodo^ buscarNodo(String^ codCliente);
    bool generarFactura(String^ codCliente);


    void reservarHotel(String^ pais, String^ cod, String^ numP, String^ codH, String^ codClient, int fact);
    void reservarCarro(String^ pais, String^ cod, String^ numP, String^ codH, String^ codClient, int fact);
    void reservarTodo(String^ pais, String^ cod, String^ numP, String^ codH, String^ cod2, String^ numP2, String^ codH2, listaSimple% resHotel, listaSimple% resAgencia, String^ codClient, int fact);

    void ponerPrecioH(NodoBinario^ nodoArbol);
    void ponerPrecioA(NodoBinario^ nodoArbol);

private:
    pnodo primero;  // puntero a nodo (esto es un tipo definido previamente en nodo.h)
    bool generarFactura(nodo^ cabeza, String^ codCliente);

};
