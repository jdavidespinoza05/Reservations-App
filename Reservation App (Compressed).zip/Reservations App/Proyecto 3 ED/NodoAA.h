#pragma once
#include <iostream>
#include <string>

using namespace std;
using namespace System;



    public ref class NodoAA { //------------------------------------------------------------------ ARBOL AA ---------------------------------------------------------------------------------------------
    public:
        int valor; //codPais
        String^ nombre;
        NodoAA^ izquierda;
        NodoAA^ derecha;
        int nivel;

        NodoAA(int val, String^ nombre);
    };
