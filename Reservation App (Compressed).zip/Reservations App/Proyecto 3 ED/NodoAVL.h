#pragma once
#include <iostream>
#include <string>
using namespace std;
class NodoAVL { //--------------------------------------------------------------- ARBOL AVL --------------------------------------------------------------------------------------
public:
	int clave; //numPiso || codTipo
	string codPais;
	string codHotel;
	string nombre;
	string cantidadHab;

	NodoAVL* izquierdo;
	NodoAVL* derecho;
	int altura;

	NodoAVL(int valor, string codPais, string codHotel, string nombre, string cantidadHab);
};