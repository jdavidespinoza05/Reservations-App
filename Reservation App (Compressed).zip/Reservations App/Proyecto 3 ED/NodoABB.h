#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>

using namespace std;

class NodoABB { //--------------------------------------------------------------- ABB --------------------------------------------------------------------------------------
public:
    int valor;
    string codPais;
    string nombre;
    string cantidadEst;

    NodoABB(int val, const string& pais, const string& nom, const string& cantidad)
        : valor(val), codPais(pais), nombre(nom), cantidadEst(cantidad), izquierda(nullptr), derecha(nullptr) {}

    void mostrarH() const;

    void mostrarA() const;

    NodoABB* izquierda;
    NodoABB* derecha;
};