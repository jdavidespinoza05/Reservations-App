#include "pch.h"
#include "ArbolAVL.h"
#include <fstream>
#include <sstream>
/*
int ArbolAVL::altura(NodoAVL* nodo) {
	return nodo ? nodo->altura : 0;
}

int ArbolAVL::obtenerBalance(NodoAVL* nodo) {
	return nodo ? altura(nodo->izquierdo) - altura(nodo->derecho) : 0;
}

NodoAVL* ArbolAVL::rotarDerecha(NodoAVL* y) {
	NodoAVL* x = y->izquierdo;
	NodoAVL* T2 = x->derecho;

	x->derecho = y;
	y->izquierdo = T2;

	y->altura = max(altura(y->izquierdo), altura(y->derecho)) + 1;
	x->altura = max(altura(x->izquierdo), altura(x->derecho)) + 1;

	return x;
}

NodoAVL* ArbolAVL::rotarIzquierda(NodoAVL* x) {
	NodoAVL* y = x->derecho;
	NodoAVL* T2 = y->izquierdo;

	y->izquierdo = x;
	x->derecho = T2;

	x->altura = max(altura(x->izquierdo), altura(x->derecho)) + 1;
	y->altura = max(altura(y->izquierdo), altura(y->derecho)) + 1;

	return y;
}

NodoAVL* ArbolAVL::insertar(NodoAVL* nodo, int clave, string codPais, string codHotel, string nombre, string cantidadHab) {
	if (!nodo) {
		nodo = new NodoAVL(clave, codPais, codHotel, nombre, cantidadHab);
		ultimoInsertado = nodo;
		return nodo;
	}
	if (clave < nodo->clave)
		nodo->izquierdo = insertar(nodo->izquierdo, clave, codPais, codHotel, nombre, cantidadHab);
	else if (clave > nodo->clave)
		nodo->derecho = insertar(nodo->derecho, clave, codPais, codHotel, nombre, cantidadHab);
	else
		return nodo;

	nodo->altura = 1 + max(altura(nodo->izquierdo), altura(nodo->derecho));
	int balance = obtenerBalance(nodo);

	if (balance > 1 && clave < nodo->izquierdo->clave)
		return rotarDerecha(nodo);

	if (balance < -1 && clave > nodo->derecho->clave)
		return rotarIzquierda(nodo);

	if (balance > 1 && clave > nodo->izquierdo->clave) {
		nodo->izquierdo = rotarIzquierda(nodo->izquierdo);
		return rotarDerecha(nodo);
	}

	if (balance < -1 && clave < nodo->derecho->clave) {
		nodo->derecho = rotarDerecha(nodo->derecho);
		return rotarIzquierda(nodo);
	}

	return nodo;
}

NodoAVL* ArbolAVL::nodoConValorMinimo(NodoAVL* nodo) {
	NodoAVL* actual = nodo;
	while (actual->izquierdo)
		actual = actual->izquierdo;
	return actual;
}

NodoAVL* ArbolAVL::obtenerUltimoInsertado() {
	return ultimoInsertado;
}

NodoAVL* ArbolAVL::borrar(NodoAVL* raiz, int clave) {
	if (!raiz)
		return raiz;

	if (clave < raiz->clave)
		raiz->izquierdo = borrar(raiz->izquierdo, clave);
	else if (clave > raiz->clave)
		raiz->derecho = borrar(raiz->derecho, clave);
	else {
		if ((!raiz->izquierdo) || (!raiz->derecho)) {
			NodoAVL* temp = raiz->izquierdo ? raiz->izquierdo : raiz->derecho;

			if (!temp) {
				temp = raiz;
				raiz = nullptr;
			}
			else
				*raiz = *temp;

			delete temp;
		}
		else {
			NodoAVL* temp = nodoConValorMinimo(raiz->derecho);
			raiz->clave = temp->clave;
			raiz->codPais = temp->codPais;
			raiz->codHotel = temp->codHotel;
			raiz->nombre = temp->nombre;
			raiz->cantidadHab = temp->cantidadHab;
			raiz->derecho = borrar(raiz->derecho, temp->clave);
		}
	}

	if (!raiz)
		return raiz;

	raiz->altura = 1 + max(altura(raiz->izquierdo), altura(raiz->derecho));
	int balance = obtenerBalance(raiz);

	if (balance > 1 && obtenerBalance(raiz->izquierdo) >= 0)
		return rotarDerecha(raiz);

	if (balance > 1 && obtenerBalance(raiz->izquierdo) < 0) {
		raiz->izquierdo = rotarIzquierda(raiz->izquierdo);
		return rotarDerecha(raiz);
	}

	if (balance < -1 && obtenerBalance(raiz->derecho) <= 0)
		return rotarIzquierda(raiz);

	if (balance < -1 && obtenerBalance(raiz->derecho) > 0) {
		raiz->derecho = rotarDerecha(raiz->derecho);
		return rotarIzquierda(raiz);
	}

	return raiz;
}

NodoAVL* ArbolAVL::buscar(NodoAVL* nodo, int clave) {
	if (!nodo || nodo->clave == clave)
		return nodo;

	if (clave < nodo->clave)
		return buscar(nodo->izquierdo, clave);

	return buscar(nodo->derecho, clave);
}

void ArbolAVL::preOrdenP(NodoAVL* raiz) {
	if (raiz) {
		cout << "CodPais: " << raiz->codPais << " - CodHotel: " << raiz->codHotel << " - NumPiso: " << raiz->clave << " - Nombre: " << raiz->nombre << " - cantidadHab: " << raiz->cantidadHab << endl;
		preOrdenP(raiz->izquierdo);
		preOrdenP(raiz->derecho);
	}
}

void ArbolAVL::preOrdenF(NodoAVL* raiz) {
	if (raiz) {
		cout << "CodPais: " << raiz->codPais << " - IdentificacionAg: " << raiz->codHotel << " - CodTipo: " << raiz->clave << " - Nombre: " << raiz->nombre << " - cantidadCarros: " << raiz->cantidadHab << endl;
		preOrdenF(raiz->izquierdo);
		preOrdenF(raiz->derecho);
	}
}

ArbolAVL::ArbolAVL() {
	raiz = NULL;
}

void ArbolAVL::insertar(int clave, string codPais, string codHotel, string nombre, string cantidadHab) {
	raiz = insertar(raiz, clave, codPais, codHotel, nombre, cantidadHab);
}

void ArbolAVL::borrar(int clave) {
	raiz = borrar(raiz, clave);
}

bool ArbolAVL::buscar(int clave) {
	return buscar(raiz, clave) != nullptr;
}

void ArbolAVL::preOrdenP() {
	preOrdenP(raiz);
	cout << endl;
}

void ArbolAVL::preOrdenF() {
	preOrdenF(raiz);
	cout << endl;
}

void ArbolAVL::leerPisoFlotilla(const string& nombreArchivo) {
	ifstream archivo(nombreArchivo);

	if (!archivo.is_open()) {
		cerr << "No se pudo abrir el archivo: " << nombreArchivo << endl;
		return;
	}

	archivo.seekg(0, ios::end);
	streampos tamano = archivo.tellg();
	archivo.seekg(0, ios::beg);

	if (tamano == 0) {
		cout << "El archivo está vacío." << endl;
		archivo.close();
		return;
	}

	int i = 0;
	NodoAVL* aux = raiz;
	string linea;

	while (getline(archivo, linea)) {
		stringstream ss(linea);
		string campo, codPais, codHotel, nombre, cantidadHab;
		int valor = -1;
		int campoNum = 0;

		i = -1;
		while (getline(ss, campo, ';')) {
			if (i == -1)
			{
				codPais = campo;
			}
			else if (i == 0)
			{
				codHotel = campo;
			}
			else if (i == 1)
			{

				campoNum = stoi(campo);
				valor = campoNum;
			}
			else if (i == 2)
			{
				nombre = campo;
			}
			else if (i == 3)
			{
				cantidadHab = campo;
			}
			i++;
		}
		if (valor != -1)
		{
			insertar(valor, codPais, codHotel, nombre, cantidadHab);
		}
	}
	archivo.close();
}

void ArbolAVL::insertarPiso(ArbolAA& paises, ABB& hoteles) {
	string cod, pais;
	string numP;
	string nom;
	string cant;

	cout << "Acontinuacion se le pedira que ingrese toda la informacion del nuevo piso." << endl << endl;

	cout << "Inserte Codigo Pais: ";
	cin >> pais;
	if (esNumero(pais) == false || !paises.buscar(stoi(pais))) {
		cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
		return;
	}

	cout << "Inserte Codigo Hotel: ";
	cin >> cod;
	if (esNumero(cod) == false || !hoteles.buscar(stoi(cod))) {
		cout << endl << "Error, el codigo debe ser un numero y debe existir." << endl << endl;
		return;
	}

	cout << "Inserte Numero de Piso: ";
	cin >> numP;
	if (esNumero(numP) == false || buscar(stoi(numP))) {
		cout << endl << "Error, el numero de piso debe ser un numero y no debe estar registrado." << endl << endl;
		return;
	}

	cout << "Inserte Nombre: ";
	cin >> nom;

	cout << "Inserte Cantidad de Habitaciones: ";
	cin >> cant;
	if (esNumero(cant) == false) {
		cout << endl << "Error, la cantidad de habitaciones debe ser un numero." << endl << endl;
		return;
	}
	cout << endl;

	insertar(stoi(numP), pais, cod, nom, cant);

	cout << "Piso insertado con exito." << endl << endl;
	return;
}

void ArbolAVL::insertarFlotilla(ArbolAA& paises, ABB& agencias) {
	string cod, pais;
	string numP;
	string nom;
	string cant;

	cout << "Acontinuacion se le pedira que ingrese toda la informacion de la nueva flotilla." << endl << endl;

	cout << "Inserte Codigo Pais: ";
	cin >> pais;
	if (esNumero(pais) == false || !paises.buscar(stoi(pais))) {
		cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
		return;
	}

	cout << "Inserte Identificacion Agencia: ";
	cin >> cod;
	if (esNumero(cod) == false || !agencias.buscar(stoi(cod))) {
		cout << endl << "Error, la identificacion debe ser un numero y debe existir." << endl << endl;
		return;
	}

	cout << "Inserte Numero de Tipo Flotilla: ";
	cin >> numP;
	if (esNumero(numP) == false || buscar(stoi(numP))) {
		cout << endl << "Error, el numero de tipo flotilla debe ser un numero y no debe existir." << endl << endl;
		return;
	}

	cout << "Inserte Nombre: ";
	cin >> nom;

	cout << "Inserte Cantidad de Tipos de Carros: ";
	cin >> cant;
	if (esNumero(cant) == false) {
		cout << endl << "Error, la cantidad de tipos de carros debe ser un numero." << endl << endl;
		return;
	}
	cout << endl;

	insertar(stoi(numP), pais, cod, nom, cant);

	cout << "Tipo Flotilla insertado con exito." << endl << endl;
	return;
}

void ArbolAVL::modificarPiso(ArbolAA& paises, ABB& hoteles) {
	string cod, pais;
	string codH;
	string verif;
	string nuevo;

	int i = 1;

	cout << "Inserte Codigo Pais: ";
	cin >> pais;
	if (esNumero(pais) == false || !paises.buscar(stoi(pais))) {
		cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
		return;
	}

	cout << "Inserte el Codigo del Hotel del piso que desea modificar: ";
	cin >> codH;
	if (esNumero(codH) == false || !hoteles.buscar(stoi(codH))) {
		cout << endl << "Error, el codigo debe ser un numero y debe existir." << endl << endl;
		return;
	}

	cout << "Inserte el Numero de Piso que desea modificar: ";
	cin >> cod;
	cout << endl;
	if (esNumero(cod) == false || !buscar(stoi(cod))) {
		cout << endl << "Error, el codigo debe ser un numero y debe existir." << endl << endl;
		return;
	}

	else
	{
		cout << "               1. Nombre" << endl << "               2. Habitaciones" << endl << endl;
		cout << "Inserte el numero de lo que desea modificar: ";
		cin >> verif;
		cout << endl;
		if (verif == "1") {
			cout << "Inserte el nuevo Nombre: ";
			cin >> nuevo;
			cout << endl;
			NodoAVL* nodo = buscar(raiz, stoi(cod));
			if (nodo->codHotel == codH && nodo->clave == stoi(cod))
			{
				nodo->nombre = nuevo;
				cout << "Se modifico con exito." << endl << endl;
				return;
			}
			cout << "Error, no hay numero de piso con ese codigo hotel" << endl << endl;
			return;
		}
		else if (verif == "2") {
			cout << "Inserte el nuevo Numero de Habitaciones: ";
			cin >> nuevo;
			cout << endl;
			if (esNumero(nuevo) == false) {
				cout << endl << "Error, debe ser un numero." << endl << endl;
				return;
			}
			NodoAVL* nodo = buscar(raiz, stoi(cod));
			if (nodo->codHotel == codH && nodo->clave == stoi(cod))
			{
				nodo->cantidadHab = nuevo;
				cout << "Se modifico con exito." << endl << endl;
				return;
			}
			cout << "Error, no hay numero de piso con ese codigo hotel" << endl << endl;
			return;

		}
		else
		{
			cout << endl << "Error, solo se puede ingresar un numero de los anteriores." << endl << endl;
			return;
		}
	}
}

void ArbolAVL::modificarFlotilla(ArbolAA& paises, ABB& agencias) {
	string cod, pais;
	string codH;
	string verif;
	string nuevo;

	int i = 1;

	cout << "Inserte Codigo Pais: ";
	cin >> pais;
	if (esNumero(pais) == false || !paises.buscar(stoi(pais))) {
		cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
		return;
	}

	cout << "Inserte la Identificacion de la Agencia del tipo flotilla que desea modificar: ";
	cin >> codH;
	if (esNumero(codH) == false || !agencias.buscar(stoi(codH))) {
		cout << endl << "Error, la identificacion debe ser un numero y debe existir." << endl << endl;
		return;
	}

	cout << "Inserte el codigo de tipo que desea modificar: ";
	cin >> cod;
	cout << endl;
	if (esNumero(cod) == false || !buscar(stoi(cod))) {
		cout << endl << "Error, el codigo debe ser un numero y debe existir." << endl << endl;
		return;
	}

	else
	{
		cout << "               1. Nombre" << endl << "               2. Tipo Carros" << endl << endl;
		cout << "Inserte el numero de lo que desea modificar: ";
		cin >> verif;
		cout << endl;
		if (verif == "1") {
			cout << "Inserte el nuevo Nombre: ";
			cin >> nuevo;
			cout << endl;
			NodoAVL* nodo = buscar(raiz, stoi(cod));
			if (nodo->codHotel == codH && nodo->clave == stoi(cod))
			{
				nodo->nombre = nuevo;
				cout << "Se modifico con exito." << endl << endl;
				return;
			}
			cout << "Error, no existe el codigo de tipo en la agencia." << endl << endl;
			return;
		}
		else if (verif == "2") {
			cout << "Inserte la nueva Cantidad de Tipos de Carro: ";
			cin >> nuevo;
			cout << endl;
			if (esNumero(nuevo) == false) {
				cout << endl << "Error, debe ser un numero." << endl << endl;
				return;
			}
			NodoAVL* nodo = buscar(raiz, stoi(cod));
			if (nodo->codHotel == codH && nodo->clave == stoi(cod))
			{
				nodo->cantidadHab = nuevo;
				cout << "Se modifico con exito." << endl << endl;
				return;
			}
			cout << "Error, no existe el codigo de tipo en la agencia." << endl << endl;
			return;
		}
		else
		{
			cout << endl << "Error, solo se puede ingresar un numero de los anteriores." << endl << endl;
			return;
		}
	}
}

bool ArbolAVL::buscarCodH(NodoAVL* nodo, string cod) {
	if (nodo == nullptr) {
		return false;
	}
	if (nodo->codHotel == cod) {
		return true;
	}
	return buscarCodH(nodo->izquierdo, cod) || buscarCodH(nodo->derecho, cod);
}

void ArbolAVL::consultarPisoAux(NodoAVL* nodo, const string& verif) {
	if (nodo == nullptr) {
		return; // Caso base: nodo vacío
	}

	// Recorrer el subárbol izquierdo
	consultarPisoAux(nodo->izquierdo, verif);

	// Procesar el nodo actual
	if (nodo->codHotel == verif) {

		cout << "Codigo Pais: " << nodo->codPais << endl;
		string texto = "Codigo Pais: " + nodo->codPais + "\n";

		cout << "Codigo Hotel: " << nodo->codHotel << endl;
		texto += "Codigo Hotel: " + nodo->codHotel + "\n";

		cout << "Numero de Piso: " << nodo->clave << endl;
		string clave = to_string(nodo->clave);
		texto += "Numero de Piso: " + clave + "\n";

		cout << "Nombre: " << nodo->nombre << endl;
		texto += "Nombre: " + nodo->nombre + "\n";

		cout << "Cantidad Habitaciones: " << nodo->cantidadHab << endl << std::endl;
		texto += "Cantidad Habitaciones: " + nodo->cantidadHab + "\n\n";

		guardarReporte("consultarPiso.txt", texto);
	}

	// Recorrer el subárbol derecho
	consultarPisoAux(nodo->derecho, verif);
}

bool ArbolAVL::buscarPais(NodoAVL* nodo, const string& pais) {
	if (nodo == nullptr) {
		return false; // No se encontró el nodo
	}

	// Comparar el numPiso del nodo actual
	if (nodo->codPais == pais) {
		return true; // Se encontró el numPiso
	}

	// Buscar en el subárbol izquierdo y derecho
	return buscarPais(nodo->izquierdo, pais) || buscarPais(nodo->derecho, pais);
}

void ArbolAVL::consultarPiso() { //*************************
	NodoAVL* aux = raiz;
	string verifP;
	string verif;
	string texto;
	int codH;
	int codP;

	//Implementar buscarCodP
	cout << "Inserte el codigo de pais del piso que desea saber su info: ";
	cin >> verifP;
	cout << endl;

	if (esNumero(verifP) == false) {
		cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
		return;
	}

	if (buscarPais(raiz, verifP) == false)
	{
		cout << "Error, no hay ningun piso con ese codigo." << endl << endl;
		return;
	}

	cout << "Inserte el codigo de hotel del piso que desea saber su info: ";
	cin >> verif;
	cout << endl;

	if (esNumero(verif) == false) {
		cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
		return;
	}

	if (buscarCodH(raiz, verif) == false)
	{
		cout << "Error, no hay ningun piso con ese codigo de hotel." << endl << endl;
		return;
	}
	consultarPisoAux(raiz, verif);
	cout << endl;
}

void ArbolAVL::consultarFlotillaAux(NodoAVL* nodo, const string& verif) {
	if (nodo == nullptr) {
		return; // Caso base: nodo vacío
	}

	// Recorrer el subárbol izquierdo
	consultarFlotillaAux(nodo->izquierdo, verif);

	// Procesar el nodo actual
	if (nodo->codHotel == verif) {

		cout << "Codigo Pais: " << nodo->codPais << endl;
		string texto = "Codigo Pais: " + nodo->codPais + "\n";

		cout << "Codigo Agencia: " << nodo->codHotel << endl;
		texto += "Codigo Agencia: " + nodo->codHotel + "\n";

		cout << "Numero Tipo: " << nodo->clave << endl;
		string clave = to_string(nodo->clave);
		texto += "Numero Tipo: " + clave + "\n";

		cout << "Nombre: " << nodo->nombre << endl;
		texto += "Nombre: " + nodo->nombre + "\n";

		cout << "Cantidad Carros Tipo: " << nodo->cantidadHab << endl << std::endl;
		texto += "Cantidad Carros Tipo: " + nodo->cantidadHab + "\n\n";

		guardarReporte("consultarTipoFlotilla.txt", texto);
	}

	// Recorrer el subárbol derecho
	consultarFlotillaAux(nodo->derecho, verif);
}

void ArbolAVL::consultarTipoFlotilla() { //*************************
	NodoAVL* aux = raiz;
	string verifP;
	string verif;
	string texto;
	int codH;
	int codP;

	//Implementar buscarCodP
	cout << "Inserte el codigo de pais del tipo Flotilla que desea saber su info: ";
	cin >> verifP;
	cout << endl;

	if (esNumero(verifP) == false) {
		cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
		return;
	}

	if (buscarPais(raiz, verifP) == false)
	{
		cout << "Error, no hay ningun tipo Flotilla con ese codigo de pais." << endl << endl;
		return;
	}

	cout << "Inserte el codigo de la agencia del tipo flotilla que desea saber su info: ";
	cin >> verif;
	cout << endl;

	if (esNumero(verif) == false) {
		cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
		return;
	}
	codH = stoi(verif);

	if (buscarCodH(raiz, verif) == false)
	{
		cout << "Error, no hay ningun piso con ese codigo de hotel." << endl << endl;
		return;
	}
	consultarFlotillaAux(raiz, verif);
	cout << endl;
}

bool ArbolAVL::buscarPiso(NodoAVL* nodo, const string& piso) {
	if (nodo == nullptr) {
		return false; // No se encontró el nodo
	}

	// Comparar el numPiso del nodo actual
	if (nodo->clave == stoi(piso)) {
		return true; // Se encontró el numPiso
	}

	// Buscar en el subárbol izquierdo y derecho
	if (stoi(piso) < nodo->clave) {
		return buscarPiso(nodo->izquierdo, piso);
	}
	return buscarPiso(nodo->derecho, piso);
}

void ArbolAVL::cantidadHab() {  //REVISAR CODIGO------------------------------ NO LEE BIEN EL NUMERO DE PISO
	NodoAVL* aux = raiz;
	string codP;
	string codH;
	string verif, texto;

	cout << "Inserte el codigo de pais del tipo Flotilla que desea saber su info: ";
	cin >> codP;
	cout << endl;

	if (esNumero(codP) == false) {
		cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
		return;
	}

	if (buscarPais(raiz, codP) == false)
	{
		cout << "Error, no hay ningun pais con ese codigo." << endl << endl;
		return;
	}

	cout << "Inserte el codigo de hotel del piso del que desea saber su cantidad de habitaciones: ";
	cin >> codH;
	cout << endl;

	if (esNumero(codH) == false) {
		cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
		return;
	}

	if (buscarCodH(raiz, codH) == false)
	{
		cout << "Error, no hay ningun piso con ese codigo de hotel." << endl << endl;
		return;
	}

	cout << "Inserte el numero de piso del que desea saber su cantidad de habitaciones: ";
	cin >> verif;
	cout << endl;

	if (buscar(stoi(verif)) == false)
	{
		cout << "Error, no existe piso con ese numero." << endl << endl;
		return;
	}

	cantidadHabAux(raiz, stoi(verif));
}

void ArbolAVL::cantidadHabAux(NodoAVL* nodo, int codH) {
	if (codH == nodo->clave) {
		string texto = "Codigo Hotel: " + nodo->codHotel + "\n";
		texto += "Cantidad de Habitaciones: " + nodo->cantidadHab + "\n\n";
		cout << texto;
		guardarReporte("consultarCantHab.txt", texto);
		return;
	}
	else if (codH < nodo->clave) {
		cantidadHabAux(nodo->izquierdo, codH); // Navegar hacia la izquierda
	}
	else {
		cantidadHabAux(nodo->derecho, codH); // Navegar hacia la derecha
	}
}

void ArbolAVL::ultimo() {
	NodoAVL* nodo = obtenerUltimoInsertado();
	string texto = "Ultimo piso registrado:\n";

	//cout << "Codigo Pais: " << nodo->codPais << endl;
	//texto += "Codigo Pais: " + nodo->codPais + "\n";

	//texto += "Codigo Hotel: " + nodo->codHotel + "\n";

	string clave = to_string(nodo->clave);
	texto += "Numero de Piso: " + clave + "\n";

	cout << texto << endl;
	guardarReporte("consultarUltP.txt", texto);
}

void ArbolAVL::ultimoTF() {
	NodoAVL* nodo = obtenerUltimoInsertado();
	string texto = "Ultimo Tipo Flotilla registrado:\n";


	string clave = to_string(nodo->clave);
	texto += "Tipo flotilla: " + clave + "\n";

	cout << texto << endl;
	guardarReporte("consultarUltTF.txt", texto);
}
*/