#include "pch.h"
#include "nodo.h"

// Constructor por defecto
nodo::nodo()
{
    siguiente = nullptr;
    anterior = nullptr;
    valor = 0;  // Aqu� accedes directamente a 'valor'
    caracter = "";  // Aqu� accedes directamente a 'caracter'
}

// Constructor con un valor entero
nodo::nodo(int v)
{
    valor = v;  // Aqu� accedes directamente a 'valor'
    siguiente = nullptr;
    anterior = nullptr;
}

// Constructor con valor entero y siguiente nodo
nodo::nodo(int v, nodo^ signodo)
{
    valor = v;  // Aqu� accedes directamente a 'valor'
    siguiente = signodo;
    anterior = nullptr;
}

// Constructor con un string
nodo::nodo(String^ dato)
{
    valor = 0;  // Aqu� accedes directamente a 'valor'
    caracter = dato;  // Aqu� accedes directamente a 'caracter'
    siguiente = nullptr;
    anterior = nullptr;
}

// Constructor con un string y siguiente nodo
nodo::nodo(String^ dato, nodo^ signodo)
{
    valor = 0;  // Aqu� accedes directamente a 'valor'
    caracter = dato;  // Aqu� accedes directamente a 'caracter'
    siguiente = signodo;
    anterior = nullptr;
}
