#pragma once

#ifndef ARBOLAA_H
#define ARBOLAA_H
/*
#include "NodoAA.h"
#include <iostream>
#include "funcionesX.h"

using namespace System;
using namespace System::IO;


    public ref class ArbolAA {
public:
    NodoAA^ raiz;
    NodoAA^ ultimoInsertado;

    void rotarIzquierda(NodoAA^% nodo);

    void rotarDerecha(NodoAA^% nodo);

    void nivelar(NodoAA^% nodo);

    NodoAA^ insertarNodo(NodoAA^ nodo, int valor, String^ nombre);

    NodoAA^ borrarNodo(NodoAA^ nodo, int valor);

    String^ inOrdenHelper(NodoAA^ nodo, String^ emp);

    NodoAA^ buscar(NodoAA^ nodo, int valor);

    NodoAA^ obtenerUltimoInsertado();

    ArbolAA();

    void insertar(int valor, String^ nombre);

    void borrar(int valor);

    void print();

    bool buscar(int valor);

    void leerPais(String^ nombreArchivo);

    void insertarPais(String^ cod, String^ nom);
    void modificarPais();

    void consultarPaises();
    //string ultimo();
};*/
#endif 