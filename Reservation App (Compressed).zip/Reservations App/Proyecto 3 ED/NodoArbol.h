using namespace System;

public ref class NodoBinario {
public:
    int llave; // Llave del nodo
    String^ nombre; // Valor asociado

    String^ codPais; // Valor asociado
    String^ cantidad; // Valor asociado

    String^ codHotel; // Valor asociado

    String^ codPiso; // Valor asociado
    String^ tipo; // Valor asociado
    String^ num; // Valor asociado
    String^ precio; // Valor asociado
    String^ estado; // Valor asociado

    String^ anho; // Valor asociado


    NodoBinario^ izquierdo; // Hijo izquierdo
    NodoBinario^ derecho; // Hijo derecho

    NodoBinario(int key, String^ val, String^ codPa) { //CLIENTE
        llave = key;
        nombre = val;
        codPais = codPa;
        izquierdo = nullptr;
        derecho = nullptr;
    }
    NodoBinario(int key, String^ val) { //PAIS
        llave = key;
        nombre = val;
        izquierdo = nullptr;
        derecho = nullptr;
    }
    NodoBinario(int key, String^ val, String^ codPa, String^ cant) { //HOTEL
        llave = key;
        nombre = val;
        codPais = codPa;
        cantidad = cant;
        izquierdo = nullptr;
        derecho = nullptr;
    }
    NodoBinario(int key, String^ val, String^ codPa, String^ codH, String^ cant) { //PISO
        llave = key;
        nombre = val;
        codPais = codPa;
        codHotel = codH;
        cantidad = cant;
        izquierdo = nullptr;
        derecho = nullptr;
    }
    NodoBinario(int key, String^ codPa, String^ codH, String^ codPi, String^ tipoCuarto, String^ numCamas, String^ precioHab, String^ estadoHab) { //HABITACION
        llave = key;
        codPais = codPa;
        codHotel = codH;
        codPiso = codPi;
        tipo = tipoCuarto;
        num = numCamas;
        precio = precioHab;
        estado = estadoHab;
        izquierdo = nullptr;
        derecho = nullptr;
    }
    NodoBinario(int key, String^ codPa, String^ codH, String^ codPi, String^ tipoCuarto, String^ numCamas, String^ precioHab, String^ estadoHab, String^ a�o) { //CARRO
        llave = key;
        codPais = codPa;
        codHotel = codH;
        codPiso = codPi;
        tipo = tipoCuarto;
        num = numCamas;
        precio = precioHab;
        estado = estadoHab;
        anho = a�o;
        izquierdo = nullptr;
        derecho = nullptr;
    }
};
