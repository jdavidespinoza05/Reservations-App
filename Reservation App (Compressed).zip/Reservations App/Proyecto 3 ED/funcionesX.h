#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>

using namespace std;

void borrarContenidoArchivo(const string& nombreArchivo);
bool esNumero(const string& str);
int contarLineasArchivo(const string& nombreArchivo);
void guardarReporte(const string& nombreArchivo, string& contenidoReporte);