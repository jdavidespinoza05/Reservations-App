#pragma once
#include "pch.h"
#include "prueba.h"

Persona::Persona(String^ nombre, int edad) {
    this->nombre = nombre;
    this->edad = edad;
}

// Propiedades
String^ Persona::Nombre::get() {
    return nombre;
}

void Persona::Nombre::set(String^ value) {
    nombre = value;
}

int Persona::Edad::get() {
    return edad;
}

void Persona::Edad::set(int value) {
    edad = value;
}

// M�todo
void Persona::Saludar() {
    String^ mensaje = String::Format("Hola, mi nombre es {0} y tengo {1} a�os.", nombre, edad);
    MessageBox::Show(mensaje, "Saludo", MessageBoxButtons::OK, MessageBoxIcon::Information);
}