#include "pch.h"
#include "ARN.h"
/*
// Implementaciones de los m�todos de ArbolRojoNegro
void ArbolRojoNegro::inicializarNNULL() {
    TNULL = new NodoRB(0);
    TNULL->color = BLACK;
    raiz = TNULL;
}

void ArbolRojoNegro::inOrdenHelperH(NodoRB* nodo) {
    if (nodo != TNULL) {
        inOrdenHelperH(nodo->izquierda);
        cout << "CodPais: " << nodo->codPais << " - CodHotel: " << nodo->codHotel
            << " - NumPiso: " << nodo->numPiso << " - CodHabitacion: " << nodo->valor
            << " - TipoCuarto: " << nodo->tipoCuarto << " - NumCamas: " << nodo->numCamas
            << " - PrecioHab: " << nodo->precioHab << " - EstadoHab: " << nodo->estadoHab << endl;
        inOrdenHelperH(nodo->derecha);
    }
}

void ArbolRojoNegro::inOrdenHelperC(NodoRB* nodo) {
    if (nodo != TNULL) {
        inOrdenHelperC(nodo->izquierda);
        cout << "CodPais: " << nodo->codPais << " - IdentificacionAg: " << nodo->codHotel
            << " - CodTipo: " << nodo->numPiso << " - Placa: " << nodo->valor
            << " - Modelo: " << nodo->tipoCuarto << " - NumeroAsientos: " << nodo->numCamas
            << " - A�o: " << nodo->anho << " - PrecioCarro: " << nodo->precioHab
            << " - EstadoCarro: " << nodo->estadoHab << endl;
        inOrdenHelperC(nodo->derecha);
    }
}

void ArbolRojoNegro::balancearInsercion(NodoRB* nodo) {
    NodoRB* temp;
    while (nodo->padre->color == RED) {
        if (nodo->padre == nodo->padre->padre->izquierda) {
            temp = nodo->padre->padre->derecha;
            if (temp->color == RED) {
                nodo->padre->color = BLACK;
                temp->color = BLACK;
                nodo->padre->padre->color = RED;
                nodo = nodo->padre->padre;
            }
            else {
                if (nodo == nodo->padre->derecha) {
                    nodo = nodo->padre;
                    rotarIzquierda(nodo);
                }
                nodo->padre->color = BLACK;
                nodo->padre->padre->color = RED;
                rotarDerecha(nodo->padre->padre);
            }
        }
        else {
            temp = nodo->padre->padre->izquierda;
            if (temp->color == RED) {
                nodo->padre->color = BLACK;
                temp->color = BLACK;
                nodo->padre->padre->color = RED;
                nodo = nodo->padre->padre;
            }
            else {
                if (nodo == nodo->padre->izquierda) {
                    nodo = nodo->padre;
                    rotarDerecha(nodo);
                }
                nodo->padre->color = BLACK;
                nodo->padre->padre->color = RED;
                rotarIzquierda(nodo->padre->padre);
            }
        }
    }
    raiz->color = BLACK;
}

void ArbolRojoNegro::rotarIzquierda(NodoRB* x) {
    NodoRB* y = x->derecha;
    x->derecha = y->izquierda;
    if (y->izquierda != TNULL) {
        y->izquierda->padre = x;
    }
    y->padre = x->padre;
    if (x->padre == TNULL) {
        raiz = y;
    }
    else if (x == x->padre->izquierda) {
        x->padre->izquierda = y;
    }
    else {
        x->padre->derecha = y;
    }
    y->izquierda = x;
    x->padre = y;
}

void ArbolRojoNegro::rotarDerecha(NodoRB* x) {
    NodoRB* y = x->izquierda;
    x->izquierda = y->derecha;
    if (y->derecha != TNULL) {
        y->derecha->padre = x;
    }
    y->padre = x->padre;
    if (x->padre == TNULL) {
        raiz = y;
    }
    else if (x == x->padre->derecha) {
        x->padre->derecha = y;
    }
    else {
        x->padre->izquierda = y;
    }
    y->derecha = x;
    x->padre = y;
}

void ArbolRojoNegro::balancearBorrado(NodoRB* nodo) {
    NodoRB* temp;
    while (nodo != raiz && nodo->color == BLACK) {
        if (nodo == nodo->padre->izquierda) {
            temp = nodo->padre->derecha;
            if (temp->color == RED) {
                temp->color = BLACK;
                nodo->padre->color = RED;
                rotarIzquierda(nodo->padre);
                temp = nodo->padre->derecha;
            }
            if (temp->izquierda->color == BLACK && temp->derecha->color == BLACK) {
                temp->color = RED;
                nodo = nodo->padre;
            }
            else {
                if (temp->derecha->color == BLACK) {
                    temp->izquierda->color = BLACK;
                    temp->color = RED;
                    rotarDerecha(temp);
                    temp = nodo->padre->derecha;
                }
                temp->color = nodo->padre->color;
                nodo->padre->color = BLACK;
                temp->derecha->color = BLACK;
                rotarIzquierda(nodo->padre);
                nodo = raiz;
            }
        }
        else {
            temp = nodo->padre->izquierda;
            if (temp->color == RED) {
                temp->color = BLACK;
                nodo->padre->color = RED;
                rotarDerecha(nodo->padre);
                temp = nodo->padre->izquierda;
            }
            if (temp->derecha->color == BLACK && temp->izquierda->color == BLACK) {
                temp->color = RED;
                nodo = nodo->padre;
            }
            else {
                if (temp->izquierda->color == BLACK) {
                    temp->derecha->color = BLACK;
                    temp->color = RED;
                    rotarIzquierda(temp);
                    temp = nodo->padre->izquierda;
                }
                temp->color = nodo->padre->color;
                nodo->padre->color = BLACK;
                temp->izquierda->color = BLACK;
                rotarDerecha(nodo->padre);
                nodo = raiz;
            }
        }
    }
    nodo->color = BLACK;
}

void ArbolRojoNegro::transplantar(NodoRB* u, NodoRB* v) {
    if (u->padre == TNULL) {
        raiz = v;
    }
    else if (u == u->padre->izquierda) {
        u->padre->izquierda = v;
    }
    else {
        u->padre->derecha = v;
    }
    v->padre = u->padre;
}

NodoRB* ArbolRojoNegro::encontrarMinimo(NodoRB* nodo) {
    while (nodo->izquierda != TNULL) {
        nodo = nodo->izquierda;
    }
    return nodo;
}

NodoRB* ArbolRojoNegro::buscar(NodoRB* nodo, int valor) {
    if (nodo == TNULL || valor == nodo->valor) {
        return nodo;
    }
    if (valor < nodo->valor) {
        return buscar(nodo->izquierda, valor);
    }
    return buscar(nodo->derecha, valor);
}

ArbolRojoNegro::ArbolRojoNegro() {
    inicializarNNULL();
}

void ArbolRojoNegro::insertar(int valor, string codPais, string codHotel, string numPiso, string tipoCuarto, string numCamas, string precioHab, string estadoHab) {
    NodoRB* nuevo = new NodoRB(valor, codPais, codHotel, numPiso, tipoCuarto, numCamas, precioHab, estadoHab);
    nuevo->padre = TNULL;

    NodoRB* y = TNULL;
    NodoRB* x = raiz;

    while (x != TNULL) {
        y = x;
        if (nuevo->valor < x->valor) {
            x = x->izquierda;
        }
        else {
            x = x->derecha;
        }
    }

    nuevo->padre = y;
    if (y == TNULL) {
        raiz = nuevo;
    }
    else if (nuevo->valor < y->valor) {
        y->izquierda = nuevo;
    }
    else {
        y->derecha = nuevo;
    }

    nuevo->izquierda = TNULL;
    nuevo->derecha = TNULL;
    nuevo->color = RED;

    balancearInsercion(nuevo);
    ultimoInsertado = nuevo;
}

void ArbolRojoNegro::insertar(int valor, string codPais, string codHotel, string numPiso, string tipoCuarto, string numCamas, string anho, string precioHab, string estadoHab) {
    NodoRB* nuevo = new NodoRB(valor, codPais, codHotel, numPiso, tipoCuarto, numCamas, anho, precioHab, estadoHab);
    nuevo->padre = TNULL;

    NodoRB* y = TNULL;
    NodoRB* x = raiz;

    while (x != TNULL) {
        y = x;
        if (nuevo->valor < x->valor) {
            x = x->izquierda;
        }
        else {
            x = x->derecha;
        }
    }

    nuevo->padre = y;
    if (y == TNULL) {
        raiz = nuevo;
    }
    else if (nuevo->valor < y->valor) {
        y->izquierda = nuevo;
    }
    else {
        y->derecha = nuevo;
    }

    nuevo->izquierda = TNULL;
    nuevo->derecha = TNULL;
    nuevo->color = RED;

    balancearInsercion(nuevo);
    ultimoInsertado = nuevo;
}

void ArbolRojoNegro::borrar(int valor) {
    NodoRB* nodo = buscar(raiz, valor);
    if (nodo == TNULL) {
        cout << "Nodo no encontrado." << endl;
        return;
    }
    NodoRB* y = nodo;
    Color yOriginalColor = y->color;
    NodoRB* x;

    if (nodo->izquierda == TNULL) {
        x = nodo->derecha;
        transplantar(nodo, nodo->derecha);
    }
    else if (nodo->derecha == TNULL) {
        x = nodo->izquierda;
        transplantar(nodo, nodo->izquierda);
    }
    else {
        y = encontrarMinimo(nodo->derecha);
        yOriginalColor = y->color;
        x = y->derecha;
        if (y->padre == nodo) {
            x->padre = y;
        }
        else {
            transplantar(y, y->derecha);
            y->derecha = nodo->derecha;
            y->derecha->padre = y;
        }
        transplantar(nodo, y);
        y->izquierda = nodo->izquierda;
        y->izquierda->padre = y;
        y->color = nodo->color;
    }
    delete nodo;
    if (yOriginalColor == BLACK) {
        balancearBorrado(x);
    }
}

NodoRB* ArbolRojoNegro::obtenerUltimoInsertado() {
    return ultimoInsertado;
}

bool ArbolRojoNegro::buscar(int clave) {
    return buscar(raiz, clave) != TNULL;
}

void ArbolRojoNegro::inOrdenH() {
    inOrdenHelperH(raiz);
}

void ArbolRojoNegro::inOrdenC() {
    inOrdenHelperC(raiz);
}

void ArbolRojoNegro::leerHabitacion(const string& nombreArchivo) {

    ifstream archivo(nombreArchivo);

    if (!archivo.is_open()) {
        cerr << "No se pudo abrir el archivo: " << nombreArchivo << endl;
        return;
    }

    archivo.seekg(0, ios::end);
    streampos tamano = archivo.tellg();
    archivo.seekg(0, ios::beg);

    if (tamano == 0) {
        cout << "El archivo est� vac�o." << endl;
        archivo.close();
        return;
    }

    int i = 0;

    NodoRB* aux = raiz;
    string linea;

    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string campo, codPais, codHotel, numPiso, tipoCuarto, numCamas, precioHab, estadoHab;
        int valor = -1;
        int campoNum = 0;

        i = -1;
        while (getline(ss, campo, ';')) {
            if (i == -1)
            {
                codPais = campo;
            }
            else if (i == 0)
            {
                codHotel = campo;
            }
            else if (i == 1)
            {
                numPiso = campo;
            }
            else if (i == 2)
            {
                campoNum = stoi(campo);
                valor = campoNum;
            }
            else if (i == 3)
            {
                tipoCuarto = campo;
            }
            else if (i == 4)
            {
                numCamas = campo;
            }
            else if (i == 5)
            {
                precioHab = campo;
            }
            else if (i == 6)
            {
                estadoHab = campo;
            }
            i++;
        }
        if (valor != -1)
        {
            insertar(valor, codPais, codHotel, numPiso, tipoCuarto, numCamas, precioHab, estadoHab);
        }
    }
    archivo.close();
}

void ArbolRojoNegro::leerCarros(const string& nombreArchivo) {

    ifstream archivo(nombreArchivo);

    if (!archivo.is_open()) {
        cerr << "No se pudo abrir el archivo: " << nombreArchivo << endl;
        return;
    }

    archivo.seekg(0, ios::end);
    streampos tamano = archivo.tellg();
    archivo.seekg(0, ios::beg);

    if (tamano == 0) {
        cout << "El archivo est� vac�o." << endl;
        archivo.close();
        return;
    }

    int i = 0;

    NodoRB* aux = raiz;
    string linea;

    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string campo, codPais, codHotel, numPiso, tipoCuarto, numCamas, anho, precioHab, estadoHab;
        int valor = -1;
        int campoNum = 0;

        i = -1;
        while (getline(ss, campo, ';')) {
            if (i == -1)
            {
                codPais = campo;
            }
            else if (i == 0)
            {
                codHotel = campo;
            }
            else if (i == 1)
            {
                numPiso = campo;
            }
            else if (i == 2)
            {
                campoNum = stoi(campo);
                valor = campoNum;
            }
            else if (i == 3)
            {
                tipoCuarto = campo;
            }
            else if (i == 4)
            {
                numCamas = campo;
            }
            else if (i == 5)
            {
                anho = campo;
            }
            else if (i == 6)
            {
                precioHab = campo;
            }
            else if (i == 7)
            {
                estadoHab = campo;
            }
            i++;
        }
        if (valor != -1)
        {
            insertar(valor, codPais, codHotel, numPiso, tipoCuarto, numCamas, anho, precioHab, estadoHab);
        }
    }
    archivo.close();
}

void ArbolRojoNegro::insertarHabitacion(ArbolAA& paises, ABB& hoteles, ArbolAVL& pisos) {

    string cod, pais;
    string numP;
    string codH;
    string tipo;
    string numC;
    string precio;
    string estado;

    cout << "Acontinuacion se le pedira que ingrese toda la informacion de la nueva habitacion." << endl << endl;

    cout << "Inserte Codigo Pais: ";
    cin >> pais;
    if (esNumero(pais) == false || !paises.buscar(stoi(pais))) {
        cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte Codigo Hotel: ";
    cin >> cod;
    if (esNumero(cod) == false || !hoteles.buscar(stoi(cod))) {
        cout << endl << "Error, el codigo debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte Numero de Piso: ";
    cin >> numP;
    if (esNumero(numP) == false || !pisos.buscar(stoi(numP))) {
        cout << endl << "Error, el numero de piso debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte Codigo de Habitacion: ";
    cin >> codH;
    if (esNumero(codH) == false || buscar(stoi(codH))) {
        cout << endl << "Error, el codigo de habitacion debe ser un numero que no este registrado." << endl << endl;
        return;
    }

    cout << "Inserte Tipo de Cuarto: ";
    cin >> tipo;

    cout << "Inserte Numero de Camas: ";
    cin >> numC;
    if (esNumero(numC) == false) {
        cout << endl << "Error, el numero de camas debe ser un numero." << endl << endl;
        return;
    }

    cout << "Inserte Precio Habitaciones: ";
    cin >> precio;
    if (esNumero(precio) == false) {
        cout << endl << "Error, el precio de habitaciones debe ser un numero." << endl << endl;
        return;
    }

    cout << "Inserte Estado Habitaciones: ";
    cin >> estado;
    if (estado != "R" && estado != "L" && estado != "O") {
        cout << endl << "Error, el estado de habitaciones debe ser R, L, O." << endl << endl;
        return;
    }
    cout << endl;

    insertar(stoi(codH), pais, cod, numP, tipo, numC, precio, estado);

    cout << "Habitacion insertada con exito." << endl << endl;
    return;
}

void ArbolRojoNegro::insertarCarro(ArbolAA& paises, ABB& agencias, ArbolAVL& flotillas) {

    string cod, pais;
    string numP;
    string codH;
    string tipo;
    string numC;
    string anho;
    string precio;
    string estado;

    cout << "Acontinuacion se le pedira que ingrese toda la informacion del nuevo carro." << endl << endl;

    cout << "Inserte Codigo Pais: ";
    cin >> pais;
    if (esNumero(pais) == false || !paises.buscar(stoi(pais))) {
        cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte Identificacion Agencia: ";
    cin >> cod;
    if (esNumero(cod) == false || !agencias.buscar(stoi(cod))) {
        cout << endl << "Error, la identificacion debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte Numero de Tipo Flotilla: ";
    cin >> numP;
    if (esNumero(numP) == false || !flotillas.buscar(stoi(numP))) {
        cout << endl << "Error, el numero de tipo flotilla debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte Placa de Carro: ";
    cin >> codH;
    if (esNumero(codH) == false || buscar(stoi(codH))) {
        cout << endl << "Error, la placa del carro debe ser un numero." << endl << endl;
        return;
    }

    cout << "Inserte Modelo de Carro: ";
    cin >> tipo;

    cout << "Inserte Numero de Asientos: ";
    cin >> numC;
    if (esNumero(numC) == false) {
        cout << endl << "Error, el numero de asientos debe ser un numero." << endl << endl;
        return;
    }

    cout << "Inserte A�o del Carro: ";
    cin >> anho;
    if (esNumero(anho) == false) {
        cout << endl << "Error, el a�o del carro debe ser un numero." << endl << endl;
        return;
    }

    cout << "Inserte Precio Carro: ";
    cin >> precio;
    if (esNumero(precio) == false) {
        cout << endl << "Error, el precio del carro debe ser un numero." << endl << endl;
        return;
    }

    cout << "Inserte Estado del Carro: ";
    cin >> estado;
    if (estado != "R" && estado != "L" && estado != "O") {
        cout << endl << "Error, el estado de habitaciones debe ser R, L, O." << endl << endl;
        return;
    }
    cout << endl;

    insertar(stoi(codH), pais, cod, numP, tipo, numC, anho, precio, estado);

    cout << "Carro insertado con exito." << endl << endl;
    return;
}

void ArbolRojoNegro::modificarHabitacion(ArbolAA& paises, ABB& hoteles, ArbolAVL& pisos) {
    string cod, pais;
    string codH;
    string codP;
    string verif;
    string nuevo;

    int i = 1;

    cout << "Inserte Codigo Pais: ";
    cin >> pais;
    if (esNumero(pais) == false || !paises.buscar(stoi(pais))) {
        cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte el Codigo del Hotel de la habitacion que desea modificar: ";
    cin >> codH;
    if (esNumero(codH) == false || !hoteles.buscar(stoi(codH))) {
        cout << endl << "Error, el codigo debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte el Numero de Piso de la habitacion que desea modificar: ";
    cin >> codP;
    if (esNumero(codP) == false || !pisos.buscar(stoi(codP))) {
        cout << endl << "Error, el codigo debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte el Codigo de la habitacion que desea modificar: ";
    cin >> cod;
    cout << endl;
    if (esNumero(cod) == false || !buscar(stoi(cod))) {
        cout << endl << "Error, el codigo debe ser un numero y debe existir." << endl << endl;
        return;
    }

    else
    {
        cout << "               1. Tipo Cuarto" << endl << "               2. Numero Camas" << endl << "               3. Precio" << endl << "               4. Estado" << endl << endl;
        cout << "Inserte el numero de lo que desea modificar: ";
        cin >> verif;
        cout << endl;
        if (verif == "1") {
            cout << "Inserte el nuevo tipo de cuarto: ";
            cin >> nuevo;
            cout << endl;
            NodoRB* nodo = buscar(raiz, stoi(cod));
            if (nodo->codHotel == codH && nodo->numPiso == codP && nodo->valor == stoi(cod))
            {
                nodo->tipoCuarto = nuevo;
                cout << "Se modifico con exito." << endl << endl;
                return;
            }
            cout << "Error, no hay numero de piso con ese codigo hotel" << endl << endl;
            return;
        }
        else if (verif == "2") {
            cout << "Inserte el nuevo Numero de Camas: ";
            cin >> nuevo;
            cout << endl;
            if (esNumero(nuevo) == false) {
                cout << endl << "Error, debe ser un numero." << endl << endl;
                return;
            }
            NodoRB* nodo = buscar(raiz, stoi(cod));
            if (nodo->codHotel == codH && nodo->numPiso == codP && nodo->valor == stoi(cod))
            {
                nodo->numCamas = nuevo;
                cout << "Se modifico con exito." << endl << endl;
                return;
            }
            cout << "Error, no hay numero de piso con ese codigo hotel" << endl << endl;
            return;
        }
        else if (verif == "3") {
            cout << "Inserte el nuevo Precio: ";
            cin >> nuevo;
            cout << endl;
            if (esNumero(nuevo) == false) {
                cout << endl << "Error, debe ser un numero." << endl << endl;
                return;
            }
            NodoRB* nodo = buscar(raiz, stoi(cod));
            if (nodo->codHotel == codH && nodo->numPiso == codP && nodo->valor == stoi(cod))
            {
                nodo->precioHab = nuevo;
                cout << "Se modifico con exito." << endl << endl;
                return;
            }
            cout << "Error, no hay numero de piso con ese codigo hotel" << endl << endl;
            return;
        }
        else if (verif == "4") {
            cout << "Inserte el nuevo Estado: ";
            cin >> nuevo;
            cout << endl;
            if (nuevo != "R" && nuevo != "L" && nuevo != "O") {
                cout << endl << "Error, el estado de habitaciones debe ser R, L, O." << endl << endl;
                return;
            }
            NodoRB* nodo = buscar(raiz, stoi(cod));
            if (nodo->codHotel == codH && nodo->numPiso == codP && nodo->valor == stoi(cod))
            {
                nodo->estadoHab = nuevo;
                cout << "Se modifico con exito." << endl << endl;
                return;
            }
            cout << "Error, no hay numero de piso con ese codigo hotel" << endl << endl;
            return;
        }
        else
        {
            cout << endl << "Error, solo se puede ingresar un numero de los anteriores." << endl << endl;
            return;
        }
    }
}

void ArbolRojoNegro::modificarCarro(ArbolAA& paises, ABB& agencias, ArbolAVL& flotillas) {
    string cod, pais;
    string codH;
    string codP;
    string verif;
    string nuevo;

    int i = 1;

    cout << "Inserte Codigo Pais: ";
    cin >> pais;
    if (esNumero(pais) == false || !paises.buscar(stoi(pais))) {
        cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte el Codigo de la agencia del carro que desea modificar: ";
    cin >> codH;
    if (esNumero(codH) == false || !agencias.buscar(stoi(codH))) {
        cout << endl << "Error, el codigo debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte el Codigo del tipo flotilla del carro que desea modificar: ";
    cin >> codP;
    if (esNumero(codP) == false || !flotillas.buscar(stoi(codP))) {
        cout << endl << "Error, el codigo debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte el numero de placa del carro que desea modificar: ";
    cin >> cod;
    cout << endl;
    if (esNumero(cod) == false || !buscar(stoi(cod))) {
        cout << endl << "Error, el codigo debe ser un numero y debe existir." << endl << endl;
        return;
    }

    else
    {
        cout << "               1. Num asientos" << endl << "               2. Precio" << endl << "               3. Estado" << endl << endl;
        cout << "Inserte el numero de lo que desea modificar: ";
        cin >> verif;
        cout << endl;
        if (verif == "1") {
            cout << "Inserte el nuevo Numero de asientos: ";
            cin >> nuevo;
            cout << endl;
            NodoRB* nodo = buscar(raiz, stoi(cod));
            if (nodo->codHotel == codH && nodo->numPiso == codP && nodo->valor == stoi(cod))
            {
                nodo->numCamas = nuevo;
                cout << "Se modifico con exito." << endl << endl;
                return;
            }
            cout << "Error, no hay tipo Flotilla con ese codigo de agencia" << endl << endl;
            return;
        }
        else if (verif == "2") {
            cout << "Inserte el nuevo Precio: ";
            cin >> nuevo;
            cout << endl;
            if (esNumero(nuevo) == false) {
                cout << endl << "Error, debe ser un numero." << endl << endl;
                return;
            }
            NodoRB* nodo = buscar(raiz, stoi(cod));
            if (nodo->codHotel == codH && nodo->numPiso == codP && nodo->valor == stoi(cod))
            {
                nodo->precioHab = nuevo;
                cout << "Se modifico con exito." << endl << endl;
                return;
            }
            cout << "Error, no hay tipo Flotilla con ese codigo de agencia" << endl << endl;
            return;
        }
        else if (verif == "3") {
            cout << "Inserte el nuevo Estado: ";
            cin >> nuevo;
            cout << endl;
            if (nuevo != "R" && nuevo != "L" && nuevo != "O") {
                cout << endl << "Error, el estado de carro debe ser R, L, O." << endl << endl;
                return;
            }
            NodoRB* nodo = buscar(raiz, stoi(cod));
            if (nodo->codHotel == codH && nodo->numPiso == codP && nodo->valor == stoi(cod))
            {
                nodo->estadoHab = nuevo;
                cout << "Se modifico con exito." << endl << endl;
                return;
            }
            cout << "Error, no hay tipo Flotilla con ese codigo de agencia" << endl << endl;
            return;
        }
        else
        {
            cout << endl << "Error, solo se puede ingresar un numero de los anteriores." << endl << endl;
            return;
        }
    }
}

bool ArbolRojoNegro::buscarCodH(NodoRB* nodo, const string& codHotel) {
    if (nodo == TNULL)
        return false;

    if (nodo->codHotel == codHotel)
        return true;

    // Buscar en el sub�rbol izquierdo y derecho
    if (buscarCodH(nodo->izquierda, codHotel))
        return true;

    return buscarCodH(nodo->derecha, codHotel);
}


bool ArbolRojoNegro::buscarHotel(NodoRB* nodo, const string& codHotel) {
    if (nodo == TNULL) {
        return false; // Si se alcanza un nodo nulo, no se encontr� el hotel
    }
    // Comparar el c�digo de hotel
    if (nodo->codHotel == codHotel) {
        return true; // Se encontr� el hotel
    }

    if (buscarHotel(nodo->izquierda, codHotel)) {
        return true;
    }
    // Buscar en el sub�rbol derecho
    if (buscarHotel(nodo->derecha, codHotel)) {
        return true;
    }
    return false; // Si no lo encontr� en ninguna de las ramas
}

bool ArbolRojoNegro::buscarPiso(NodoRB* nodo, const string& numPiso) {
    if (nodo == TNULL) {
        return false; // Si se alcanza un nodo nulo, no se encontr� el piso
    }
    // Comparar el n�mero de piso
    if (nodo->numPiso == numPiso) {
        return true; // Se encontr� el piso
    }
    // Recorrer recursivamente los sub�rboles izquierdo y derecho
    return buscarPiso(nodo->izquierda, numPiso) || buscarPiso(nodo->derecha, numPiso);
}

NodoRB* ArbolRojoNegro::buscarCarro(NodoRB* nodo, int valor) {
    if (nodo == TNULL || nodo->valor == valor) {
        return nodo;
    }
    if (valor < nodo->valor) {
        return buscar(nodo->izquierda, valor);
    }
    else {
        return buscar(nodo->derecha, valor);
    }
}

bool ArbolRojoNegro::buscarPais(NodoRB* nodo, const string& pais) {
    if (nodo == TNULL) {
        return false; // Si llega al nodo nulo, no encontr� el pa�s
    }
    if (nodo->codPais == pais) {
        return true; // Si encuentra un nodo con el codPais
    }
    // Buscar en el sub�rbol izquierdo
    if (buscarPais(nodo->izquierda, pais)) {
        return true;
    }
    // Buscar en el sub�rbol derecho
    if (buscarPais(nodo->derecha, pais)) {
        return true;
    }
    return false; // Si no lo encontr� en ninguna de las ramas
}

void ArbolRojoNegro::consultarHab() {
    NodoRB* aux = raiz;
    string codP;
    string codH;
    string verif;

    cout << "Inserte el codigo del pais del piso que desea saber su info: ";
    cin >> codP;
    cout << endl;

    if (buscarPais(raiz, codP) == false) {
        cout << endl << "Error, el codigo de pais no existe." << endl << endl;
        return;
    }

    // Validar que el c�digo de hotel sea un n�mero
    if (!esNumero(codP)) {
        cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
        return;
    }

    // Solicitar el c�digo de hotel y el piso
    cout << "Inserte el codigo de hotel del piso que desea saber su info: ";
    cin >> codH;
    cout << endl;

    // Validar que el c�digo de hotel sea un n�mero
    if (!esNumero(codH)) {
        cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
        return;
    }

    if (buscarHotel(raiz, codH) == false) {
        cout << endl << "Error, el codigo de hotel no existe." << endl << endl;
        return;
    }

    // Solicitar el n�mero del piso
    cout << "Inserte el numero de piso de la habitacion que desea saber su info: ";
    cin >> verif;
    cout << endl;

    // Validar que el n�mero de piso sea un n�mero
    if (!esNumero(verif)) {
        cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
        return;
    }

    if (buscarPiso(raiz, verif) == false) {
        cout << endl << "Error, el numero de piso del hotel no existe." << endl << endl;
        return;
    }

    int numPiso = stoi(verif);

    // Buscar la habitaci�n en el �rbol
    NodoRB* resultado = buscarHab(raiz, codH, numPiso);

    if (resultado == nullptr) {
        cout << "Error, no hay ninguna habitacion con ese numero de piso." << endl << endl;
        return;
    }

    // Mostrar informaci�n de la habitaci�n encontrada
    string texto;

    cout << "Codigo Pa�s: " << resultado->codPais << endl;
    texto = "Codigo de Pa�s: " + resultado->codPais + "\n";

    cout << "Codigo Hotel: " << resultado->codHotel << endl;
    texto = "Codigo de Hotel: " + resultado->codHotel + "\n";

    cout << "Numero de Piso: " << resultado->numPiso << endl;
    texto += "Numero de Piso: " + resultado->numPiso + "\n";

    cout << "Tipo Cuarto: " << resultado->tipoCuarto << endl;
    texto += "Tipo Cuarto: " + resultado->tipoCuarto + "\n";

    cout << "Numero Camas: " << resultado->numCamas << endl;
    texto += "Numero Camas: " + resultado->numCamas + "\n";

    cout << "Precio habitacion: " << resultado->precioHab << endl;
    texto += "Precio habitacion: " + resultado->precioHab + "\n";

    cout << "Estado Habitacion: " << resultado->estadoHab << endl << endl;
    texto += "Estado Habitacion: " + resultado->estadoHab + "\n\n";

    guardarReporte("consultarHab.txt", texto);

    cout << endl;
}

NodoRB* ArbolRojoNegro::buscarHab(NodoRB* nodo, const string& codHotel, int numPiso) {
    if (nodo == TNULL || (nodo->codHotel == codHotel && stoi(nodo->numPiso) == numPiso)) {
        return nodo; // Si encuentra el nodo o llega al nodo nulo (hoja)
    }

    if (stoi(nodo->numPiso) > numPiso) {
        return buscarHab(nodo->izquierda, codHotel, numPiso); // Buscar en el sub�rbol izquierdo
    }
    else {
        return buscarHab(nodo->derecha, codHotel, numPiso); // Buscar en el sub�rbol derecho
    }
}

void ArbolRojoNegro::consultarCarrosT() {
    NodoRB* aux = raiz;
    string codP;
    string codH;
    string verif;

    cout << "Inserte el codigo del pais del tipo flotilla que desea saber su info: ";
    cin >> codP;
    cout << endl;

    if (!esNumero(codP)) {
        cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
        return;
    }

    if (buscarPais(raiz, codP) == false) {
        cout << endl << "Error, el codigo de pais no existe." << endl << endl;
        return;
    }

    cout << "Inserte el codigo del tipo flotilla del carro que desea saber su info: ";
    cin >> codH;
    cout << endl;

    // Validar que el c�digo de hotel sea un n�mero
    if (!esNumero(codH)) {
        cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
        return;
    }

    if (buscarHotel(raiz, codH) == false) {
        cout << endl << "Error, el codigo de tipo flotilla no existe." << endl << endl;
        return;
    }

    // Solicitar el n�mero del piso
    cout << "Inserte el numero de placa del carro que desea saber su info: ";
    cin >> verif;
    cout << endl;

    // Validar que el n�mero de piso sea un n�mero
    if (!esNumero(verif)) {
        cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
        return;
    }

    if (buscarPiso(raiz, verif) == false) {
        cout << endl << "Error, el numero de placa del carro no existe." << endl << endl;
        return;
    }

    int numPiso = stoi(verif);

    // Buscar la habitaci�n en el �rbol
    NodoRB* resultado = buscarHab(raiz, codH, numPiso);

    if (resultado == nullptr) {
        cout << "Error, no hay ningun carro con ese numero de placa." << endl << endl;
        return;
    }

    // Mostrar informaci�n de la habitaci�n encontrada
    string texto;

    cout << "Codigo Pa�s: " << resultado->codPais << endl;
    texto = "Codigo de Pa�s: " + resultado->codPais + "\n";

    cout << "Codigo Agencia: " << resultado->codHotel << endl;
    texto = "Codigo de Agencia: " + resultado->codHotel + "\n";

    cout << "Numero de Tipo Flotilla: " << resultado->numPiso << endl;
    texto += "Numero de Tipo Flotilla: " + resultado->numPiso + "\n";

    cout << "Tipo Carro: " << resultado->tipoCuarto << endl;
    texto += "Tipo Carro: " + resultado->tipoCuarto + "\n";

    cout << "Numero Asientos: " << resultado->numCamas << endl;
    texto += "Numero Asientos: " + resultado->numCamas + "\n";

    cout << "Precio carro: " << resultado->precioHab << endl;
    texto += "Precio carro: " + resultado->precioHab + "\n";

    cout << "Estado Carro: " << resultado->estadoHab << endl << endl;
    texto += "Estado Carro: " + resultado->estadoHab + "\n\n";

    guardarReporte("consultarCarro.txt", texto);

    cout << endl;
}

void ArbolRojoNegro::ultimo() {
    NodoRB* nodo = obtenerUltimoInsertado();
    string texto = "Ultima Habitacion registrada: \n";

    //cout << "Codigo Pais: " << nodo->codPais << endl;
    //texto += "Codigo Pais: " + nodo->codPais + "\n";

    //cout << "Codigo Hotel: " << nodo->codHotel << endl;
    //texto += "Codigo Hotel: " + nodo->codHotel + "\n";

    //cout << "Numero de Piso: " << nodo->numPiso << endl;
    //texto += "Numero de Piso: " + nodo->numPiso + "\n";

    texto += "Codigo de habitacion: " + to_string(nodo->valor) + "\n";

    cout << texto << endl;
    guardarReporte("consultarUltHab.txt", texto);
}

void ArbolRojoNegro::ultimoC() {
    NodoRB* nodo = obtenerUltimoInsertado();
    string texto = "Ultimo Carro registrado: \n";

    //cout << "Codigo Pais: " << nodo->codPais << endl;
    //texto += "Codigo Pais: " + nodo->codPais + "\n";

    //cout << "Codigo Hotel: " << nodo->codHotel << endl;
    //texto += "Codigo Hotel: " + nodo->codHotel + "\n";

    //cout << "Numero de Piso: " << nodo->numPiso << endl;
    //texto += "Numero de Piso: " + nodo->numPiso + "\n";

    texto += "Placa: " + to_string(nodo->valor) + "\n";

    cout << texto << endl;
    guardarReporte("consultarUltCarro.txt", texto);
}

void ArbolRojoNegro::cantidadAsientos() {
    NodoRB* aux = raiz;
    string codP;
    string codH;
    string placa;
    string verif, texto;

    cout << "Inserte el codigo del pais del carro que desea saber su info: ";
    cin >> codP;
    cout << endl;

    if (!esNumero(codP)) {
        cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
        return;
    }

    if (buscarPais(raiz, codP) == false) {
        cout << endl << "Error, el codigo de pais no existe." << endl << endl;
        return;
    }

    cout << "Inserte el codigo de la agencia del carro del que desea saber su cantidad de asientos: ";
    cin >> codH;
    cout << endl;

    if (buscarCodH(raiz, codH) == false)
    {
        cout << "Error, no hay ningun tipo flotilla con ese codigo de agencia." << endl << endl;
        return;
    }

    cout << "Inserte el codigo del tipo flotilla del carro que desea saber su cantidad de asientos: ";
    cin >> verif;
    cout << endl;

    if (buscarPiso(raiz, verif) == false)
    {
        cout << "Error, no hay ningun tipo flotilla con ese codigo." << endl << endl;
        return;
    }

    cout << "Inserte la placa del carro que desea saber su cantidad de asientos: ";
    cin >> placa;
    cout << endl;

    if (buscarCarro(raiz, stoi(placa)) == nullptr)
    {
        cout << "Error, no hay ningun carro con esa placa." << endl << endl;
        return;
    }

    cantidadAsientosAux(raiz, placa);
}

void ArbolRojoNegro::cantidadAsientosAux(NodoRB* nodo, string placa) {
    string texto;
    int p = stoi(placa);
    if (nodo->valor == p)
    {
        texto = "Cantidad de asientos: " + nodo->codHotel + "\n" + "\n";
        cout << texto;
        guardarReporte("cantidadAsientos.txt", texto);
        return;
    }
    if (p < nodo->valor) {
        cantidadAsientosAux(nodo->izquierda, placa);
    }
    else {
        cantidadAsientosAux(nodo->derecha, placa);
    }
}*/