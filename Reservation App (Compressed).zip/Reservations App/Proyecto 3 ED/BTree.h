#include "NodoB.h"
#include <iostream>
#include <string>
using namespace std;
class BTree {
private:
	NodoB* raiz; // Puntero a la raíz
	int t;       // Grado mínimo

public:
	BTree(int t);

	void insertar(int k, const string& codPais, const string& nombre);

	bool buscarPorID(string id);
	void borrar(int k);
	string recorrer();
	string graficar();
	string consultarClientes();
	bool leerClientes_Admins(const string& nombreArchivo);

	NodoB* buscar(int k);

};