#pragma once
#include <iostream>
#include <string>
using namespace std;
class NodoB { //------------------------------------------------------------------------- BTREE -----------------------------------------------------------------------------------------
private:
	int* claves;
	int t;
	NodoB** hijos;
	int n;
	bool hoja;

	string* nombres; // Arreglo para almacenar los nombres
	string* codPaises; // Arreglo para almacenar los códigos de país

public:
	NodoB(int t, bool hoja);

	void insertarNoLleno(int k, const string& codPais, const string& nombre);
	void dividirHijo(int i, NodoB* y);
	string recorrer();
	string graficar(int nivel = 0);
	NodoB* buscar(int k);

	friend class BTree;
};