#pragma once
#include "ArbolBinario.h"
#include "prueba.h"
#include "listaSimple.h"