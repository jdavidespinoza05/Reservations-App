#include "pch.h"
#include "ABB.h"

void ABB::insertar(NodoABB*& nodo, int valor, const string& pais, const string& nom, const string& cantidad) {
    if (nodo == nullptr) {
        nodo = new NodoABB(valor, pais, nom, cantidad);
        ultimoInsertado = nodo;
    }
    else if (valor < nodo->valor) {
        insertar(nodo->izquierda, valor, pais, nom, cantidad);
    }
    else if (valor > nodo->valor) {
        insertar(nodo->derecha, valor, pais, nom, cantidad);
    }
}

NodoABB* ABB::buscar(NodoABB* nodo, int clave) {
    if (nodo == nullptr || nodo->valor == clave)
        return nodo;
    if (clave < nodo->valor)
        return buscar(nodo->izquierda, clave);
    else
        return buscar(nodo->derecha, clave);
}

NodoABB* ABB::borrar(NodoABB*& nodo, int valor) {
    if (nodo == nullptr) {
        return nullptr;
    }
    if (valor < nodo->valor) {
        nodo->izquierda = borrar(nodo->izquierda, valor);
    }
    else if (valor > nodo->valor) {
        nodo->derecha = borrar(nodo->derecha, valor);
    }
    else {
        if (nodo->izquierda == nullptr) {
            NodoABB* temp = nodo->derecha;
            delete nodo;
            return temp;
        }
        else if (nodo->derecha == nullptr) {
            NodoABB* temp = nodo->izquierda;
            delete nodo;
            return temp;
        }
        NodoABB* temp = encontrarMinimo(nodo->derecha);
        nodo->valor = temp->valor;
        nodo->codPais = temp->codPais;
        nodo->nombre = temp->nombre;
        nodo->cantidadEst = temp->cantidadEst;
        nodo->derecha = borrar(nodo->derecha, temp->valor);
    }
    return nodo;
}

NodoABB* ABB::encontrarMinimo(NodoABB* nodo) {
    while (nodo && nodo->izquierda != nullptr) {
        nodo = nodo->izquierda;
    }
    return nodo;
}

void ABB::recorridoInordenH(NodoABB* nodo) {
    if (nodo != nullptr) {
        recorridoInordenH(nodo->izquierda);
        nodo->mostrarH(); // Mostrar detalles del nodo
        recorridoInordenH(nodo->derecha);
    }
}

void ABB::recorridoInordenA(NodoABB* nodo) {
    if (nodo != nullptr) {
        recorridoInordenA(nodo->izquierda);
        nodo->mostrarA(); // Mostrar detalles del nodo
        recorridoInordenA(nodo->derecha);
    }
}

// Definici�n del constructor y m�todos p�blicos
ABB::ABB() : raiz(nullptr) {}

void ABB::insertar(int valor, const string& pais, const string& nom, const string& cantidad) {
    insertar(raiz, valor, pais, nom, cantidad);
}

bool ABB::buscar(int valor) {
    return buscar(raiz, valor) != nullptr;
}

void ABB::borrar(int valor) {
    raiz = borrar(raiz, valor);
}

void ABB::recorridoInordenH() {
    recorridoInordenH(raiz);
    cout << endl;
}

void ABB::recorridoInordenA() {
    recorridoInordenA(raiz);
    cout << endl;
}

NodoABB* ABB::obtenerUltimoInsertado() {
    return ultimoInsertado;
}

void ABB::leerHotel_Agencia(const string& nombreArchivo) {

    ifstream archivo(nombreArchivo);

    if (!archivo.is_open()) {
        cerr << "No se pudo abrir el archivo: " << nombreArchivo << endl;
        return;
    }

    archivo.seekg(0, ios::end); //Mover el puntero al final del archivo 
    streampos tamano = archivo.tellg(); //Obtener la posici�n del puntero (tama�o del archivo) 
    archivo.seekg(0, ios::beg); //Volver al principio del archivo 

    if (tamano == 0) {
        cout << "El archivo est� vac�o." << endl;
        archivo.close();
        return;
    }

    int i = 0;

    NodoABB* aux = raiz;
    string linea;

    while (getline(archivo, linea)) { // Lee l�nea por l�nea
        stringstream ss(linea); // Usa un stringstream para procesar la l�nea
        string campo, codPais, nombre, cantidadEst;
        int valor = -1;
        int campoNum;

        i = -1;
        while (getline(ss, campo, ';')) { // Separa la l�nea por el delimitador ';'

            if (i == -1)
            {
                codPais = campo;
            }
            else if (i == 0)
            {
                campoNum = stoi(campo);
                valor = campoNum;
            }
            else if (i == 1)
            {
                nombre = campo;
            }
            else if (i == 2)
            {
                cantidadEst = campo;
            }
            i++;
        }
        if (valor != -1)
        {
            insertar(valor, codPais, nombre, cantidadEst);
        }
    }

    archivo.close(); // Cierra el archivo
}
/*
void ABB::insertarHotel(ArbolAA& paises) {

    string cod, pais;
    string nom;
    string est;

    cout << "Acontinuacion se le pedira que ingrese toda la informacion del nuevo hotel." << endl << endl;

    cout << "Inserte Codigo Pais: ";
    cin >> pais;
    if (esNumero(pais) == false || !paises.buscar(stoi(pais))) {
        cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte Codigo Hotel: ";
    cin >> cod;
    if (esNumero(cod) == false || buscar(stoi(cod))) {
        cout << endl << "Error, el codigo debe ser un numero y no debe estar registrado." << endl << endl;
        return;
    }

    cout << "Inserte Nombre: ";
    cin >> nom;

    cout << "Inserte Cantidad de Estrellas: ";
    cin >> est;
    if (esNumero(est) == false) {
        cout << endl << "Error, la cantidad de estrellas debe ser un numero." << endl << endl;
        return;
    }
    cout << endl;

    insertar(stoi(cod), pais, nom, est);
    cout << "Hotel insertado con exito." << endl << endl;
    return;

}

void ABB::insertarAgencia(ArbolAA& paises) {

    string cod, pais;
    string nom;
    string est;

    cout << "Acontinuacion se le pedira que ingrese toda la informacion de la nueva agencia." << endl << endl;

    cout << "Inserte Codigo Pais: ";
    cin >> pais;
    if (esNumero(pais) == false || !paises.buscar(stoi(pais))) {
        cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
        return;
    }


    cout << "Inserte Identificacion: ";
    cin >> cod;
    if (esNumero(cod) == false || buscar(stoi(cod))) {
        cout << endl << "Error, la identificacion debe ser un numero y no debe existir.." << endl << endl;
        return;
    }

    cout << "Inserte Nombre: ";
    cin >> nom;

    cout << "Inserte Cantidad de Vehiculos: ";
    cin >> est;
    if (esNumero(est) == false) {
        cout << endl << "Error, la cantidad de vehiculos debe ser un numero." << endl << endl;
        return;
    }
    cout << endl;

    insertar(stoi(cod), pais, nom, est);

    cout << "Agencia insertada con exito." << endl << endl;
    return;

}

void ABB::modificarHotel(ArbolAA& paises) {
    string cod, pais;
    string verif;
    string nuevo;

    int i = 1;

    cout << "Inserte Codigo Pais: ";
    cin >> pais;
    if (esNumero(pais) == false || !paises.buscar(stoi(pais))) {
        cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte el Codigo del Hotel que desea modificar: ";
    cin >> cod;
    cout << endl;
    if (esNumero(cod) == false || !buscar(stoi(cod))) {
        cout << endl << "Error, el codigo debe ser un numero y debe existir." << endl << endl;
        return;
    }

    else
    {
        cout << "               1. Nombre" << endl << "               2. Estrellas" << endl << endl;
        cout << "Inserte el numero de lo que desea modificar: ";
        cin >> verif;
        cout << endl;
        if (verif == "1") {
            cout << "Inserte el nuevo Nombre: ";
            cin >> nuevo;
            cout << endl;
            NodoABB* nodo = buscar(raiz, stoi(cod));
            nodo->nombre = nuevo;
            cout << "Se modifico con exito." << endl << endl;
            return;
        }
        else if (verif == "2") {
            cout << "Inserte el nuevo Numero de Estrellas: ";
            cin >> nuevo;
            cout << endl;
            if (esNumero(nuevo) == false) {
                cout << endl << "Error, debe ser un numero." << endl << endl;
                return;
            }
            NodoABB* nodo = buscar(raiz, stoi(cod));
            nodo->cantidadEst = nuevo;
            cout << "Se modifico con exito." << endl << endl;
            return;
        }
        else
        {
            cout << endl << "Error, solo se puede ingresar un numero de los anteriores." << endl << endl;
            return;
        }
    }
}

void ABB::modificarAgencia(ArbolAA& paises) {
    string cod, pais;
    string verif;
    string nuevo;

    int i = 1;

    cout << "Inserte Codigo Pais: ";
    cin >> pais;
    if (esNumero(pais) == false || !paises.buscar(stoi(pais))) {
        cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
        return;
    }

    cout << "Inserte la Identificacion de la Agencia que desea modificar: ";
    cin >> cod;
    cout << endl;
    if (esNumero(cod) == false || !buscar(stoi(cod))) {
        cout << endl << "Error, la identificacion debe ser un numero y debe existir." << endl << endl;
        return;
    }

    else
    {
        cout << "               1. Nombre" << endl << "               2. Vehiculos" << endl << endl;
        cout << "Inserte el numero de lo que desea modificar: ";
        cin >> verif;
        cout << endl;
        if (verif == "1") {
            cout << "Inserte el nuevo Nombre: ";
            cin >> nuevo;
            cout << endl;
            NodoABB* nodo = buscar(raiz, stoi(cod));
            nodo->nombre = nuevo;
            cout << "Se modifico con exito." << endl << endl;
            return;
        }
        else if (verif == "2") {
            cout << "Inserte el nuevo Numero de Vehiculos: ";
            cin >> nuevo;
            cout << endl;
            if (esNumero(nuevo) == false) {
                cout << endl << "Error, debe ser un numero." << endl << endl;
                return;
            }
            NodoABB* nodo = buscar(raiz, stoi(cod));
            nodo->cantidadEst = nuevo;
            cout << "Se modifico con exito." << endl << endl;
            return;
        }
        else
        {
            cout << endl << "Error, solo se puede ingresar un numero de los anteriores." << endl << endl;
            return;
        }
    }
}

void ABB::consultarHoteles() {
    recorridoInordenH();
}

bool ABB::buscarPais(NodoABB* nodo, const string& pais) {
    if (nodo == nullptr) {
        return false; // No se encontr� el nodo
    }

    // Comparar el numPiso del nodo actual
    if (nodo->codPais == pais) {
        return true; // Se encontr� el numPiso
    }

    // Buscar en el sub�rbol izquierdo y derecho
    return buscarPais(nodo->izquierda, pais) || buscarPais(nodo->derecha, pais);
}

void ABB::cantidadEst() {
    NodoABB* aux = raiz;  // Asumiendo que 'raiz' es el nodo ra�z del �rbol
    string verifP;
    string verif;

    cout << "Inserte el c�digo del pais del hotel del que desea saber sus estrellas: ";
    cin >> verifP;
    cout << endl;

    if (esNumero(verifP) == false) {
        cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
        return;
    }
    if (buscarPais(raiz, verifP) == false) {
        cout << "Error, no hay ning�n pais con ese c�digo." << endl << endl;
        return;
    }

    cout << "Inserte el c�digo de hotel del que desea saber sus estrellas: ";
    cin >> verif;
    cout << endl;

    if (esNumero(verif) == false) {
        cout << endl << "Error, el codigo debe ser un numero." << endl << endl;
        return;
    }
    int i = stoi(verif);
    if (!buscar(i)) {
        cout << "Error, no hay ning�n hotel con ese c�digo." << endl << endl;
        return;
    }
    cantidadEstAux(raiz, i);
}
// Buscar el hotel en el �rbol
void ABB::cantidadEstAux(NodoABB* nodo, int codH) {
    if (codH == nodo->valor) {
        string texto = "";
        cout << "Codigo Hotel: " << nodo->valor << endl << endl;
        texto = "Codigo Hotel: " + to_string(nodo->valor) + "\n";
        cout << "Cantidad de Estrellas: " << nodo->cantidadEst << endl << endl;
        texto += "Cantidad de Estrellas: " + nodo->cantidadEst + "\n\n";
        guardarReporte("consultarCantEst.txt", texto);
        return;
    }
    else if (codH < nodo->valor) {
        cantidadEstAux(nodo->izquierda, codH); // Navegar hacia la izquierda
    }
    else {
        cantidadEstAux(nodo->derecha, codH); // Navegar hacia la derecha
    }
}

void ABB::consultarAgencias() {
    recorridoInordenA();
}

void ABB::ultimo() {
    NodoABB* ultimo = obtenerUltimoInsertado();
    string texto = "Ultimo hotel registrado:\n";

    //cout << "Codigo de pais: "+ ultimo->codPais << endl;
    //texto += "Codigo de pais: "+ ultimo->codPais +"\n";

    texto += "Codigo de hotel: " + to_string(ultimo->valor) + "\n";
    cout << texto << endl;
    guardarReporte("consultarUltH.txt", texto);

}

void ABB::ultimoA() {                  //---------------------PROBLEMA CON ULTIMO AGENCIA Y ULTIMO HOTEL POR SER MISMOS ATRIBUTOS
    NodoABB* ultimo = obtenerUltimoInsertado();
    string texto = "Ultima Agencia registrada:\n";

    //cout << "Codigo de pais: " + ultimo->codPais << endl;
    //texto += "Codigo de pais: " + ultimo->codPais + "\n";

    texto += "Codigo de Agencia: " + to_string(ultimo->valor) + "\n";

    cout << texto << endl;

    guardarReporte("consultarUltA.txt", texto);
}*/