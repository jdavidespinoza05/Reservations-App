#pragma once
#include "Comun.h"
namespace Proyecto_3_ED {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de ModificarPais2
	/// </summary>
	public ref class ModificarPais2 : public System::Windows::Forms::Form
	{
	private:
		Persona^ persona;
		ArbolBinario^ paises;
		ArbolBinario^ hoteles;
		ArbolBinario^ pisos;
		ArbolBinario^ habitaciones;
		ArbolBinario^ agencias;
		ArbolBinario^ flotillas;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ nombreTB;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ eliminarBTN;
		   ArbolBinario^ carros;
		   int snum;

	public:
		ModificarPais2(Persona^ p, ArbolBinario^ pais, ArbolBinario^ hotel, ArbolBinario^ piso, ArbolBinario^ hab, ArbolBinario^ ag, ArbolBinario^ fl, ArbolBinario^ car, int numero)
		{
			persona = p;
			paises = pais;
			hoteles = hotel;
			pisos = piso;
			habitaciones = hab;
			agencias = ag;
			flotillas = fl;
			carros = car;
			snum = numero;
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~ModificarPais2()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->nombreTB = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->eliminarBTN = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label3->Location = System::Drawing::Point(45, 38);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(99, 17);
			this->label3->TabIndex = 19;
			this->label3->Text = L"Nuevo Nombre";
			// 
			// nombreTB
			// 
			this->nombreTB->BackColor = System::Drawing::Color::White;
			this->nombreTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->nombreTB->ForeColor = System::Drawing::Color::Black;
			this->nombreTB->Location = System::Drawing::Point(162, 38);
			this->nombreTB->Name = L"nombreTB";
			this->nombreTB->Size = System::Drawing::Size(146, 20);
			this->nombreTB->TabIndex = 18;
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(170)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(210)));
			this->button1->FlatAppearance->BorderSize = 0;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->button1->Location = System::Drawing::Point(142, 78);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(83, 24);
			this->button1->TabIndex = 17;
			this->button1->Text = L"CANCEL";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &ModificarPais2::button1_Click);
			// 
			// eliminarBTN
			// 
			this->eliminarBTN->BackColor = System::Drawing::Color::WhiteSmoke;
			this->eliminarBTN->FlatAppearance->BorderColor = System::Drawing::Color::Black;
			this->eliminarBTN->FlatAppearance->BorderSize = 0;
			this->eliminarBTN->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->eliminarBTN->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->eliminarBTN->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(97)), static_cast<System::Int32>(static_cast<System::Byte>(129)),
				static_cast<System::Int32>(static_cast<System::Byte>(154)));
			this->eliminarBTN->Location = System::Drawing::Point(231, 78);
			this->eliminarBTN->Name = L"eliminarBTN";
			this->eliminarBTN->Size = System::Drawing::Size(77, 24);
			this->eliminarBTN->TabIndex = 16;
			this->eliminarBTN->Text = L"OK";
			this->eliminarBTN->UseVisualStyleBackColor = false;
			this->eliminarBTN->Click += gcnew System::EventHandler(this, &ModificarPais2::eliminarBTN_Click);
			// 
			// ModificarPais2
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(170)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(210)));
			this->ClientSize = System::Drawing::Size(355, 137);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->nombreTB);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->eliminarBTN);
			this->Name = L"ModificarPais2";
			this->Text = L"ModificarPais2";
			this->Load += gcnew System::EventHandler(this, &ModificarPais2::ModificarPais2_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void ModificarPais2_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void eliminarBTN_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ resp = nombreTB->Text; // Procesa lo que tiene el cuadro de texto
		if (!String::IsNullOrEmpty(resp)) {
			paises->modificarP(snum, resp);
			MessageBox::Show("El pa�s ha sido modificado.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);
			this->Close();
		}
		else {
			MessageBox::Show("Error, hace falta informaci�n o el formato es incorrecto.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Close();
}
};
}
