#include "pch.h"
#include "listaSimple.h"

// Constructor
listaSimple::listaSimple()
{
    primero = nullptr;  // Inicializamos primero como nullptr en lugar de NULL
}

// Destructor
listaSimple::~listaSimple()
{
    nodo^ aux;

    while (primero) {
        aux = primero;
        primero = primero->siguiente;
        delete aux;  // eliminamos el nodo
    }
    primero = nullptr;
}

// Verifica si la lista est� vac�a
bool listaSimple::vacio()
{
    return primero == nullptr;
}

// Inserta un nuevo hotel en la lista
void listaSimple::insertarRH(String^ codPais, String^ codH, String^ numP, String^ codHab, String^ codClient, int fact)
{
    pnodo nuevo = gcnew nodo();
    if (vacio()) {
        primero = nuevo;
    }
    else {
        pnodo aux = primero;
        while (aux->siguiente != nullptr) {
            if (aux->codCliente==codClient)
            {
                MessageBox::Show("Error, ya tiene una habitacion reservada.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            }
            aux = aux->siguiente;
        }
        aux->siguiente = nuevo;
    }

    nuevo->codPais = codPais;
    nuevo->codHotel = codH;
    nuevo->numPiso = numP;
    nuevo->codHab = codHab;
    nuevo->codCliente = codClient;
    nuevo->factura = fact; //0 = no tiene factura / 1 = tiene factura
    nuevo->precio = 0;
    nuevo->siguiente = nullptr;
    nuevo->anterior = nullptr;
}

// Inserta un nuevo carro en la lista
void listaSimple::insertarRC(String^ codPais, String^ codA, String^ codT, String^ codC, String^ codClient, int fact)
{
    pnodo nuevo = gcnew nodo();
    if (vacio()) {
        primero = nuevo;
    }
    else {
        pnodo aux = primero;
        while (aux->siguiente != nullptr) {
            if (aux->codCliente == codClient)
            {
                MessageBox::Show("Error, ya tiene un carro reservado.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            }
            aux = aux->siguiente;
        }
        aux->siguiente = nuevo;
    }

    nuevo->codPais = codPais;
    nuevo->codAg = codA;
    nuevo->codT = codT;
    nuevo->placa = codC;
    nuevo->codCliente = codClient;
    nuevo->factura = fact;
    nuevo->precio = 0;
    nuevo->siguiente = nullptr;
    nuevo->anterior = nullptr;
}

// Borra el primer nodo
void listaSimple::borrarInicio()
{
    if (vacio()) {
        MessageBox::Show("Error, no hay hoteles registrados.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
    }
    else {
        if (primero->siguiente == nullptr) {
            if (primero->factura==1)
            {
                pnodo temp = primero;
                primero = nullptr;
                delete temp;
            }
            else
            {
                MessageBox::Show("Aun no se le asigna una factura.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            }
        }
        else {
            if (primero->factura==1)
            {
                pnodo aux = primero;
                primero = primero->siguiente;
                delete aux;
            }
            else
            {
                MessageBox::Show("Aun no se le asigna una factura.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            }
        }
    }
}

// Borra un nodo en una posici�n dada
void listaSimple::borrarPosicion(int pos)
{
    if ((pos > largo()) || (pos < 0)) {
        MessageBox::Show("No hay reservaciones que pagar.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
    }
    else {
        if (pos == 1) {
            borrarInicio();
        }
        else {
            int cont = 2;
            pnodo aux = primero;
            while (cont < pos) {
                aux = aux->siguiente;
                cont++;
            }
            pnodo temp = aux->siguiente;
            if (temp->factura==1)
            {
                aux->siguiente = aux->siguiente->siguiente;
                delete temp;
            }
            else
            {
                MessageBox::Show("Aun no se le asigna una factura.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            }
            
        }
    }
   
}

// Retorna el largo de la lista
int listaSimple::largo()
{
    int count = 0;
    pnodo current = primero;

    while (current) {
        count++;
        current = current->siguiente;
    }

    return count;
}

// Muestra todos los hoteles
String^ listaSimple::mostrarH()
{
    nodo^ aux;
    String^ resultado = ""; // Inicializa una cadena vac�a para acumular el resultado

    if (primero == nullptr) {
        // Si la lista est� vac�a, retornamos un mensaje indicando que no hay reservaciones
        resultado = "No existen reservaciones.";
    }
    else {
        aux = primero;
        while (aux) {
            // Concatenamos la informaci�n de cada nodo a la cadena resultado
            resultado += "Codigo de Pais: " + aux->codPais + "\r\n";
            resultado += "Codigo de Hotel: " + aux->codHotel + "\r\n";
            resultado += "Numero de Piso: " + aux->numPiso + "\r\n";
            resultado += "Codigo de Habitacion: " + aux->codHab + "\r\n";
            resultado += "Codigo del Cliente: " + aux->codCliente + "\r\n";
            resultado += "Precio: " + aux->precio + "\r\n\r\n";
            aux = aux->siguiente;  // Avanzamos al siguiente nodo
        }
    }

    return resultado;  // Retornamos el string con toda la informaci�n concatenada
}

// Muestra todos los carros
String^ listaSimple::mostrarA()
{
    nodo^ aux;
    String^ resultado = ""; // Inicializa una cadena vac�a para acumular el resultado

    if (primero == nullptr) {
        // Si la lista est� vac�a, retornamos un mensaje indicando que no hay reservaciones
        resultado = "No existen reservaciones.";
    }
    else {
        aux = primero;
        while (aux) {
            // Concatenamos la informaci�n de cada nodo a la cadena resultado
            resultado += "Codigo de Pais: " + aux->codPais + "\r\n";
            resultado += "Codigo de Agencia: " + aux->codAg + "\r\n";
            resultado += "Codigo de Flotilla: " + aux->codT + "\r\n";
            resultado += "Codigo de Carro: " + aux->placa + "\r\n";
            resultado += "Codigo del Cliente: " + aux->codCliente + "\r\n";
            resultado += "Precio: " + aux->precio + "\r\n\r\n";
            aux = aux->siguiente;  // Avanzamos al siguiente nodo
        }
    }

    return resultado;  // Retornamos el string con toda la informaci�n concatenada
}

bool listaSimple::generarFactura(nodo^ cabeza, String^ codCliente)
{
    nodo^ actual = cabeza;  // Empezamos desde la cabeza de la lista

    while (actual != nullptr) // Recorremos la lista hasta llegar al final
    {
        if (actual->codCliente == codCliente) // Verificamos si codCliente coincide
        {
            if (actual->factura == 0) {
                actual->factura = 1;  // Cambiamos el valor de factura a 1
                return false;  // Salimos de la funci�n ya que encontramos y actualizamos el nodo
            }
            else {
                return true;
            }
        }
        actual = actual->siguiente;  // Avanzamos al siguiente nodo
    }
}

bool listaSimple::generarFactura(String^ codCliente)
{   
    nodo^ aux = primero;
    return generarFactura(aux, codCliente);
}

// Busca un hotel por su c�digo
bool listaSimple::buscar(String^ cod)
{
    nodo^ aux;
    if (primero == nullptr) {
        //MessageBox::Show("No existen hoteles.", "Informaci�n", MessageBoxButtons::OK, MessageBoxIcon::Information);
        return false;
    }
    else {
        aux = primero;
        while (aux) {
            if (cod == aux->codCliente) {
                return true;
            }
            aux = aux->siguiente;
        }
        return false;
    }
}

int listaSimple::buscarPos(String^ codCliente)
{
    nodo^ aux = primero;  // Empezamos desde el primer nodo
    int posicion = 1;      // Inicializamos la posici�n a 1 (porque las listas generalmente son 1-indexadas)

    // Recorremos la lista hasta encontrar el nodo o llegar al final
    while (aux != nullptr) {
        // Comparamos el codCliente del nodo con el par�metro
        if (aux->codCliente == codCliente) {
            return posicion;  // Retornamos la posici�n si encontramos una coincidencia
        }
        aux = aux->siguiente;  // Avanzamos al siguiente nodo
        posicion++;            // Aumentamos la posici�n
    }

    return -1;  // Si no encontramos el nodo, retornamos -1
}

nodo^ listaSimple::buscarNodo(String^ codCliente)
{
    nodo^ aux = primero;  // Empezamos desde el primer nodo

    // Recorremos la lista hasta encontrar el nodo o llegar al final
    while (aux != nullptr) {
        // Comparamos el codCliente del nodo con el par�metro
        if (aux->codCliente == codCliente) {
            return aux;  // Retornamos el nodo si encontramos una coincidencia
        }
        aux = aux->siguiente;  // Avanzamos al siguiente nodo
    }

    return nullptr;  // Si no encontramos el nodo, retornamos nullptr
}

void listaSimple::reservarHotel(String^ pais, String^ cod, String^ numP, String^ codH, String^ codClient, int fact) {
    pnodo aux;
    bool verif;
    aux = primero;
    verif = true;

    for (int i = 0; i < largo(); i++) {
        if (aux->codPais == pais && aux->codHotel == cod && aux->numPiso == numP && aux->codHab == codH) {
            MessageBox::Show("Error, la habitaci�n solicitada ya se encuentra reservada, intente con otra.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            verif = false;
        }
        aux = aux->siguiente;
    }

    if (verif || vacio()) {
        insertarRH(pais, cod, numP, codH, codClient, fact);
        MessageBox::Show("Reservaci�n Exitosa!", "Informaci�n", MessageBoxButtons::OK, MessageBoxIcon::Information);
        return;
    }
    
}

void listaSimple::reservarCarro(String^ pais, String^ cod, String^ numP, String^ codH, String^ codClient, int fact) {
    pnodo aux;
    bool verif;
    aux = primero;
    verif = true;

    for (int i = 0; i < largo(); i++) {
        if (aux->codPais == pais && aux->codAg == cod && aux->codT == numP && aux->placa == codH) {
            MessageBox::Show("Error, el carro solicitado ya se encuentra reservado, intente con otro.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            verif = false;
        }
        aux = aux->siguiente;
    }

    if (verif || vacio()) {
        insertarRC(pais, cod, numP, codH, codClient, fact);
        MessageBox::Show("Reservaci�n Exitosa!", "Informaci�n", MessageBoxButtons::OK, MessageBoxIcon::Information);
        return;
    }
}

void listaSimple::reservarTodo(String^ pais, String^ cod, String^ numP, String^ codH, String^ cod2, String^ numP2, String^ codH2, listaSimple% resHotel, listaSimple% resAgencia, String^ codClient, int fact) {
    pnodo aux1, aux2;
    bool verif;
    aux1 = resHotel.primero;
    verif = true;
    aux2 = resAgencia.primero;

        
    for (int i = 0; i < resHotel.largo(); i++) {
        if (aux1->codPais == pais && aux1->codHotel == cod && aux1->numPiso == numP && aux1->codHab == codH) {
            MessageBox::Show("Error, la habitaci�n solicitada ya se encuentra reservada, intente con otra.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            verif = false;
        }
        aux1 = aux1->siguiente;
    }

    if (verif || resHotel.vacio()) {
        resHotel.insertarRH(pais, cod, numP, codH, codClient, fact);
    }

    verif = true;

    for (int i = 0; i < resAgencia.largo(); i++) {
        if (aux2->codPais == pais && aux2->codAg == cod2 && aux2->codT == numP2 && aux2->placa == codH2) {
            MessageBox::Show("Error, el carro solicitado ya se encuentra reservado, intente con otro.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            verif = false;
        }
        aux2 = aux2->siguiente;
    }

    if (verif || resAgencia.vacio()) {
        resAgencia.insertarRC(pais, cod2, numP2, codH2, codClient, fact);
        MessageBox::Show("Reservaci�n Exitosa!", "Informaci�n", MessageBoxButtons::OK, MessageBoxIcon::Information);
        return;
    }
}

String^ listaSimple::mostrarFacturaH(String^ codClient)
{
    nodo^ aux;
    String^ resultado = ""; // Inicializa una cadena vac�a para acumular el resultado

    if (primero == nullptr) {
        // Si la lista est� vac�a, retornamos un mensaje indicando que no hay reservaciones
        resultado = "No existen reservaciones de hoteles.\r\n\r\n";
    }
    else {
        aux = primero;
        while (aux) {
            if (aux->codCliente == codClient && aux->factura==1)
            {
                resultado += "Codigo de Pais: " + aux->codPais + "\r\n";
                resultado += "Codigo de Hotel: " + aux->codHotel + "\r\n";
                resultado += "Numero de Piso: " + aux->numPiso + "\r\n";
                resultado += "Codigo de Habitacion: " + aux->codHab + "\r\n\r\n";
            }
            
            aux = aux->siguiente;  // Avanzamos al siguiente nodo
        }
    }

    return resultado;  // Retornamos el string con toda la informaci�n concatenada
}

String^ listaSimple::mostrarFacturaA(String^ codClient)
{
    nodo^ aux;
    String^ resultado = ""; // Inicializa una cadena vac�a para acumular el resultado

    if (primero == nullptr) {
        // Si la lista est� vac�a, retornamos un mensaje indicando que no hay reservaciones
        resultado = "No existen reservaciones de carros.\r\n\r\n";
    }
    else {
        aux = primero;
        while (aux) {
            if (aux->codCliente == codClient && aux->factura == 1)
            {
                resultado += "Codigo de Pais: " + aux->codPais + "\r\n";
                resultado += "Codigo de Agencia: " + aux->codAg + "\r\n";
                resultado += "Codigo de Tipo Flotilla: " + aux->codT + "\r\n";
                resultado += "Placa del Carro: " + aux->placa + "\r\n\r\n";
            }

            aux = aux->siguiente;  // Avanzamos al siguiente nodo
        }
    }

    return resultado;  // Retornamos el string con toda la informaci�n concatenada
}

void listaSimple::ponerPrecioH(NodoBinario^ nodoArbol) {
    nodo^ aux;
    int x, x2;
    String^ resultado = ""; // Inicializa una cadena vac�a para acumular el resultado

    if (primero == nullptr) {
        MessageBox::Show("No existen reservaciones.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
    }
    else {
        aux = primero;
        while (aux) {
            Int32::TryParse(aux->codHab, x);
            if (x == nodoArbol->llave)
            {
                Int32::TryParse(nodoArbol->precio, x2);
                aux->precio = x2;
            }

            aux = aux->siguiente;  // Avanzamos al siguiente nodo
        }
    }
}

void listaSimple::ponerPrecioA(NodoBinario^ nodoArbol) {
    nodo^ aux;
    int x, x2;
    String^ resultado = ""; // Inicializa una cadena vac�a para acumular el resultado

    if (primero == nullptr) {
        MessageBox::Show("No existen reservaciones.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
    }
    else {
        aux = primero;
        while (aux) {
            Int32::TryParse(aux->placa, x);
            if (x == nodoArbol->llave)
            {
                Int32::TryParse(nodoArbol->precio, x2);
                aux->precio = x2;
            }

            aux = aux->siguiente;  // Avanzamos al siguiente nodo
        }
    }
}