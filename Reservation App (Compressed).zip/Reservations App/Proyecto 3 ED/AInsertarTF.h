#pragma once
#include "Comun.h"

namespace Proyecto_3_ED {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de AInsertarTF
	/// </summary>
	public ref class AInsertarTF : public System::Windows::Forms::Form
	{
		Persona^ persona;
		ArbolBinario^ paises;
		ArbolBinario^ hoteles;
		ArbolBinario^ pisos;
		ArbolBinario^ habitaciones;
		ArbolBinario^ agencias;
		ArbolBinario^ flotillas;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::TextBox^ cantTB;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::TextBox^ nombreTB;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ codPisoTB;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ eliminarBTN;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ codHotelTB;
	private: System::Windows::Forms::TextBox^ codPaisTB;
		   ArbolBinario^ carros;

	public:
		AInsertarTF(Persona^ p, ArbolBinario^ pais, ArbolBinario^ hotel, ArbolBinario^ piso, ArbolBinario^ hab, ArbolBinario^ ag, ArbolBinario^ fl, ArbolBinario^ car)
		{
			persona = p;
			paises = pais;
			hoteles = hotel;
			pisos = piso;
			habitaciones = hab;
			agencias = ag;
			flotillas = fl;
			carros = car;
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~AInsertarTF()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->cantTB = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->nombreTB = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->codPisoTB = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->eliminarBTN = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->codHotelTB = (gcnew System::Windows::Forms::TextBox());
			this->codPaisTB = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label5->Location = System::Drawing::Point(54, 257);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(81, 17);
			this->label5->TabIndex = 29;
			this->label5->Text = L"Cant. Carros";
			// 
			// cantTB
			// 
			this->cantTB->BackColor = System::Drawing::Color::White;
			this->cantTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->cantTB->ForeColor = System::Drawing::Color::Black;
			this->cantTB->Location = System::Drawing::Point(168, 257);
			this->cantTB->Name = L"cantTB";
			this->cantTB->Size = System::Drawing::Size(146, 20);
			this->cantTB->TabIndex = 28;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label4->Location = System::Drawing::Point(79, 199);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(56, 17);
			this->label4->TabIndex = 27;
			this->label4->Text = L"Nombre";
			// 
			// nombreTB
			// 
			this->nombreTB->BackColor = System::Drawing::Color::White;
			this->nombreTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->nombreTB->ForeColor = System::Drawing::Color::Black;
			this->nombreTB->Location = System::Drawing::Point(168, 199);
			this->nombreTB->Name = L"nombreTB";
			this->nombreTB->Size = System::Drawing::Size(146, 20);
			this->nombreTB->TabIndex = 26;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label3->Location = System::Drawing::Point(29, 88);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(106, 17);
			this->label3->TabIndex = 25;
			this->label3->Text = L"C�digo Agencia";
			// 
			// codPisoTB
			// 
			this->codPisoTB->BackColor = System::Drawing::Color::White;
			this->codPisoTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->codPisoTB->ForeColor = System::Drawing::Color::Black;
			this->codPisoTB->Location = System::Drawing::Point(168, 144);
			this->codPisoTB->Name = L"codPisoTB";
			this->codPisoTB->Size = System::Drawing::Size(146, 20);
			this->codPisoTB->TabIndex = 24;
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(195)), static_cast<System::Int32>(static_cast<System::Byte>(211)),
				static_cast<System::Int32>(static_cast<System::Byte>(223)));
			this->button1->FlatAppearance->BorderSize = 0;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->button1->Location = System::Drawing::Point(152, 317);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(83, 24);
			this->button1->TabIndex = 23;
			this->button1->Text = L"CANCEL";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &AInsertarTF::button1_Click);
			// 
			// eliminarBTN
			// 
			this->eliminarBTN->BackColor = System::Drawing::Color::WhiteSmoke;
			this->eliminarBTN->FlatAppearance->BorderColor = System::Drawing::Color::Black;
			this->eliminarBTN->FlatAppearance->BorderSize = 0;
			this->eliminarBTN->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->eliminarBTN->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->eliminarBTN->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(97)), static_cast<System::Int32>(static_cast<System::Byte>(129)),
				static_cast<System::Int32>(static_cast<System::Byte>(154)));
			this->eliminarBTN->Location = System::Drawing::Point(237, 317);
			this->eliminarBTN->Name = L"eliminarBTN";
			this->eliminarBTN->Size = System::Drawing::Size(77, 24);
			this->eliminarBTN->TabIndex = 22;
			this->eliminarBTN->Text = L"OK";
			this->eliminarBTN->UseVisualStyleBackColor = false;
			this->eliminarBTN->Click += gcnew System::EventHandler(this, &AInsertarTF::eliminarBTN_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label2->Location = System::Drawing::Point(14, 147);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(121, 17);
			this->label2->TabIndex = 21;
			this->label2->Text = L"C�digo Tipo Flotilla";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label1->Location = System::Drawing::Point(57, 33);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(78, 17);
			this->label1->TabIndex = 20;
			this->label1->Text = L"C�digo Pa�s";
			// 
			// codHotelTB
			// 
			this->codHotelTB->BackColor = System::Drawing::Color::White;
			this->codHotelTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->codHotelTB->ForeColor = System::Drawing::Color::Black;
			this->codHotelTB->Location = System::Drawing::Point(168, 88);
			this->codHotelTB->Name = L"codHotelTB";
			this->codHotelTB->Size = System::Drawing::Size(146, 20);
			this->codHotelTB->TabIndex = 19;
			// 
			// codPaisTB
			// 
			this->codPaisTB->BackColor = System::Drawing::Color::White;
			this->codPaisTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->codPaisTB->ForeColor = System::Drawing::Color::Black;
			this->codPaisTB->Location = System::Drawing::Point(168, 30);
			this->codPaisTB->Name = L"codPaisTB";
			this->codPaisTB->Size = System::Drawing::Size(146, 20);
			this->codPaisTB->TabIndex = 18;
			// 
			// AInsertarTF
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(195)), static_cast<System::Int32>(static_cast<System::Byte>(211)),
				static_cast<System::Int32>(static_cast<System::Byte>(223)));
			this->ClientSize = System::Drawing::Size(355, 370);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->cantTB);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->nombreTB);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->codPisoTB);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->eliminarBTN);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->codHotelTB);
			this->Controls->Add(this->codPaisTB);
			this->Name = L"AInsertarTF";
			this->Text = L"AInsertarTF";
			this->Load += gcnew System::EventHandler(this, &AInsertarTF::AInsertarTF_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void AInsertarTF_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Close();
	}
private: System::Void eliminarBTN_Click(System::Object^ sender, System::EventArgs^ e) {
	String^ resp = codPaisTB->Text; // Procesa lo que tiene el cuadro de texto
	String^ resp2 = codHotelTB->Text;
	String^ resp3 = codPisoTB->Text;
	String^ resp4 = nombreTB->Text;
	String^ resp5 = cantTB->Text;
	int snum, codPais, codHotel, cant;
	Int32::TryParse(resp3, snum);
	Int32::TryParse(resp, codPais);
	Int32::TryParse(resp2, codHotel);

	NodoBinario^ nodoBuscado = flotillas->buscar(snum);
	NodoBinario^ nodoBuscado2 = paises->buscar(codPais);
	NodoBinario^ nodoBuscado3 = agencias->buscar(codHotel);

	if (nodoBuscado != nullptr) {
		MessageBox::Show("Ese codigo de tipo flotilla ya existe.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);

	}
	else if (nodoBuscado2 == nullptr) {
		MessageBox::Show("El codigo de pais no existe.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
	else if (nodoBuscado3 == nullptr) {
		MessageBox::Show("El codigo de agencia no existe.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
	else if (!Int32::TryParse(resp3, snum) || !Int32::TryParse(resp2, codHotel) || !Int32::TryParse(resp, codPais)) {
		MessageBox::Show("Los codigos deben ser numeros enteros.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
	else if (!Int32::TryParse(resp5, cant)) {
		MessageBox::Show("La cantidad de carros debe ser un numero entero.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
	else if (nodoBuscado == nullptr && Int32::TryParse(resp3, snum) && nodoBuscado2 != nullptr && nodoBuscado3 != nullptr && Int32::TryParse(resp5, cant)) {
		flotillas->insertarPiso(resp, resp2, resp3, resp4, resp5);
		MessageBox::Show("Tipo flotilla insertado con exito.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);
		this->Close();
	}
}
};
}
