#include "pch.h"
#include "NodoAVL.h"
NodoAVL::NodoAVL(int valor, string codPaisP, string codHotelP, string nombreP, string cantidadHabP) {
	clave = valor;
	codPais = codPaisP;
	codHotel = codHotelP;
	nombre = nombreP;
	cantidadHab = cantidadHabP;
	izquierdo = NULL;
	derecho = NULL;
	altura = 1;
}