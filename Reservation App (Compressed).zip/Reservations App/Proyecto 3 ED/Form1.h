#pragma once

#include "BTree.h"
#include "NodoB.h"

#include <string>
#include <msclr/marshal_cppstd.h>
#include "menu.h"
#include "menuUsuarios.h"

namespace Proyecto_3_ED {
	
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data; 
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de ventanaP
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	private:
		Persona^ persona; //SE CREA COMO ATRIBUTO PRIVADO
		ArbolBinario^ paises;
		ArbolBinario^ hoteles;
		ArbolBinario^ pisos;
		ArbolBinario^ habitaciones;
		ArbolBinario^ agencias;
		ArbolBinario^ flotillas;
		ArbolBinario^ clientes2;
		listaSimple^ resHotel;
		listaSimple^ resAgencia;
		listaSimple^ resTodoIncluido;
	private: System::Windows::Forms::PictureBox^ pictureBox3;

		   ArbolBinario^ carros;
		   int snum;
		//ArbolAA^ paises;

	public:
		Form1(Persona^ p, ArbolBinario^ pais, ArbolBinario^ hotel, ArbolBinario^ piso, ArbolBinario^ hab, ArbolBinario^ ag, 
			ArbolBinario^ fl, ArbolBinario^ car, int numero, ArbolBinario^ client, listaSimple^ resH, listaSimple^ resA, listaSimple^ resT)//, ArbolAA^ pais) //SE CAMBIA EL CONSTRUCTOR Y SE PONEN LOS OBJETOS COMO PARAMETROS 
		{
			persona = p; //GUARDAR PARAMETRO (objeto de clase externa)
			paises = pais;
			hoteles = hotel;
			pisos = piso;
			habitaciones = hab;
			agencias = ag;
			flotillas = fl;
			carros = car;
			snum = numero;
			clientes2 = client;
			resHotel = resH;
			resAgencia = resA;
			resTodoIncluido = resT;
			//paises = pais;
			InitializeComponent();
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ idTb;



	private: System::Windows::Forms::Button^ loginBtn;
	private: System::Windows::Forms::CheckBox^ adminhCB;
	private: System::Windows::Forms::CheckBox^ adminaCB;
	private: System::Windows::Forms::CheckBox^ clienteCB;





	private: System::Windows::Forms::Label^ error;


	private: System::Windows::Forms::PictureBox^ pictureBox2;
	private: System::Windows::Forms::PictureBox^ pictureBox1;








	protected:

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->idTb = (gcnew System::Windows::Forms::TextBox());
			this->loginBtn = (gcnew System::Windows::Forms::Button());
			this->adminhCB = (gcnew System::Windows::Forms::CheckBox());
			this->adminaCB = (gcnew System::Windows::Forms::CheckBox());
			this->clienteCB = (gcnew System::Windows::Forms::CheckBox());
			this->error = (gcnew System::Windows::Forms::Label());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox3 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->label1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(157)), static_cast<System::Int32>(static_cast<System::Byte>(178)),
				static_cast<System::Int32>(static_cast<System::Byte>(191)));
			this->label1->Location = System::Drawing::Point(177, 62);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(138, 19);
			this->label1->TabIndex = 0;
			this->label1->Text = L"INICIO DE SESI�N";
			this->label1->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// idTb
			// 
			this->idTb->BackColor = System::Drawing::Color::Lavender;
			this->idTb->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->idTb->ForeColor = System::Drawing::SystemColors::ControlDarkDark;
			this->idTb->Location = System::Drawing::Point(151, 121);
			this->idTb->Name = L"idTb";
			this->idTb->Size = System::Drawing::Size(200, 21);
			this->idTb->TabIndex = 1;
			// 
			// loginBtn
			// 
			this->loginBtn->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(221)), static_cast<System::Int32>(static_cast<System::Byte>(230)),
				static_cast<System::Int32>(static_cast<System::Byte>(237)));
			this->loginBtn->FlatAppearance->BorderSize = 0;
			this->loginBtn->FlatStyle = System::Windows::Forms::FlatStyle::Popup;
			this->loginBtn->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->loginBtn->ForeColor = System::Drawing::SystemColors::ControlText;
			this->loginBtn->Location = System::Drawing::Point(180, 289);
			this->loginBtn->Name = L"loginBtn";
			this->loginBtn->Size = System::Drawing::Size(132, 46);
			this->loginBtn->TabIndex = 4;
			this->loginBtn->Text = L"ACEPTAR";
			this->loginBtn->UseVisualStyleBackColor = false;
			this->loginBtn->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// adminhCB
			// 
			this->adminhCB->AutoSize = true;
			this->adminhCB->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->adminhCB->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->adminhCB->ForeColor = System::Drawing::SystemColors::GradientInactiveCaption;
			this->adminhCB->Location = System::Drawing::Point(188, 163);
			this->adminhCB->Name = L"adminhCB";
			this->adminhCB->Size = System::Drawing::Size(121, 21);
			this->adminhCB->TabIndex = 5;
			this->adminhCB->Text = L"Administrador H";
			this->adminhCB->UseVisualStyleBackColor = false;
			this->adminhCB->CheckedChanged += gcnew System::EventHandler(this, &Form1::adminH_CheckedChanged);
			// 
			// adminaCB
			// 
			this->adminaCB->AutoSize = true;
			this->adminaCB->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->adminaCB->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->adminaCB->ForeColor = System::Drawing::SystemColors::GradientInactiveCaption;
			this->adminaCB->Location = System::Drawing::Point(188, 190);
			this->adminaCB->Name = L"adminaCB";
			this->adminaCB->Size = System::Drawing::Size(122, 21);
			this->adminaCB->TabIndex = 6;
			this->adminaCB->Text = L"Administrador A";
			this->adminaCB->UseVisualStyleBackColor = false;
			this->adminaCB->CheckedChanged += gcnew System::EventHandler(this, &Form1::adminA_CheckedChanged);
			// 
			// clienteCB
			// 
			this->clienteCB->AutoSize = true;
			this->clienteCB->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->clienteCB->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->clienteCB->ForeColor = System::Drawing::SystemColors::GradientInactiveCaption;
			this->clienteCB->Location = System::Drawing::Point(188, 217);
			this->clienteCB->Name = L"clienteCB";
			this->clienteCB->Size = System::Drawing::Size(70, 21);
			this->clienteCB->TabIndex = 7;
			this->clienteCB->Text = L"Cliente";
			this->clienteCB->UseVisualStyleBackColor = false;
			this->clienteCB->CheckedChanged += gcnew System::EventHandler(this, &Form1::cliente_CheckedChanged);
			// 
			// error
			// 
			this->error->AutoSize = true;
			this->error->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->error->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->error->ForeColor = System::Drawing::SystemColors::ActiveCaption;
			this->error->Location = System::Drawing::Point(156, 252);
			this->error->Name = L"error";
			this->error->Size = System::Drawing::Size(0, 17);
			this->error->TabIndex = 9;
			this->error->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			// 
			// pictureBox2
			// 
			this->pictureBox2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->pictureBox2->Cursor = System::Windows::Forms::Cursors::Default;
			this->pictureBox2->Location = System::Drawing::Point(63, 52);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(375, 316);
			this->pictureBox2->TabIndex = 12;
			this->pictureBox2->TabStop = false;
			this->pictureBox2->Click += gcnew System::EventHandler(this, &Form1::pictureBox2_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(109, 121);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(25, 21);
			this->pictureBox1->TabIndex = 13;
			this->pictureBox1->TabStop = false;
			// 
			// pictureBox3
			// 
			this->pictureBox3->BackColor = System::Drawing::Color::White;
			this->pictureBox3->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->pictureBox3->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox3.Image")));
			this->pictureBox3->Location = System::Drawing::Point(497, -60);
			this->pictureBox3->Name = L"pictureBox3";
			this->pictureBox3->Size = System::Drawing::Size(400, 500);
			this->pictureBox3->SizeMode = System::Windows::Forms::PictureBoxSizeMode::AutoSize;
			this->pictureBox3->TabIndex = 14;
			this->pictureBox3->TabStop = false;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(39)), static_cast<System::Int32>(static_cast<System::Byte>(55)),
				static_cast<System::Int32>(static_cast<System::Byte>(77)));
			this->ClientSize = System::Drawing::Size(887, 421);
			this->Controls->Add(this->pictureBox3);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->error);
			this->Controls->Add(this->clienteCB);
			this->Controls->Add(this->adminaCB);
			this->Controls->Add(this->adminhCB);
			this->Controls->Add(this->loginBtn);
			this->Controls->Add(this->idTb);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->pictureBox2);
			this->Name = L"Form1";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Login";
			this->TransparencyKey = System::Drawing::Color::White;
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		BTree clientes(4), adminH(4), adminA(4);
		clientes.leerClientes_Admins("Clientes.txt");
		adminH.leerClientes_Admins("AdministradoresH.txt");
		adminA.leerClientes_Admins("AdministradoresA.txt");
		int tipo;

		String^ resp = idTb->Text; //Procesa lo que tiene el cuadro de texto
		string n = msclr::interop::marshal_as<std::string>(resp);
		String^ errorMsg = "Error, usuario no encontrado."; //Mensaje de error si no encuentra al usuario
		String^ encontrado="             Bienvenido"; //Mensaje si enceuntra al usuario
		if (clientes.buscarPorID(n) == true && clienteCB->Checked == true) { //Entra si encuentra al cliente en Clientes.txt
			error->Text = encontrado;
			tipo = 3;
			menuUsuarios^ Ov = gcnew menuUsuarios(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, resHotel, resAgencia, resTodoIncluido, resp);// , paises);  ///DEBE DE ABRIR VENTANA PARA CLIENTE
			Ov->Show();
			//this->Hide();
		}
		else if(adminH.buscarPorID(n) == true && adminhCB->Checked == true){ //Entra si encuentra el ID del administrador de hotel en el .txt
			error->Text = encontrado;
			tipo = 1;
			menu^ Ov = gcnew menu(tipo, persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros,snum, clientes2, resHotel, resAgencia, resTodoIncluido);//,paises); //DEBE DE ABRIR VENTANA PARA ADMIN H
			Ov->Show();
			//this->Hide();
		}
		else if (adminA.buscarPorID(n) == true && adminaCB->Checked == true) { //Entra si encuentra el ID del administrador de agencia en el .txt
			error->Text = encontrado;
			tipo = 2;
			menu^ Ov = gcnew menu(tipo, persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros,snum, clientes2, resHotel, resAgencia, resTodoIncluido);//,paises);  //DEBE DE ABRIR VENTANA PARA ADMIN A
			Ov->Show();
			//this->Hide();
		}
		else {
			error->Text = errorMsg;
		}
	}
	private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void adminH_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
		if (adminhCB->Checked) {
			adminaCB->Checked = false;
			clienteCB->Checked = false;
		}
	}
	private: System::Void adminA_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
		if (adminaCB->Checked) {
			adminhCB->Checked = false;
			clienteCB->Checked = false;
		}
	}
	private: System::Void cliente_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
		if (clienteCB->Checked) {
			adminaCB->Checked = false;
			adminhCB->Checked = false;
		}
	}
	private: System::Void button1_Click_1(System::Object^ sender, System::EventArgs^ e) {
		this->Close();
	}
	private: System::Void pictureBox2_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	};
}
