#pragma once
#include "Comun.h"
namespace Proyecto_3_ED {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de AModificarAgencia2
	/// </summary>
	public ref class AModificarAgencia2 : public System::Windows::Forms::Form
	{
	private:
		Persona^ persona;
		ArbolBinario^ paises;
		ArbolBinario^ hoteles;
		ArbolBinario^ pisos;
		ArbolBinario^ habitaciones;
		ArbolBinario^ agencias;
		ArbolBinario^ flotillas;
		   ArbolBinario^ carros;
		   int snum;

	public:
		AModificarAgencia2(Persona^ p, ArbolBinario^ pais, ArbolBinario^ hotel, ArbolBinario^ piso, ArbolBinario^ hab, ArbolBinario^ ag, ArbolBinario^ fl, ArbolBinario^ car, int numero)
		{
			persona = p;
			paises = pais;
			hoteles = hotel;
			pisos = piso;
			habitaciones = hab;
			agencias = ag;
			flotillas = fl;
			carros = car;
			snum = numero;
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~AModificarAgencia2()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;
	protected:
	private: System::Windows::Forms::Button^ eliminarBTN;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ cantidadTB;
	private: System::Windows::Forms::TextBox^ nombreTB;

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->eliminarBTN = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->cantidadTB = (gcnew System::Windows::Forms::TextBox());
			this->nombreTB = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(208)), static_cast<System::Int32>(static_cast<System::Byte>(221)),
				static_cast<System::Int32>(static_cast<System::Byte>(230)));
			this->button1->FlatAppearance->BorderSize = 0;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->button1->Location = System::Drawing::Point(162, 137);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(83, 24);
			this->button1->TabIndex = 23;
			this->button1->Text = L"CANCEL";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &AModificarAgencia2::button1_Click);
			// 
			// eliminarBTN
			// 
			this->eliminarBTN->BackColor = System::Drawing::Color::WhiteSmoke;
			this->eliminarBTN->FlatAppearance->BorderColor = System::Drawing::Color::Black;
			this->eliminarBTN->FlatAppearance->BorderSize = 0;
			this->eliminarBTN->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->eliminarBTN->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->eliminarBTN->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(97)), static_cast<System::Int32>(static_cast<System::Byte>(129)),
				static_cast<System::Int32>(static_cast<System::Byte>(154)));
			this->eliminarBTN->Location = System::Drawing::Point(251, 137);
			this->eliminarBTN->Name = L"eliminarBTN";
			this->eliminarBTN->Size = System::Drawing::Size(77, 24);
			this->eliminarBTN->TabIndex = 22;
			this->eliminarBTN->Text = L"OK";
			this->eliminarBTN->UseVisualStyleBackColor = false;
			this->eliminarBTN->Click += gcnew System::EventHandler(this, &AModificarAgencia2::eliminarBTN_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label2->Location = System::Drawing::Point(3, 90);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(144, 17);
			this->label2->TabIndex = 21;
			this->label2->Text = L"Nueva Cant. Vehiculos";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label1->Location = System::Drawing::Point(55, 32);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(99, 17);
			this->label1->TabIndex = 20;
			this->label1->Text = L"Nuevo Nombre";
			// 
			// cantidadTB
			// 
			this->cantidadTB->BackColor = System::Drawing::Color::White;
			this->cantidadTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->cantidadTB->ForeColor = System::Drawing::Color::Black;
			this->cantidadTB->Location = System::Drawing::Point(182, 87);
			this->cantidadTB->Name = L"cantidadTB";
			this->cantidadTB->Size = System::Drawing::Size(146, 20);
			this->cantidadTB->TabIndex = 19;
			// 
			// nombreTB
			// 
			this->nombreTB->BackColor = System::Drawing::Color::White;
			this->nombreTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->nombreTB->ForeColor = System::Drawing::Color::Black;
			this->nombreTB->Location = System::Drawing::Point(182, 32);
			this->nombreTB->Name = L"nombreTB";
			this->nombreTB->Size = System::Drawing::Size(146, 20);
			this->nombreTB->TabIndex = 18;
			// 
			// AModificarAgencia2
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(208)), static_cast<System::Int32>(static_cast<System::Byte>(221)),
				static_cast<System::Int32>(static_cast<System::Byte>(230)));
			this->ClientSize = System::Drawing::Size(355, 193);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->eliminarBTN);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->cantidadTB);
			this->Controls->Add(this->nombreTB);
			this->Name = L"AModificarAgencia2";
			this->Text = L"AModificarAgencia2";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Close();
	}
private: System::Void eliminarBTN_Click(System::Object^ sender, System::EventArgs^ e) {
	String^ resp = nombreTB->Text; // Procesa lo que tiene el cuadro de texto
	String^ resp2 = cantidadTB->Text;
	int cantidad;
	if (!String::IsNullOrEmpty(resp) && Int32::TryParse(resp2, cantidad)) {
		agencias->modificarHotel(snum, resp, resp2);
		MessageBox::Show("La agencia ha sido modificada.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);
		this->Close();
	}
	else {
		MessageBox::Show("Error, hace falta informaci�n o el formato es incorrecto.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}
};
}
