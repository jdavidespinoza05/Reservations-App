#pragma once
#include "Comun.h"

namespace Proyecto_3_ED {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Facturaa
	/// </summary>
	public ref class Facturaa : public System::Windows::Forms::Form
	{
	private:

		listaSimple^ resHotel;
		listaSimple^ resAgencia;
		listaSimple^ resTodoIncluido;


	public:
		Facturaa(listaSimple^ resH, listaSimple^ resA, listaSimple^ resT)//, ArbolAA^ pais) //SE CAMBIA EL CONSTRUCTOR Y SE PONEN LOS OBJETOS COMO PARAMETROS 
		{
			resHotel = resH;
			resAgencia = resA;
			resTodoIncluido = resT;
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~Facturaa()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;
	protected:
	private: System::Windows::Forms::Button^ eliminarBTN;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ codClienteTB;


	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->eliminarBTN = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->codClienteTB = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(170)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(210)));
			this->button1->FlatAppearance->BorderSize = 0;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->button1->Location = System::Drawing::Point(148, 82);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(83, 24);
			this->button1->TabIndex = 27;
			this->button1->Text = L"CANCEL";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &Facturaa::button1_Click);
			// 
			// eliminarBTN
			// 
			this->eliminarBTN->BackColor = System::Drawing::Color::WhiteSmoke;
			this->eliminarBTN->FlatAppearance->BorderColor = System::Drawing::Color::Black;
			this->eliminarBTN->FlatAppearance->BorderSize = 0;
			this->eliminarBTN->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->eliminarBTN->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->eliminarBTN->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(97)), static_cast<System::Int32>(static_cast<System::Byte>(129)),
				static_cast<System::Int32>(static_cast<System::Byte>(154)));
			this->eliminarBTN->Location = System::Drawing::Point(237, 82);
			this->eliminarBTN->Name = L"eliminarBTN";
			this->eliminarBTN->Size = System::Drawing::Size(77, 24);
			this->eliminarBTN->TabIndex = 26;
			this->eliminarBTN->Text = L"OK";
			this->eliminarBTN->UseVisualStyleBackColor = false;
			this->eliminarBTN->Click += gcnew System::EventHandler(this, &Facturaa::eliminarBTN_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label1->Location = System::Drawing::Point(41, 30);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(97, 17);
			this->label1->TabIndex = 25;
			this->label1->Text = L"C�digo cliente";
			// 
			// codClienteTB
			// 
			this->codClienteTB->BackColor = System::Drawing::Color::White;
			this->codClienteTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->codClienteTB->ForeColor = System::Drawing::Color::Black;
			this->codClienteTB->Location = System::Drawing::Point(168, 30);
			this->codClienteTB->Name = L"codClienteTB";
			this->codClienteTB->Size = System::Drawing::Size(146, 20);
			this->codClienteTB->TabIndex = 24;
			// 
			// Facturaa
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(170)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(210)));
			this->ClientSize = System::Drawing::Size(355, 137);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->eliminarBTN);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->codClienteTB);
			this->Name = L"Facturaa";
			this->Text = L"Facturaa";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Close();
	}
private: System::Void eliminarBTN_Click(System::Object^ sender, System::EventArgs^ e) {
	String^ resp = codClienteTB->Text;
	if (resHotel->buscar(resp) == true && resAgencia->buscar(resp) == true) {
		if (resHotel->generarFactura(resp) == false && resAgencia->generarFactura(resp) == false) {
			MessageBox::Show("Factura sobre reservaci�n de hotel y de carro hecha cliente.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);
			this->Close();
		}
		else {
			MessageBox::Show("Este cliente no tiene nada que cancelar.", "Info", MessageBoxButtons::OK, MessageBoxIcon::Information);

		}		
	}
	else if (resHotel->buscar(resp) == true) {
		if (resHotel->generarFactura(resp) == false) {
			MessageBox::Show("Factura sobre reservaci�n de hotel hecha al cliente.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);
			this->Close();
		}
		else {
			MessageBox::Show("Este cliente no tiene nada que cancelar.", "Info", MessageBoxButtons::OK, MessageBoxIcon::Information);

		}
	}
	else if (resAgencia->buscar(resp)==true) {
		if (resAgencia->generarFactura(resp) == false) {
			MessageBox::Show("Factura sobre reservaci�n de carro hecha al cliente.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);
			this->Close();
		}
		else {
			MessageBox::Show("Este cliente no tiene nada que cancelar.", "Info", MessageBoxButtons::OK, MessageBoxIcon::Information);
		}
	}
	else {
		MessageBox::Show("Este cliente no tiene nada que cancelar.", "Info", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
}
};
}
