#pragma once

using namespace System;  // Necesario para usar tipos de .NET como String

ref class nodo
{
public:
    nodo();  // Constructor por defecto
    nodo(int v);  // Constructor con valor entero
    nodo(int v, nodo^ signodo);  // Constructor con valor entero y siguiente nodo
    nodo(String^ dato);  // Constructor con String^
    nodo(String^ dato, nodo^ signodo);  // Constructor con String^ y siguiente nodo

    int valor;  // Miembro privado
    String^ caracter;  // Miembro privado

    String^ codPais;
    String^ codHotel;
    String^ numPiso;
    String^ codHab;
    String^ codAg;
    String^ codT;
    String^ placa;
    String^ codCliente;
    int factura;
    int precio;
    
    nodo^ siguiente;  // Usamos ^ en lugar de * para punteros en C++/CLI
    nodo^ anterior;

};

typedef nodo^ pnodo;
