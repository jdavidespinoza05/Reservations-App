#pragma once
#include "Comun.h"
namespace Proyecto_3_ED {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de AModificarCarro2
	/// </summary>
	public ref class AModificarCarro2 : public System::Windows::Forms::Form
	{
	private:
		Persona^ persona;
		ArbolBinario^ paises;
		ArbolBinario^ hoteles;
		ArbolBinario^ pisos;
		ArbolBinario^ habitaciones;
		ArbolBinario^ agencias;
		ArbolBinario^ flotillas;
		   ArbolBinario^ carros;
	private: System::Windows::Forms::CheckBox^ checkBox3;
	private: System::Windows::Forms::CheckBox^ checkBox2;
	private: System::Windows::Forms::CheckBox^ checkBox1;
		   int snum;

	public:
		AModificarCarro2(Persona^ p, ArbolBinario^ pais, ArbolBinario^ hotel, ArbolBinario^ piso, ArbolBinario^ hab, ArbolBinario^ ag, ArbolBinario^ fl, ArbolBinario^ car, int numero)
		{
			persona = p;
			paises = pais;
			hoteles = hotel;
			pisos = piso;
			habitaciones = hab;
			agencias = ag;
			flotillas = fl;
			carros = car;
			snum = numero;
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~AModificarCarro2()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label4;
	protected:
	private: System::Windows::Forms::TextBox^ precioTB;
	private: System::Windows::Forms::Label^ label3;

	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ eliminarBTN;

	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ numTB;
	private: System::Windows::Forms::TextBox^ tipoTB;
	private: System::Windows::Forms::TextBox^ a�oTB;

	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label2;

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->precioTB = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->eliminarBTN = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->numTB = (gcnew System::Windows::Forms::TextBox());
			this->tipoTB = (gcnew System::Windows::Forms::TextBox());
			this->a�oTB = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->checkBox3 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox2 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->SuspendLayout();
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label4->Location = System::Drawing::Point(51, 267);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(91, 17);
			this->label4->TabIndex = 63;
			this->label4->Text = L"Nuevo Estado";
			// 
			// precioTB
			// 
			this->precioTB->BackColor = System::Drawing::Color::White;
			this->precioTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->precioTB->ForeColor = System::Drawing::Color::Black;
			this->precioTB->Location = System::Drawing::Point(177, 206);
			this->precioTB->Name = L"precioTB";
			this->precioTB->Size = System::Drawing::Size(146, 20);
			this->precioTB->TabIndex = 62;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label3->Location = System::Drawing::Point(8, 91);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(134, 17);
			this->label3->TabIndex = 61;
			this->label3->Text = L"Nuevo Num. Asientos";
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(183)), static_cast<System::Int32>(static_cast<System::Byte>(202)),
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->button1->FlatAppearance->BorderSize = 0;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->button1->Location = System::Drawing::Point(167, 308);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(83, 24);
			this->button1->TabIndex = 59;
			this->button1->Text = L"CANCEL";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &AModificarCarro2::button1_Click);
			// 
			// eliminarBTN
			// 
			this->eliminarBTN->BackColor = System::Drawing::Color::WhiteSmoke;
			this->eliminarBTN->FlatAppearance->BorderColor = System::Drawing::Color::Black;
			this->eliminarBTN->FlatAppearance->BorderSize = 0;
			this->eliminarBTN->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->eliminarBTN->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->eliminarBTN->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(97)), static_cast<System::Int32>(static_cast<System::Byte>(129)),
				static_cast<System::Int32>(static_cast<System::Byte>(154)));
			this->eliminarBTN->Location = System::Drawing::Point(256, 308);
			this->eliminarBTN->Name = L"eliminarBTN";
			this->eliminarBTN->Size = System::Drawing::Size(77, 24);
			this->eliminarBTN->TabIndex = 58;
			this->eliminarBTN->Text = L"OK";
			this->eliminarBTN->UseVisualStyleBackColor = false;
			this->eliminarBTN->Click += gcnew System::EventHandler(this, &AModificarCarro2::eliminarBTN_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label1->Location = System::Drawing::Point(45, 33);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(97, 17);
			this->label1->TabIndex = 56;
			this->label1->Text = L"Nuevo Modelo";
			// 
			// numTB
			// 
			this->numTB->BackColor = System::Drawing::Color::White;
			this->numTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->numTB->ForeColor = System::Drawing::Color::Black;
			this->numTB->Location = System::Drawing::Point(177, 91);
			this->numTB->Name = L"numTB";
			this->numTB->Size = System::Drawing::Size(146, 20);
			this->numTB->TabIndex = 55;
			// 
			// tipoTB
			// 
			this->tipoTB->BackColor = System::Drawing::Color::White;
			this->tipoTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->tipoTB->ForeColor = System::Drawing::Color::Black;
			this->tipoTB->Location = System::Drawing::Point(177, 33);
			this->tipoTB->Name = L"tipoTB";
			this->tipoTB->Size = System::Drawing::Size(146, 20);
			this->tipoTB->TabIndex = 54;
			// 
			// a�oTB
			// 
			this->a�oTB->BackColor = System::Drawing::Color::White;
			this->a�oTB->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->a�oTB->ForeColor = System::Drawing::Color::Black;
			this->a�oTB->Location = System::Drawing::Point(177, 147);
			this->a�oTB->Name = L"a�oTB";
			this->a�oTB->Size = System::Drawing::Size(146, 20);
			this->a�oTB->TabIndex = 65;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label5->Location = System::Drawing::Point(67, 147);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(75, 17);
			this->label5->TabIndex = 64;
			this->label5->Text = L"Nuevo A�o";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(36)), static_cast<System::Int32>(static_cast<System::Byte>(54)),
				static_cast<System::Int32>(static_cast<System::Byte>(69)));
			this->label2->Location = System::Drawing::Point(55, 206);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(89, 17);
			this->label2->TabIndex = 66;
			this->label2->Text = L"Nuevo Precio";
			// 
			// checkBox3
			// 
			this->checkBox3->AutoSize = true;
			this->checkBox3->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->checkBox3->Location = System::Drawing::Point(303, 267);
			this->checkBox3->Name = L"checkBox3";
			this->checkBox3->Size = System::Drawing::Size(85, 20);
			this->checkBox3->TabIndex = 69;
			this->checkBox3->Text = L"Reservado";
			this->checkBox3->UseVisualStyleBackColor = true;
			this->checkBox3->CheckedChanged += gcnew System::EventHandler(this, &AModificarCarro2::checkBox3_CheckedChanged);
			// 
			// checkBox2
			// 
			this->checkBox2->AutoSize = true;
			this->checkBox2->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->checkBox2->Location = System::Drawing::Point(216, 267);
			this->checkBox2->Name = L"checkBox2";
			this->checkBox2->Size = System::Drawing::Size(81, 20);
			this->checkBox2->TabIndex = 68;
			this->checkBox2->Text = L"Ocupado";
			this->checkBox2->UseVisualStyleBackColor = true;
			this->checkBox2->CheckedChanged += gcnew System::EventHandler(this, &AModificarCarro2::checkBox2_CheckedChanged);
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Font = (gcnew System::Drawing::Font(L"Century Gothic", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->checkBox1->Location = System::Drawing::Point(159, 267);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(51, 20);
			this->checkBox1->TabIndex = 67;
			this->checkBox1->Text = L"Libre";
			this->checkBox1->UseVisualStyleBackColor = true;
			this->checkBox1->CheckedChanged += gcnew System::EventHandler(this, &AModificarCarro2::checkBox1_CheckedChanged);
			// 
			// AModificarCarro2
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(183)), static_cast<System::Int32>(static_cast<System::Byte>(202)),
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->ClientSize = System::Drawing::Size(387, 346);
			this->Controls->Add(this->checkBox3);
			this->Controls->Add(this->checkBox2);
			this->Controls->Add(this->checkBox1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->a�oTB);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->precioTB);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->eliminarBTN);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->numTB);
			this->Controls->Add(this->tipoTB);
			this->Name = L"AModificarCarro2";
			this->Text = L"AModificarCarro2";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Close();
	}
private: System::Void eliminarBTN_Click(System::Object^ sender, System::EventArgs^ e) {
	String^ resp = tipoTB->Text; // Procesa lo que tiene el cuadro de texto
	String^ resp2 = numTB->Text;
	String^ resp22 = a�oTB->Text;
	String^ resp3 = precioTB->Text; // Procesa lo que tiene el cuadro de texto
	String^ resp4;
	int c1, c2, c3;
	if (!String::IsNullOrEmpty(resp) && Int32::TryParse(resp2, c1) && Int32::TryParse(resp22, c3) && Int32::TryParse(resp3, c2)) {
		if (checkBox1->Checked == true) {
			resp4 = "L";
			carros->modificarCarro(snum, resp, resp2, resp22, resp3, resp4);
			MessageBox::Show("El carro ha sido modificado.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);
			this->Close();
		}
		else if (checkBox2->Checked == true) {
			resp4 = "O";
			carros->modificarCarro(snum, resp, resp2, resp22, resp3, resp4);
			MessageBox::Show("El carro ha sido modificado.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);
			this->Close();
		}
		else if (checkBox3->Checked == true) {
			resp4 = "R";
			carros->modificarCarro(snum, resp, resp2, resp22, resp3, resp4);
			MessageBox::Show("El carro ha sido modificado.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);
			this->Close();
		}
		else {
			MessageBox::Show("Debe de seleccionar un estado.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}
	else {
		MessageBox::Show("Error, hace falta informaci�n o el formato es incorrecto.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}

private: System::Void label2_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void checkBox1_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
	if (checkBox1->Checked) {
		checkBox2->Checked = false;
		checkBox3->Checked = false;
	}
}
private: System::Void checkBox2_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
	if (checkBox2->Checked) {
		checkBox1->Checked = false;
		checkBox3->Checked = false;
	}
}
private: System::Void checkBox3_CheckedChanged(System::Object^ sender, System::EventArgs^ e) {
	if (checkBox3->Checked) {
		checkBox2->Checked = false;
		checkBox1->Checked = false;
	}
}
};
}
