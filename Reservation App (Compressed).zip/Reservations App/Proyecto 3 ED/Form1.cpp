#include "pch.h"
#include "Form1.h"

using namespace System;
using namespace System::Windows::Forms;

void main(cli::array<String^>^ args) { //recibe un arreglo de Strings (clientes)
	Persona^ p = gcnew Persona("Juan", 30);

	listaSimple^ resHotel = gcnew listaSimple();
	listaSimple^ resAgencia = gcnew listaSimple();
	listaSimple^ resTodoIncluido = gcnew listaSimple();

	ArbolBinario^ clientes = gcnew ArbolBinario();
	clientes->leerClientes("Clientes.txt");

	ArbolBinario^ paises = gcnew ArbolBinario();
	paises->leerPaises("Paises.txt");

	ArbolBinario^ hoteles = gcnew ArbolBinario();
	hoteles->leerHotel("Hoteles.txt");

	ArbolBinario^ pisos = gcnew ArbolBinario();
	pisos->leerPiso("PisosHotel.txt");

	ArbolBinario^ habitaciones = gcnew ArbolBinario();
	habitaciones->leerHab("Habitaciones.txt");


	ArbolBinario^ agencias = gcnew ArbolBinario();
	agencias->leerHotel("AgenciasCarros.txt");

	ArbolBinario^ flotillas = gcnew ArbolBinario();
	flotillas->leerPiso("TipoFlotilla.txt");
	
	ArbolBinario^ carros = gcnew ArbolBinario();
	carros->leerCarro("Carros.txt");
	int snum;

	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Proyecto_3_ED::Form1 form(p, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, snum, clientes, resHotel, resAgencia, resTodoIncluido);  //ventana inicial al correr el programa
	Application::Run(% form);  //corre la ventana
}