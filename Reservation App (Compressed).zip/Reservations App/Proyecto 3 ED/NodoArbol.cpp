#include "pch.h"
/*
#include "NodoArbol.h"

Nodo::Nodo(String^ codPais, String^ nombre) { // NODO PAIS
    CodPais = codPais;
    Nombre = nombre;
    izquierdo = nullptr;                // Inicializa puntero izquierdo
    derecho = nullptr;
}

Nodo::Nodo(String^ codPais, String^ codHotel, String^ nombre) { // NODO HOTEL / AGENCIA
    CodPais = codPais;
    CodHotel = codHotel;
    Nombre = nombre;
    izquierdo = nullptr;                // Inicializa puntero izquierdo
    derecho = nullptr;
}

Nodo::Nodo(String^ codPais, String^ codHotel, String^ numPiso, String^ nombre,
    String^ cantidadHab) { // NODO PISO / TIPO FLOTILLA
    CodPais = codPais;
    CodHotel = codHotel;
    NumPiso = numPiso;
    Nombre = nombre;
    CantidadHab = cantidadHab;
    izquierdo = nullptr;                // Inicializa puntero izquierdo
    derecho = nullptr;
}

Nodo::Nodo(String^ codPais, String^ codHotel, String^ numPiso, String^ codHabitacion,
    String^ tipoCuarto, String^ numeroCamas, String^ precioHabitacion, String^ estadoHab) { // NODO HABITACION
    CodPais = codPais;
    CodHotel = codHotel;
    NumPiso = numPiso;
    CodHabitacion = codHabitacion;
    TipoCuarto = tipoCuarto;
    NumeroCamas = numeroCamas;
    PrecioHabitacion = precioHabitacion;
    EstadoHab = estadoHab;
    izquierdo = nullptr;                // Inicializa puntero izquierdo
    derecho = nullptr;
}

Nodo::Nodo(String^ codPais, String^ codHotel, String^ numPiso, String^ codHabitacion,
    String^ tipoCuarto, String^ numeroCamas, String^ precioHabitacion, String^ estadoHab,
    String^ estadoCarro) { // NODO CARRO
    CodPais = codPais;
    CodHotel = codHotel;
    NumPiso = numPiso;
    CodHabitacion = codHabitacion;
    TipoCuarto = tipoCuarto;
    NumeroCamas = numeroCamas;
    PrecioHabitacion = precioHabitacion;
    EstadoHab = estadoHab;
    this->estadoCarro = estadoCarro;  // Inicializa el nuevo atributo
    izquierdo = nullptr;                // Inicializa puntero izquierdo
    derecho = nullptr;
}*/