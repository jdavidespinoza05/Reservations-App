#include "pch.h"
#include "BTree.h"
#include <fstream>
#include <sstream>

BTree::BTree(int t) {
	this->raiz = nullptr;
	this->t = t;
}

void BTree::insertar(int k, const string& codPais, const string& nombre) {
	if (raiz == nullptr) {
		raiz = new NodoB(t, true);
		raiz->claves[0] = k;
		raiz->n = 1;
		raiz->nombres[0] = nombre; // Asignar nombre
		raiz->codPaises[0] = codPais; // Asignar código de país
	}
	else {
		// Verificar si la clave ya existe
		if (raiz->buscar(k) != nullptr) {
			return;
		}

		if (raiz->n == 2 * t - 1) {
			NodoB* s = new NodoB(t, false);
			s->hijos[0] = raiz;

			s->dividirHijo(0, raiz);

			int i = 0;
			if (s->claves[0] < k)
				i++;
			s->hijos[i]->insertarNoLleno(k, codPais, nombre);

			raiz = s;
		}
		else {
			raiz->insertarNoLleno(k, codPais, nombre);
		}
	}
}

string BTree::graficar() {
	return (raiz != nullptr) ? raiz->graficar() : "";
}


void BTree::borrar(int k) {
	return;
}

string BTree::recorrer() {
	return (raiz != nullptr) ? raiz->recorrer() : "";
}

bool BTree::buscarPorID(string id) {
	istringstream iss(id);
	int number;
	iss >> number;
	NodoB* nodo = buscar(number);
	return (nodo != nullptr);
}


NodoB* BTree::buscar(int k) {
	return (raiz == nullptr) ? nullptr : raiz->buscar(k);
}

bool BTree::leerClientes_Admins(const string& nombreArchivo) {
	ifstream archivo(nombreArchivo);
	if (!archivo.is_open()) {
		cerr << "No se pudo abrir el archivo: " << nombreArchivo << endl;
		return false;
	}

	archivo.seekg(0, ios::end);
	streampos tamano = archivo.tellg();
	archivo.seekg(0, ios::beg);

	if (tamano == 0) {
		cerr << "El archivo está vacío." << endl;
		archivo.close();
		return false;
	}

	string linea;
	while (getline(archivo, linea)) {
		stringstream ss(linea);
		string campo, codPais, nombre;
		int valor = -1, i = -1;

		while (getline(ss, campo, ';')) {
			if (i == -1) codPais = campo;
			else if (i == 0) valor = stoi(campo);
			else if (i == 1) nombre = campo;
			i++;
		}
		if (valor != -1) insertar(valor, codPais, nombre);
	}
	archivo.close();
	return true;
}


string BTree::consultarClientes() {
	return recorrer();
}
