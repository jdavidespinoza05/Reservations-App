﻿#pragma once

#include "Insertar.h"
#include "InsertarAg.h" 

#include "Modificar.h"
#include "ModificarAg.h"

#include "Eliminar.h"
#include "EliminarAg.h"

#include "Reportes.h"
#include "ReportesAg.h"

#include "Consultas.h"
#include "Facturacion.h"
#include "Reservaciones.h"

#include "Comun.h"

namespace Proyecto_3_ED {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Mantenimiento
	/// </summary>
	public ref class Mantenimiento : public System::Windows::Forms::Form
	{
	private:
		Persona^ persona;
		ArbolBinario^ paises;
		ArbolBinario^ hoteles;
		ArbolBinario^ pisos;
		ArbolBinario^ habitaciones;
		ArbolBinario^ agencias;
		ArbolBinario^ flotillas;
		ArbolBinario^ carros;
		ArbolBinario^ clientes;
		listaSimple^ resHotel;
		listaSimple^ resAgencia;
		listaSimple^ resTodoIncluido;
	private: System::Windows::Forms::PictureBox^ pictureBox2;
	private: System::Windows::Forms::PictureBox^ pictureBox1;

		   int snum;
		   int tipo; // 1=AdminH, 2=AdminA, 3=Cliente
	public:
		Mantenimiento(int x, Persona^ p, ArbolBinario^ pais, ArbolBinario^ hotel, ArbolBinario^ piso, ArbolBinario^ hab, ArbolBinario^ ag, ArbolBinario^ fl, ArbolBinario^ car, int numero, ArbolBinario^ client, listaSimple^ resH, listaSimple^ resA, listaSimple^ resT)
		{
			InitializeComponent();
			persona = p;
			paises = pais;
			hoteles = hotel;
			pisos = piso;
			habitaciones = hab;
			agencias = ag;
			flotillas = fl;
			carros = car;
			tipo = x;
			snum = numero;
			resHotel = resH;
			resAgencia = resA;
			resTodoIncluido = resT;
			//
			//TODO: agregar código de constructor aquí
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se estén usando.
		/// </summary>
		~Mantenimiento()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:



	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button1;

	private: System::Windows::Forms::Panel^ panel1;


	private:
		/// <summary>
		/// Variable del diseñador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Método necesario para admitir el Diseñador. No se puede modificar
		/// el contenido de este método con el editor de código.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Mantenimiento::typeid));
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->panel1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button4->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button4->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(157)),
				static_cast<System::Int32>(static_cast<System::Byte>(178)), static_cast<System::Int32>(static_cast<System::Byte>(191)));
			this->button4->FlatAppearance->BorderSize = 3;
			this->button4->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F));
			this->button4->ForeColor = System::Drawing::SystemColors::ControlLight;
			this->button4->Location = System::Drawing::Point(605, 111);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(251, 226);
			this->button4->TabIndex = 24;
			this->button4->Text = L"Reportes";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &Mantenimiento::button4_Click);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button3->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button3->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(157)),
				static_cast<System::Int32>(static_cast<System::Byte>(178)), static_cast<System::Int32>(static_cast<System::Byte>(191)));
			this->button3->FlatAppearance->BorderSize = 3;
			this->button3->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F));
			this->button3->ForeColor = System::Drawing::SystemColors::ControlLight;
			this->button3->Location = System::Drawing::Point(605, 360);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(251, 226);
			this->button3->TabIndex = 23;
			this->button3->Text = L"Modificar";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &Mantenimiento::button3_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(39)), static_cast<System::Int32>(static_cast<System::Byte>(55)),
				static_cast<System::Int32>(static_cast<System::Byte>(77)));
			this->button2->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button2->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(157)),
				static_cast<System::Int32>(static_cast<System::Byte>(178)), static_cast<System::Int32>(static_cast<System::Byte>(191)));
			this->button2->FlatAppearance->BorderSize = 3;
			this->button2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F));
			this->button2->ForeColor = System::Drawing::SystemColors::ControlLight;
			this->button2->Location = System::Drawing::Point(23, 360);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(545, 226);
			this->button2->TabIndex = 22;
			this->button2->Text = L"Eliminar";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &Mantenimiento::button2_Click);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(39)), static_cast<System::Int32>(static_cast<System::Byte>(55)),
				static_cast<System::Int32>(static_cast<System::Byte>(77)));
			this->button1->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button1->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(157)),
				static_cast<System::Int32>(static_cast<System::Byte>(178)), static_cast<System::Int32>(static_cast<System::Byte>(191)));
			this->button1->FlatAppearance->BorderSize = 3;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F));
			this->button1->ForeColor = System::Drawing::SystemColors::ControlLight;
			this->button1->Location = System::Drawing::Point(23, 111);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(545, 226);
			this->button1->TabIndex = 21;
			this->button1->Text = L"Insertar";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &Mantenimiento::button1_Click);
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(221)), static_cast<System::Int32>(static_cast<System::Byte>(230)),
				static_cast<System::Int32>(static_cast<System::Byte>(237)));
			this->panel1->Controls->Add(this->pictureBox2);
			this->panel1->Controls->Add(this->pictureBox1);
			this->panel1->Controls->Add(this->button4);
			this->panel1->Controls->Add(this->button3);
			this->panel1->Controls->Add(this->button2);
			this->panel1->Controls->Add(this->button1);
			this->panel1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel1->Location = System::Drawing::Point(0, 0);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(878, 611);
			this->panel1->TabIndex = 30;
			// 
			// pictureBox2
			// 
			this->pictureBox2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(175)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(202)));
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(23, 23);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(232, 51);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::CenterImage;
			this->pictureBox2->TabIndex = 34;
			this->pictureBox2->TabStop = false;
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(175)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(202)));
			this->pictureBox1->Location = System::Drawing::Point(0, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(880, 95);
			this->pictureBox1->TabIndex = 33;
			this->pictureBox1->TabStop = false;
			// 
			// Mantenimiento
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(878, 611);
			this->Controls->Add(this->panel1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"Mantenimiento";
			this->Text = L"Mantenimiento";
			this->Load += gcnew System::EventHandler(this, &Mantenimiento::Mantenimiento_Load);
			this->panel1->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
		template<class T>
		void AbrirPanel(T^ FormHijo)
		{
			// Si hay controles en el panel, eliminamos el primero
			if (this->panel1->Controls->Count > 0) {
				// Ocultamos el formulario actual antes de eliminarlo
				auto currentForm = dynamic_cast<Form^>(this->panel1->Controls[0]);
				if (currentForm != nullptr) {
					currentForm->Hide(); // Oculta el formulario actual
				}
				this->panel1->Controls->RemoveAt(0); // Elimina el formulario actual
			}

			// Configuramos el nuevo formulario
			FormHijo->TopLevel = false; // Permitimos que sea un control hijo
			FormHijo->Dock = DockStyle::Fill; // Lo hacemos llenar el panel
			this->panel1->Controls->Add(FormHijo); // Añadimos el nuevo formulario
			this->panel1->Tag = FormHijo; // Opcional: guardar referencia al formulario
			FormHijo->Show(); // Mostramos el nuevo formulario
			FormHijo->BringToFront(); // Asegúrate de que esté al frente
		}

	private: System::Void Mantenimiento_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		if (tipo == 1)
		{
			auto nuevoMenu = gcnew Proyecto_3_ED::Insertar(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros); // Asegúrate de que Insertar sea el formulario correcto
			this->AbrirPanel(nuevoMenu);
		}
		else if (tipo == 2)
		{
			auto nuevoMenu = gcnew Proyecto_3_ED::InsertarAg(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros); // Asegúrate de que Insertar sea el formulario correcto
			this->AbrirPanel(nuevoMenu);
		}

		button1->Enabled = true;
	}
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	if (tipo == 1)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::Modificar(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, snum);  // Asegúrate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}
	else if (tipo == 2)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::ModificarAg(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros);  // Asegúrate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}

	button3->Enabled = true;
}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	if (tipo == 1)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::Reportes(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, resHotel, resAgencia, resTodoIncluido);  // Aseg?rate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}
	else if (tipo == 2)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::ReportesAg(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, resHotel, resAgencia, resTodoIncluido);  // Aseg?rate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}


	// Habilitar el bot?n de nuevo (puedes hacer esto despu?s de que el panel se haya mostrado)
	button4->Enabled = true;
}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	if (tipo == 1)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::Eliminar(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros);  // Asegúrate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}
	else if (tipo == 2)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::EliminarAg(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros);  // Asegúrate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}

	button2->Enabled = true; 
}
private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Close();
}
private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {
	auto nuevoMenu = gcnew Proyecto_3_ED::Consultas(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, clientes);   // Aseg�rate de que Insertar sea el formulario correcto

	// Llama a AbrirPanel con la nueva instancia
	this->AbrirPanel(nuevoMenu);

	// Habilitar el bot�n de nuevo (puedes hacer esto despu�s de que el panel se haya mostrado)
	button4->Enabled = true;
}
};
}
