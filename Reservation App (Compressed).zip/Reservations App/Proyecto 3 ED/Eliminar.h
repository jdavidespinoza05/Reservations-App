#pragma once
#include "EliminarHotel.h"
#include "EliminarPiso.h"
#include "EliminarHabitacion.h"
#include "EliminarPais.h"
namespace Proyecto_3_ED {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Eliminar
	/// </summary>
	public ref class Eliminar : public System::Windows::Forms::Form
	{
	private:
		Persona^ persona;
		ArbolBinario^ paises;
		ArbolBinario^ hoteles;
		ArbolBinario^ pisos;
		ArbolBinario^ habitaciones;
		ArbolBinario^ agencias;
		ArbolBinario^ flotillas;
	private: System::Windows::Forms::PictureBox^ pictureBox2;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
		   ArbolBinario^ carros;
	public:
		Eliminar(Persona^ p, ArbolBinario^ pais, ArbolBinario^ hotel, ArbolBinario^ piso, ArbolBinario^ hab, ArbolBinario^ ag, ArbolBinario^ fl, ArbolBinario^ car)
		{
			persona = p;
			paises = pais;
			hoteles = hotel;
			pisos = piso;
			habitaciones = hab;
			agencias = ag;
			flotillas = fl;
			carros = car;
			InitializeComponent();
			
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~Eliminar()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:


	private: System::Windows::Forms::Label^ tituloInsertar;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button1;

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Eliminar::typeid));
			this->tituloInsertar = (gcnew System::Windows::Forms::Label());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// tituloInsertar
			// 
			this->tituloInsertar->AutoSize = true;
			this->tituloInsertar->Font = (gcnew System::Drawing::Font(L"Century Gothic", 26.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->tituloInsertar->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->tituloInsertar->Location = System::Drawing::Point(348, 122);
			this->tituloInsertar->Name = L"tituloInsertar";
			this->tituloInsertar->RightToLeft = System::Windows::Forms::RightToLeft::No;
			this->tituloInsertar->Size = System::Drawing::Size(172, 42);
			this->tituloInsertar->TabIndex = 27;
			this->tituloInsertar->Text = L"ELIMINAR";
			this->tituloInsertar->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(170)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(210)));
			this->button4->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button4->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button4->Location = System::Drawing::Point(123, 483);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(626, 71);
			this->button4->TabIndex = 31;
			this->button4->Text = L"Pais";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &Eliminar::button4_Click);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(183)), static_cast<System::Int32>(static_cast<System::Byte>(202)),
				static_cast<System::Int32>(static_cast<System::Byte>(217)));
			this->button3->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button3->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button3->Location = System::Drawing::Point(123, 391);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(626, 71);
			this->button3->TabIndex = 30;
			this->button3->Text = L"Habitacion";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &Eliminar::button3_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(195)), static_cast<System::Int32>(static_cast<System::Byte>(211)),
				static_cast<System::Int32>(static_cast<System::Byte>(223)));
			this->button2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button2->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button2->Location = System::Drawing::Point(123, 298);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(626, 71);
			this->button2->TabIndex = 29;
			this->button2->Text = L"Piso";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &Eliminar::button2_Click);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(208)), static_cast<System::Int32>(static_cast<System::Byte>(221)),
				static_cast<System::Int32>(static_cast<System::Byte>(230)));
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button1->Location = System::Drawing::Point(123, 206);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(626, 71);
			this->button1->TabIndex = 28;
			this->button1->Text = L"Hotel";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &Eliminar::button1_Click);
			// 
			// pictureBox2
			// 
			this->pictureBox2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(175)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(202)));
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(23, 23);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(232, 51);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::CenterImage;
			this->pictureBox2->TabIndex = 36;
			this->pictureBox2->TabStop = false;
			this->pictureBox2->Click += gcnew System::EventHandler(this, &Eliminar::pictureBox2_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(175)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(202)));
			this->pictureBox1->Location = System::Drawing::Point(0, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(880, 95);
			this->pictureBox1->TabIndex = 35;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Click += gcnew System::EventHandler(this, &Eliminar::pictureBox1_Click_1);
			// 
			// Eliminar
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(221)), static_cast<System::Int32>(static_cast<System::Byte>(230)),
				static_cast<System::Int32>(static_cast<System::Byte>(237)));
			this->ClientSize = System::Drawing::Size(880, 611);
			this->Controls->Add(this->pictureBox2);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->tituloInsertar);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"Eliminar";
			this->Text = L"Eliminar";
			this->Load += gcnew System::EventHandler(this, &Eliminar::Eliminar_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Eliminar_Load(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {	//HOTELES
	EliminarHotel^ Ov = gcnew EliminarHotel(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros);
	Ov->Show();
}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {	//PISO
	EliminarPiso^ Ov = gcnew EliminarPiso(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros);
	Ov->Show();
}
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {	//HABITACION
	EliminarHabitacion^ Ov = gcnew EliminarHabitacion(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros);
	Ov->Show();
}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) { //PAIS
	EliminarPais^ Ov = gcnew EliminarPais(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros);
	Ov->Show();
}
private: System::Void label4_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void pictureBox1_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void pictureBox1_Click_1(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void pictureBox2_Click(System::Object^ sender, System::EventArgs^ e) {
}
};
}
