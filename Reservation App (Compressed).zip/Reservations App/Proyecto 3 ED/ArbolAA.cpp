#include "pch.h"
#include "ArbolAA.h"
/*
    void ArbolAA::rotarIzquierda(NodoAA^% nodo) {
        NodoAA^ y = nodo->derecha;
        nodo->derecha = y->izquierda;
        y->izquierda = nodo;
        nodo = y;
    }

    void ArbolAA::rotarDerecha(NodoAA^% nodo) {
        NodoAA^ y = nodo->izquierda;
        nodo->izquierda = y->derecha;
        y->derecha = nodo;
        nodo = y;
    }

    void ArbolAA::nivelar(NodoAA^% nodo) {
        if (nodo->derecha != nullptr && nodo->derecha->nivel == nodo->nivel) {
            rotarIzquierda(nodo);
        }
        if (nodo->izquierda != nullptr && nodo->izquierda->izquierda != nullptr && nodo->izquierda->nivel == nodo->nivel) {
            rotarDerecha(nodo);
        }
        if (nodo->izquierda != nullptr && nodo->izquierda->izquierda != nullptr) {
            nodo->izquierda->nivel++;
        }
    }

    NodoAA^ ArbolAA::insertarNodo(NodoAA^ nodo, int valor, String^ nombre) {
        if (nodo == nullptr) {
            NodoAA^ nuevo = gcnew NodoAA(valor, nombre);
            ultimoInsertado = nuevo;
            return nuevo;
        }
        if (valor < nodo->valor) {
            nodo->izquierda = insertarNodo(nodo->izquierda, valor, nombre);
        }
        else if (valor > nodo->valor) {
            nodo->derecha = insertarNodo(nodo->derecha, valor, nombre);
        }
        nivelar(nodo);
        return nodo;
    }


    NodoAA^ ArbolAA::borrarNodo(NodoAA^ nodo, int valor) {
        if (nodo == nullptr) return nodo;

        if (valor < nodo->valor) {
            nodo->izquierda = borrarNodo(nodo->izquierda, valor);
        }
        else if (valor > nodo->valor) {
            nodo->derecha = borrarNodo(nodo->derecha, valor);
        }
        else {
            if (nodo->izquierda == nullptr) {
                NodoAA^ temp = nodo->derecha;
                delete nodo; // Liberar el nodo actual
                return temp;
            }
            else if (nodo->derecha == nullptr) {
                NodoAA^ temp = nodo->izquierda;
                delete nodo; // Liberar el nodo actual
                return temp;
            }
            NodoAA^ temp = nodo->derecha;
            while (temp->izquierda != nullptr) {
                temp = temp->izquierda;
            }
            nodo->valor = temp->valor;
            nodo->nombre = temp->nombre;
            nodo->derecha = borrarNodo(nodo->derecha, temp->valor);
        }
        nivelar(nodo);
        return nodo;
    }
    void ArbolAA::borrar(int valor) {
        raiz = borrarNodo(raiz, valor);
    }

    String^ ArbolAA::inOrdenHelper(NodoAA^ nodo, String^ emp="") {
        if (nodo != nullptr) {
            inOrdenHelper(nodo->izquierda,emp);
            emp = emp + "CodPais: " + nodo->valor;
            emp = emp + "Nombre" + nodo->nombre+"\n";
            inOrdenHelper(nodo->derecha, emp);
        }
        return emp;
    }

    NodoAA^ ArbolAA::buscar(NodoAA^ nodo, int valor) {
        if (nodo == nullptr || valor == nodo->valor) {
            return nodo; // Nodo encontrado o no encontrado
        }
        if (valor < nodo->valor) {
            return buscar(nodo->izquierda, valor);
        }
        else {
            return buscar(nodo->derecha, valor);
        }
    }

    NodoAA^ ArbolAA::obtenerUltimoInsertado() {
        return ultimoInsertado;
    }



    ArbolAA::ArbolAA() {
        raiz = nullptr;
    }

    void ArbolAA::insertar(int valor, String^ nombre) {
        raiz = insertarNodo(raiz, valor, nombre);
    }
    
    void ArbolAA::print() {
        inOrdenHelper(raiz,"");
    }

    bool ArbolAA::buscar(int valor) {
        return buscar(raiz, valor) != nullptr;
    }

    void ArbolAA::leerPais(String^ nombreArchivo) {
        System::IO::StreamReader^ archivo = gcnew System::IO::StreamReader(nombreArchivo);

        // Verificar si el archivo está abierto
        if (archivo == nullptr) {
            Console::WriteLine("No se pudo abrir el archivo: " + nombreArchivo);
            return;
        }

        // Leer línea por línea
        while (!archivo->EndOfStream) {
            String^ linea = archivo->ReadLine();
            cli::array<String^>^ campos = linea->Split(';');

            // Asegurarse de que la línea tiene al menos dos campos
            if (campos->Length >= 2) {
                int valor = Convert::ToInt32(campos[0]);
                String^ nombre = campos[1];
                insertar(valor, nombre);  // Llama al método de inserción con valor y nombre
            }
        }

        archivo->Close(); // Cierra el archivo
    }*/



    /*void ArbolAA::insertarPais(String^ cod, String^ nom) {

        cod = stoi(cod);
        string nom;

        cout << "Acontinuacion se le pedira que ingrese toda la informacion del nuevo pais." << endl << endl;

        cout << "Inserte Codigo Pais: ";
        cin >> cod;
        if (esNumero(cod) == false || buscar(stoi(cod))) {
            cout << endl << "Error, el codigo pais debe ser un numero y no debe existir." << endl << endl;
            return;
        }

        cout << "Inserte Nombre: ";
        cin >> nom;

        insertar(stoi(cod), nom);
        cout << "Pais insertado con exito." << endl << endl;
        return;

    }*/
    /*void ArbolAA::modificarPais() {
        string cod;
        string verif;
        string nuevo;

        int i = 1;

        cout << "Inserte Codigo Pais: ";
        cin >> cod;
        if (esNumero(cod) == false || !buscar(stoi(cod))) {
            cout << endl << "Error, el codigo pais debe ser un numero y debe existir." << endl << endl;
            return;
        }

        else
        {
            cout << "Inserte el nuevo Nombre: ";
            cin >> nuevo;
            cout << endl;
            NodoAA* nodo = buscar(raiz, stoi(cod));
            nodo->nombre = nuevo;
            cout << "Se modifico con exito." << endl << endl;
            return;
        }
    }

    void ArbolAA::consultarPaises() {
        print();
        cout << endl;
    }

    string ArbolAA::ultimo() {
        NodoAA nodo = obtenerUltimoInsertado();
        string texto = "Ultimo Pais registrado: \n";

        texto += "Codigo de pais: " + to_string(nodo->valor) + "\n";
        guardarReporte("consultarUltPais.txt", texto);
        return texto;
    }*/
