#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>

using namespace std;

enum Color { RED, BLACK };

class NodoRB { //------------------------------------------------------------- ARBOL RN -----------------------------------------------------------------------------------------
public:
    int valor; //codHab || placa(codCarro)
    string codPais;
    string codHotel;
    string numPiso;
    string tipoCuarto;
    string numCamas;
    string precioHab;
    string estadoHab;
    string anho;

    Color color;
    NodoRB* izquierda;
    NodoRB* derecha;
    NodoRB* padre;

    NodoRB(int val, string codPais, string codHotel, string numPiso, string tipoCuarto, string numCamas, string precioHab, string estadoHab) : valor(val), codPais(codPais), codHotel(codHotel), numPiso(numPiso), tipoCuarto(tipoCuarto), numCamas(numCamas), precioHab(precioHab), estadoHab(estadoHab), color(RED), izquierda(nullptr), derecha(nullptr), padre(nullptr) {}
    NodoRB(int val, string codPais, string codHotel, string numPiso, string tipoCuarto, string numCamas, string anho, string precioHab, string estadoHab) : valor(val), codPais(codPais), codHotel(codHotel), numPiso(numPiso), tipoCuarto(tipoCuarto), numCamas(numCamas), anho(anho), precioHab(precioHab), estadoHab(estadoHab), color(RED), izquierda(nullptr), derecha(nullptr), padre(nullptr) {}
    NodoRB(int val) : valor(val), color(RED), izquierda(nullptr), derecha(nullptr), padre(nullptr) {}
};