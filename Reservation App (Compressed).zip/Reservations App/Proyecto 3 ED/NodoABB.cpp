#include "pch.h"
#include "NodoABB.h"


void NodoABB::mostrarH() const {
    cout << "CodPais: " << codPais
        << " - CodHotel: " << valor
        << " - Nombre: " << nombre
        << " - CantidadEst: " << cantidadEst << endl;
}

void NodoABB::mostrarA() const {
    cout << "CodPais: " << codPais
        << " - IdentificacionAg: " << valor
        << " - Nombre: " << nombre
        << " - CantidadVeh: " << cantidadEst << endl;
}