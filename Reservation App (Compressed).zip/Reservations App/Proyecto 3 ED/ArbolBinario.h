#include "NodoArbol.h"

using namespace System;
using namespace System::Windows::Forms;

public ref class ArbolBinario {
private:
    NodoBinario^ raiz; // Ra�z del �rbol
    NodoBinario^ ultimoNodoInsertado; 

    NodoBinario^ insertarCliente(NodoBinario^ nodo, String^ codPais, int llave, String^ nom);
    NodoBinario^ insertarP(NodoBinario^ nodo, int llave, String^ nom);
    NodoBinario^ insertarHotel(NodoBinario^ nodo, String^ codPais, int llave, String^ nom, String^ cant);
    NodoBinario^ insertarPiso(NodoBinario^ nodo, String^ codPais, String^ codHotel, int llave, String^ nom, String^ cant);
    NodoBinario^ insertarHab(NodoBinario^ nodo, String^ codPais, String^ codHotel, String^ codPiso, int llave, String^ tipoCuarto, String^ numCamas, String^ precioHab, String^ estadoHab);
    //NodoBinario^ insertarAgencia(NodoBinario^ nodo, String^ codPais, int llave, String^ nom, String^ cant);
    //NodoBinario^ insertarFlotilla(NodoBinario^ nodo, String^ codPais, String^ codHotel, int llave, String^ nom, String^ cant);
    NodoBinario^ insertarCarro(NodoBinario^ nodo, String^ codPais, String^ codHotel, String^ codPiso, int llave, String^ tipoCuarto, String^ numCamas, String^ a�o, String^ precioHab, String^ estadoHab);


    NodoBinario^ buscar(NodoBinario^ nodo, int llave);
    NodoBinario^ eliminarP(NodoBinario^ nodo, int llave);
    NodoBinario^ eliminarHotel(NodoBinario^ nodo, String^ codPais, int llave);
    NodoBinario^ eliminarHotelPais(NodoBinario^ nodo, String^ codPais);
    NodoBinario^ eliminarPiso(NodoBinario^ nodo, String^ codPais, String^ codHotel, int llave);
    NodoBinario^ eliminarPisoHotel(NodoBinario^ nodo, String^ codPais, String^ codHotel);
    NodoBinario^ eliminarHab(NodoBinario^ nodo, String^ codPais, String^ codHotel, String^ codPiso, int llave);
    NodoBinario^ eliminarHabPiso(NodoBinario^ nodo, String^ codPais, String^ codHotel, String^ codPiso);


    NodoBinario^ encontrarMinimo(NodoBinario^ nodo);

    /*void modificarP(int llave, String^ nom);
    void modificarHotel(int llave, String^ nom, String^ cant);
    void modificarPiso(int llave, String^ nom, String^ cant);
    void modificarHab(int llave, String^ tipoCuarto, String^ numCamas, String^ precioHab, String^ estadoHab);
    */

public:
    ArbolBinario();

    void insertarCliente(String^ codPais, String^ llaveStr, String^ nom);
    void insertarP(String^ llaveStr, String^ valor);
    void insertarHotel(String^ codPais, String^ llaveStr, String^ nom, String^ cant);
    void insertarPiso(String^ codPais, String^ codHotel, String^ llaveStr, String^ nom, String^ cant);
    void insertarHab(String^ codPais, String^ codHotel, String^ codPiso, String^ llaveStr, String^ tipoCuarto, String^ numCamas, String^ precioHab, String^ estadoHab);
    //void insertarAgencia(String^ codPais, String^ llaveStr, String^ nom, String^ cant);
    //void insertarFlotilla(String^ codPais, String^ codHotel, String^ llaveStr, String^ nom, String^ cant);
    void insertarCarro(String^ codPais, String^ codHotel, String^ codPiso, String^ llaveStr, String^ tipoCuarto, String^ numCamas, String^ a�o, String^ precioHab, String^ estadoHab);
    int contarNodos(); 

    NodoBinario^ buscar(int llave);
    void eliminarP(String^ llaveStr);
    void eliminarHotel(String^ codPais, String^ llaveStr);
    void eliminarHotelPais(String^ codPais);
    void eliminarPiso(String^ codPais, String^ codHotel, String^ llaveStr);
    void eliminarPisoHotel(String^ codPais, String^ codHotel);
    void eliminarHab(String^ codPais, String^ codHotel, String^ codPiso, String^ llaveStr);
    void eliminarHabPiso(String^ codPais, String^ codHotel, String^ codPiso);

    void modificarP(int llave, String^ nom);
    void modificarHotel(int llave, String^ nom, String^ cant);
    void modificarPiso(int llave, String^ nom, String^ cant);
    void modificarHab(int llave, String^ tipoCuarto, String^ numCamas, String^ precioHab, String^ estadoHab);
    void modificarCarro(int llave, String^ tipoCuarto, String^ numCamas, String^ anho, String^ precioHab, String^ estadoHab);

    /*void modificarP(String^ llaveStr, String^ valor);
    void modificarHotel(String^ llaveStr, String^ nom, String^ cant);
    void modificarPiso(String^ llaveStr, String^ nom, String^ cant);
    void modificarHab(String^ llaveStr, String^ tipoCuarto, String^ numCamas, String^ precioHab, String^ estadoHab);
    */
    void leerClientes(String^ nombreArchivo);
    void leerPaises(String^ nombreArchivo);
    void leerHotel(String^ nombreArchivo);
    void leerPiso(String^ nombreArchivo);
    void leerHab(String^ nombreArchivo);  
    //void leerAgencia(String^ nombreArchivo);
    //void leerFlotilla(String^ nombreArchivo);
    void leerCarro(String^ nombreArchivo);

    NodoBinario^ ultimoInsertado();

    String^ consultarClientes();
    String^ consultarClientesRecursivo(NodoBinario^ nodo, String^% resultado);
    String^ consultarPais();
    String^ consultarPaisRecursivo(NodoBinario^ nodo, String^% resultado);
    String^ consultarHotel();
    String^ consultarHotelRecursivo(NodoBinario^ nodo, String^% resultado);
    String^ consultarPiso(String^ codHotel);
    String^ consultarPisoRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel);
    String^ consultarHab(String^ codHotel, String^ codPiso);
    String^ consultarHabRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel, String^ codPiso);
    String^ cantidadEstrellas(String^ codHotel);
    String^ cantidadEstrellasRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel);
    String^ cantidadHabs(String^ codHotel, String^ codPiso);
    String^ cantidadHabsRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel, String^ codPiso); 

    String^ consultarAgencia();
    String^ consultarAgenciaRecursivo(NodoBinario^ nodo, String^% resultado);
    String^ consultarFlotilla(String^ codHotel);
    String^ consultarFlotillaRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel);
    String^ consultarCarro(String^ codHotel, String^ codPiso);
    String^ consultarCarroRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel, String^ codPiso);
    String^ cantidadAsientos(String^ codHotel);
    String^ cantidadAsientosRecursivo(NodoBinario^ nodo, String^% resultado, String^ codHotel);


};
