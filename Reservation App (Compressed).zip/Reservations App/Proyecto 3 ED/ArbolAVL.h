#pragma once
#include "NodoAVL.h"
#include "ABB.h"
#include "ArbolAA.h"
#include <iostream>
#include <string>
class ArbolAVL {
private:
	NodoAVL* raiz;
	NodoAVL* ultimoInsertado;

public:

	int altura(NodoAVL* nodo);

	int obtenerBalance(NodoAVL* nodo);

	NodoAVL* rotarDerecha(NodoAVL* y);

	NodoAVL* rotarIzquierda(NodoAVL* x);

	NodoAVL* insertar(NodoAVL* nodo, int clave, string codPais, string codHotel, string nombre, string cantidadHab);

	NodoAVL* nodoConValorMinimo(NodoAVL* nodo);

	NodoAVL* obtenerUltimoInsertado();

	NodoAVL* borrar(NodoAVL* raiz, int clave);

	NodoAVL* buscar(NodoAVL* nodo, int clave);

	void preOrdenP(NodoAVL* raiz);

	void preOrdenF(NodoAVL* raiz);

	ArbolAVL();

	void insertar(int clave, string codPais, string codHotel, string nombre, string cantidadHab);

	void borrar(int clave);

	bool buscar(int clave);

	void preOrdenP();

	void preOrdenF();

	void leerPisoFlotilla(const string& nombreArchivo);
	/*
	void insertarPiso(ArbolAA& paises, ABB& hoteles);
	void insertarFlotilla(ArbolAA& paises, ABB& agencias);

	void modificarPiso(ArbolAA& paises, ABB& hoteles);
	void modificarFlotilla(ArbolAA& paises, ABB& agencias);
	*/
	bool buscarCodH(NodoAVL* nodo, string cod);
	void consultarPisoAux(NodoAVL* nodo, const string& verif);
	bool buscarPais(NodoAVL* nodo, const string& pais);
	void consultarPiso();
	void consultarFlotillaAux(NodoAVL* nodo, const string& verif);
	void consultarTipoFlotilla();
	bool buscarPiso(NodoAVL* nodo, const string& piso);
	void cantidadHab();
	void cantidadHabAux(NodoAVL* nodo, int codH);
	void ultimo();
	void ultimoTF();
};