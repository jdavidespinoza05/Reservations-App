#include "pch.h"
#include "NodoB.h"
#include <iomanip>
NodoB::NodoB(int t, bool hoja) {
	this->t = t;
	this->hoja = hoja;

	claves = new int[2 * t - 1];
	hijos = new NodoB * [2 * t];

	nombres = new string[2 * t - 1]; // Inicializar arreglo para nombres
	codPaises = new string[2 * t - 1]; // Inicializar arreglo para códigos de país

	n = 0;
}

void NodoB::insertarNoLleno(int k, const string& codPais, const string& nombre) {
	int i = n - 1;

	if (hoja) {
		while (i >= 0 && claves[i] > k) {
			claves[i + 1] = claves[i];
			nombres[i + 1] = nombres[i]; // Mover nombres
			codPaises[i + 1] = codPaises[i]; // Mover códigos de país
			i--;
		}

		claves[i + 1] = k;
		nombres[i + 1] = nombre; // Asignar nombre
		codPaises[i + 1] = codPais; // Asignar código de país
		n++;
	}
	else {
		while (i >= 0 && claves[i] > k)
			i--;

		// Verificar si la clave ya existe
		if (i >= 0 && claves[i] == k) {
			cout << "La clave " << k << " ya existe. No se puede insertar." << endl;
			return;
		}

		if (hijos[i + 1]->n == 2 * t - 1) {
			dividirHijo(i + 1, hijos[i + 1]);

			if (claves[i + 1] < k)
				i++;
		}
		hijos[i + 1]->insertarNoLleno(k, codPais, nombre);
	}
}

void NodoB::dividirHijo(int i, NodoB* y) {
	NodoB* z = new NodoB(y->t, y->hoja);
	z->n = t - 1;

	for (int j = 0; j < t - 1; j++) {
		z->claves[j] = y->claves[j + t];
		z->nombres[j] = y->nombres[j + t]; // Copiar nombres
		z->codPaises[j] = y->codPaises[j + t]; // Copiar códigos de país
	}

	if (!y->hoja) {
		for (int j = 0; j < t; j++)
			z->hijos[j] = y->hijos[j + t];
	}

	y->n = t - 1;

	for (int j = n; j >= i + 1; j--)
		hijos[j + 1] = hijos[j];

	hijos[i + 1] = z;

	for (int j = n - 1; j >= i; j--) {
		claves[j + 1] = claves[j];
		nombres[j + 1] = nombres[j]; // Mover nombres
		codPaises[j + 1] = codPaises[j]; // Mover códigos de país
	}

	claves[i] = y->claves[t - 1];
	nombres[i] = y->nombres[t - 1]; // Asignar nombre del hijo
	codPaises[i] = y->codPaises[t - 1]; // Asignar código de país del hijo
	n++;
}

string NodoB::recorrer() {
	string output;
	int i;
	for (i = 0; i < n; i++) {
		if (!hoja)
			output += hijos[i]->recorrer();
		output += "Clave: " + to_string(claves[i]) + ", Nombre: " + nombres[i] + ", CodPais: " + codPaises[i] + "\n";
	}

	if (!hoja)
		output += hijos[i]->recorrer();

	return output;
}


string NodoB::graficar(int nivel) {
	string output;
	if (hoja) {
		for (int i = 0; i < n; ++i) {
			output += string(nivel * 4, ' ') + to_string(claves[i]) + " ";
		}
		output += "\n";
	}
	else {
		for (int i = 0; i < n; ++i) {
			output += hijos[i]->graficar(nivel + 1);
			output += string(nivel * 4, ' ') + to_string(claves[i]) + " ";
		}
		output += hijos[n]->graficar(nivel + 1);
	}
	return output;
}


NodoB* NodoB::buscar(int k) {
	int i = 0;
	while (i < n && k > claves[i])
		i++;

	if (i < n && claves[i] == k) // Comprobar si la clave existe
		return this;

	if (hoja)
		return nullptr;

	return hijos[i]->buscar(k);
}
