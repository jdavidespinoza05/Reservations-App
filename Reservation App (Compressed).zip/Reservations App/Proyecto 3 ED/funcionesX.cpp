#include "pch.h"
#include "funcionesX.h"

void borrarContenidoArchivo(const string& nombreArchivo) {
    //Abre el archivo en modo truncado para borrar su contenido
    ofstream archivo(nombreArchivo, ios::trunc);
    if (archivo.is_open()) {
        cout << "El contenido del archivo ha sido borrado.\n";
    }
    else {
        cerr << "No se pudo abrir el archivo.\n";
    }
    archivo.close();
}

//Funci�n que recibe un string y retorna true si es tipo entero
bool esNumero(const string& str) {
    for (char c : str) {
        if (!isdigit(static_cast<unsigned char>(c))) {
            return false; // Si encontramos un car�cter que no es d�gito, retornamos false
        }
    }
    return true; // Todos los caracteres son d�gitos
}

//Funcion que recibe un nombre de archivo y retorna la cantidad de lineas
int contarLineasArchivo(const string& nombreArchivo) {
    ifstream archivo(nombreArchivo);

    if (!archivo.is_open()) {
        cerr << "No se pudo abrir el archivo: " << nombreArchivo << endl;
        return -1; // Retornar -1 para indicar un error
    }

    int contadorLineas = 0;
    string linea;
    while (getline(archivo, linea)) {
        contadorLineas++;
    }
    archivo.close();
    return contadorLineas;
}

void guardarReporte(const string& nombreArchivo, string& contenidoReporte) {
    ofstream archivo(nombreArchivo, ios::app);
    if (archivo.is_open()) {
        archivo << contenidoReporte << endl;
        archivo.close();
    }
    else {
        cerr << "Error al abrir el archivo para guardar el reporte." << endl << endl;
    }
}