#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>

#include "NodoABB.h"
#include "ArbolAA.h"
#include "funcionesX.h"

class ABB {
private:
    NodoABB* raiz;
    NodoABB* ultimoInsertado;

    // Declaraci�n de m�todos privados
    void insertar(NodoABB*& nodo, int valor, const string& pais, const string& nom, const string& cantidad);
    NodoABB* buscar(NodoABB* nodo, int clave);
    NodoABB* borrar(NodoABB*& nodo, int valor);
    NodoABB* encontrarMinimo(NodoABB* nodo);
    void recorridoInordenH(NodoABB* nodo);
    void recorridoInordenA(NodoABB* nodo);

public:
    ABB();
    void insertar(int valor, const string& pais, const string& nom, const string& cantidad);
    bool buscar(int valor);
    void borrar(int valor);
    void recorridoInordenH();
    void recorridoInordenA();
    NodoABB* obtenerUltimoInsertado();
    void leerHotel_Agencia(const string& nombreArchivo);
    //void insertarHotel(ArbolAA& paises);
    //void insertarAgencia(ArbolAA& paises);
    //void modificarHotel(ArbolAA& paises);
    //void modificarAgencia(ArbolAA& paises);
    void consultarHoteles();
    bool buscarPais(NodoABB* nodo, const string& pais);
    void cantidadEst();
    void cantidadEstAux(NodoABB* nodo, int codH);
    void consultarAgencias();
    void ultimo();
    void ultimoA();
};