#pragma once

//#include "funciones.cpp"

#include "AcercaDe.h"
#include "Contactos.h"

#include "Insertar.h"
#include "InsertarAg.h"

#include "Modificar.h"
#include "ModificarAg.h"

#include "Eliminar.h"
#include "EliminarAg.h"

#include "Reportes.h"
#include "ReportesAg.h"

#include "Consultas.h"
#include "Facturacion.h"
#include "Mantenimiento.h"
#include "prueba.h"
#include "Comun.h"

namespace Proyecto_3_ED {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de menu
	/// </summary>
	public ref class menu : public System::Windows::Forms::Form
	{
	private:
		Persona^ persona;
		ArbolBinario^ paises;
		ArbolBinario^ hoteles;
		ArbolBinario^ pisos;
		ArbolBinario^ habitaciones;
		ArbolBinario^ agencias;
		ArbolBinario^ flotillas;
		ArbolBinario^ carros;
		ArbolBinario^ clientes;
		listaSimple^ resHotel;
		listaSimple^ resAgencia;
		listaSimple^ resTodoIncluido;
	private: System::Windows::Forms::PictureBox^ pictureBox2;


		   int snum;


	private: System::Windows::Forms::Button^ button11;
	private: System::Windows::Forms::Button^ button10;
	private: System::Windows::Forms::Button^ button1;




		   int tipo; // 1=AdminH, 2=AdminA, 3=Cliente
		//ArbolAA^ paises;
	public:
		menu(int x, Persona^ p, ArbolBinario^ pais, ArbolBinario^ hotel, ArbolBinario^ piso, ArbolBinario^ hab, 
			ArbolBinario^ ag, ArbolBinario^ fl, ArbolBinario^ car, int numero, ArbolBinario^ client, listaSimple^ resH, listaSimple^ resA, listaSimple^ resT)//, ArbolAA^ pais)
		{
			persona = p;
			paises = pais;
			hoteles = hotel;
			pisos = piso;
			habitaciones = hab;
			agencias = ag;
			flotillas = fl;
			carros = car;
			snum = numero;
			tipo = x; 
			clientes = client;
			resHotel = resH;
			resAgencia = resA;
			resTodoIncluido = resT;

			InitializeComponent();
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~menu()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panelMenu;
	protected:

	protected:








	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;



	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Button^ button7;


	private: System::Windows::Forms::Button^ button9;


	private: System::Windows::Forms::PictureBox^ pictureBox1;


	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button2;







	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(menu::typeid));
			this->panelMenu = (gcnew System::Windows::Forms::Panel());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->panelMenu->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->panel2->SuspendLayout();
			this->SuspendLayout();
			// 
			// panelMenu
			// 
			this->panelMenu->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(221)), static_cast<System::Int32>(static_cast<System::Byte>(230)),
				static_cast<System::Int32>(static_cast<System::Byte>(237)));
			this->panelMenu->Controls->Add(this->pictureBox2);
			this->panelMenu->Controls->Add(this->button4);
			this->panelMenu->Controls->Add(this->button3);
			this->panelMenu->Controls->Add(this->button2);
			this->panelMenu->Controls->Add(this->button1);
			this->panelMenu->Controls->Add(this->label3);
			this->panelMenu->Controls->Add(this->label2);
			this->panelMenu->Controls->Add(this->label1);
			this->panelMenu->Controls->Add(this->pictureBox1);
			this->panelMenu->Dock = System::Windows::Forms::DockStyle::Right;
			this->panelMenu->Location = System::Drawing::Point(66, 0);
			this->panelMenu->Name = L"panelMenu";
			this->panelMenu->Size = System::Drawing::Size(878, 611);
			this->panelMenu->TabIndex = 0;
			this->panelMenu->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &menu::panelMenu_Paint);
			// 
			// pictureBox2
			// 
			this->pictureBox2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(175)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(202)));
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(23, 23);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(232, 51);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::CenterImage;
			this->pictureBox2->TabIndex = 32;
			this->pictureBox2->TabStop = false;
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button4->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button4->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(157)),
				static_cast<System::Int32>(static_cast<System::Byte>(178)), static_cast<System::Int32>(static_cast<System::Byte>(191)));
			this->button4->FlatAppearance->BorderSize = 3;
			this->button4->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F));
			this->button4->ForeColor = System::Drawing::SystemColors::ControlLight;
			this->button4->Location = System::Drawing::Point(605, 111);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(251, 226);
			this->button4->TabIndex = 30;
			this->button4->Text = L"Reportes";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &menu::button4_Click);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button3->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button3->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(157)),
				static_cast<System::Int32>(static_cast<System::Byte>(178)), static_cast<System::Int32>(static_cast<System::Byte>(191)));
			this->button3->FlatAppearance->BorderSize = 3;
			this->button3->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button3->ForeColor = System::Drawing::SystemColors::ControlLight;
			this->button3->Location = System::Drawing::Point(605, 360);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(251, 226);
			this->button3->TabIndex = 29;
			this->button3->Text = L"Modificar";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &menu::button3_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(39)), static_cast<System::Int32>(static_cast<System::Byte>(55)),
				static_cast<System::Int32>(static_cast<System::Byte>(77)));
			this->button2->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button2->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(157)),
				static_cast<System::Int32>(static_cast<System::Byte>(178)), static_cast<System::Int32>(static_cast<System::Byte>(191)));
			this->button2->FlatAppearance->BorderSize = 3;
			this->button2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F));
			this->button2->ForeColor = System::Drawing::SystemColors::ControlLight;
			this->button2->Location = System::Drawing::Point(23, 360);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(545, 226);
			this->button2->TabIndex = 28;
			this->button2->Text = L"Eliminar";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &menu::button2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(48, 32);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(0, 13);
			this->label3->TabIndex = 9;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(32, 23);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(0, 13);
			this->label2->TabIndex = 8;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(17, 13);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(0, 13);
			this->label1->TabIndex = 7;
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(175)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(202)));
			this->pictureBox1->Location = System::Drawing::Point(0, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(880, 95);
			this->pictureBox1->TabIndex = 20;
			this->pictureBox1->TabStop = false;
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->panel2->Controls->Add(this->button11);
			this->panel2->Controls->Add(this->button10);
			this->panel2->Controls->Add(this->button9);
			this->panel2->Controls->Add(this->button8);
			this->panel2->Controls->Add(this->button7);
			this->panel2->Dock = System::Windows::Forms::DockStyle::Left;
			this->panel2->Location = System::Drawing::Point(0, 0);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(67, 611);
			this->panel2->TabIndex = 1;
			// 
			// button11
			// 
			this->button11->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->button11->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button11->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button11->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button11->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button11.Image")));
			this->button11->Location = System::Drawing::Point(0, 273);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(67, 46);
			this->button11->TabIndex = 4;
			this->button11->UseVisualStyleBackColor = true;
			this->button11->Click += gcnew System::EventHandler(this, &menu::button11_Click);
			// 
			// button10
			// 
			this->button10->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->button10->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button10->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button10->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button10->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button10.Image")));
			this->button10->Location = System::Drawing::Point(0, 209);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(67, 46);
			this->button10->TabIndex = 3;
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &menu::button10_Click);
			// 
			// button9
			// 
			this->button9->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->button9->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button9->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button9->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button9->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button9.Image")));
			this->button9->Location = System::Drawing::Point(0, 145);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(67, 46);
			this->button9->TabIndex = 2;
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &menu::button9_Click);
			// 
			// button8
			// 
			this->button8->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->button8->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button8->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button8->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button8->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button8.Image")));
			this->button8->Location = System::Drawing::Point(0, 81);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(67, 46);
			this->button8->TabIndex = 1;
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &menu::button8_Click);
			// 
			// button7
			// 
			this->button7->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->button7->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button7->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button7->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button7->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button7.Image")));
			this->button7->Location = System::Drawing::Point(0, 17);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(67, 46);
			this->button7->TabIndex = 0;
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &menu::button7_Click);
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(39)), static_cast<System::Int32>(static_cast<System::Byte>(55)),
				static_cast<System::Int32>(static_cast<System::Byte>(77)));
			this->button1->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button1->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(157)),
				static_cast<System::Int32>(static_cast<System::Byte>(178)), static_cast<System::Int32>(static_cast<System::Byte>(191)));
			this->button1->FlatAppearance->BorderSize = 3;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F));
			this->button1->ForeColor = System::Drawing::SystemColors::ControlLight;
			this->button1->Location = System::Drawing::Point(23, 111);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(545, 226);
			this->button1->TabIndex = 27;
			this->button1->Text = L"Insertar";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &menu::button1_Click_1);
			// 
			// menu
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(944, 611);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->panelMenu);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::None;
			this->Name = L"menu";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"menu";
			this->panelMenu->ResumeLayout(false);
			this->panelMenu->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->panel2->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion

		template<class T>
		void AbrirPanel(T^ FormHijo)
		{
			// Si hay controles en el panel, eliminamos el primero
			if (this->panelMenu->Controls->Count > 0) {
				// Ocultamos el formulario actual antes de eliminarlo
				auto currentForm = dynamic_cast<Form^>(this->panelMenu->Controls[0]);
				if (currentForm != nullptr) {
					currentForm->Hide(); // Oculta el formulario actual
				}
				this->panelMenu->Controls->RemoveAt(0); // Elimina el formulario actual
			}

			// Configuramos el nuevo formulario
			FormHijo->TopLevel = false; // Permitimos que sea un control hijo
			FormHijo->Dock = DockStyle::Fill; // Lo hacemos llenar el panel
			this->panelMenu->Controls->Add(FormHijo); // A�adimos el nuevo formulario
			this->panelMenu->Tag = FormHijo; // Opcional: guardar referencia al formulario
			FormHijo->Show(); // Mostramos el nuevo formulario
			FormHijo->BringToFront(); // Aseg�rate de que est� al frente
		}

private: System::Void button1_Click_1(System::Object^ sender, System::EventArgs^ e) {
	if (tipo==1)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::Insertar(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros); // Aseg�rate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}
	else if (tipo==2)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::InsertarAg(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros); // Aseg�rate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}

	button1->Enabled = true;
}

private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Close();
}

private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	if (tipo == 1)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::Modificar(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, snum);  // Aseg�rate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}
	else if (tipo == 2)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::ModificarAg(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros);  // Aseg�rate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}

	button3->Enabled = true;
}

private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	if (tipo==1)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::Eliminar(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros);  // Aseg�rate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}
	else if (tipo==2)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::EliminarAg(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros);  // Aseg�rate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}

	button2->Enabled = true;
}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	if (tipo==1)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::Reportes(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, resHotel, resAgencia, resTodoIncluido);  // Aseg�rate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}
	else if (tipo==2)
	{
		auto nuevoMenu = gcnew Proyecto_3_ED::ReportesAg(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, resHotel, resAgencia, resTodoIncluido);  // Aseg�rate de que Insertar sea el formulario correcto
		this->AbrirPanel(nuevoMenu);
	}
	

	// Habilitar el bot�n de nuevo (puedes hacer esto despu�s de que el panel se haya mostrado)
	button4->Enabled = true;
}
private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e) {
	auto nuevoMenu = gcnew Proyecto_3_ED::Mantenimiento(tipo, persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros,snum, clientes, resHotel, resAgencia, resTodoIncluido);  // Aseg�rate de que Insertar sea el formulario correcto

	// Llama a AbrirPanel con la nueva instancia
	this->AbrirPanel(nuevoMenu);

	// Habilitar el bot�n de nuevo (puedes hacer esto despu�s de que el panel se haya mostrado)
	button4->Enabled = true;
}
private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {
	auto nuevoMenu = gcnew Proyecto_3_ED::Consultas(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, clientes);   // Aseg�rate de que Insertar sea el formulario correcto

	// Llama a AbrirPanel con la nueva instancia
	this->AbrirPanel(nuevoMenu);

	// Habilitar el bot�n de nuevo (puedes hacer esto despu�s de que el panel se haya mostrado)
	button4->Enabled = true;
}
private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e) {
	auto nuevoMenu = gcnew Proyecto_3_ED::Consultas(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, clientes);   // Aseg�rate de que Insertar sea el formulario correcto

	// Llama a AbrirPanel con la nueva instancia
	this->AbrirPanel(nuevoMenu);

	// Habilitar el bot�n de nuevo (puedes hacer esto despu�s de que el panel se haya mostrado)
	button4->Enabled = true;
}
private: System::Void button9_Click(System::Object^ sender, System::EventArgs^ e) {
	auto nuevoMenu = gcnew Proyecto_3_ED::Facturacion(resHotel, resAgencia, resTodoIncluido);  // Aseg�rate de que Insertar sea el formulario correcto

	// Llama a AbrirPanel con la nueva instancia
	this->AbrirPanel(nuevoMenu);

	// Habilitar el bot�n de nuevo (puedes hacer esto despu�s de que el panel se haya mostrado)
	button4->Enabled = true;
}
private: System::Void pictureBox2_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void panelMenu_Paint(System::Object^ sender, System::Windows::Forms::PaintEventArgs^ e) {
}
private: System::Void button10_Click(System::Object^ sender, System::EventArgs^ e) {
	auto nuevoMenu = gcnew Proyecto_3_ED::AcercaDe();  

	this->AbrirPanel(nuevoMenu);
	button4->Enabled = true;
}
private: System::Void button11_Click(System::Object^ sender, System::EventArgs^ e) {
	auto nuevoMenu = gcnew Proyecto_3_ED::Contactos();

	this->AbrirPanel(nuevoMenu);
	button4->Enabled = true;
}
};
}
