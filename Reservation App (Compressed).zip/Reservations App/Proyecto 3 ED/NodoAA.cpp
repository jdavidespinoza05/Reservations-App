#include "pch.h"
#include "NodoAA.h"


    NodoAA::NodoAA(int val, String^ nom) {
        valor = val;
        nombre = nom;
        izquierda = nullptr; // Usa nullptr en lugar de NULL
        derecha = nullptr;
        nivel = 1;
    }

