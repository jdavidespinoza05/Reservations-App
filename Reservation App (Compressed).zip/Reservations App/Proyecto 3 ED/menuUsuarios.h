﻿#pragma once
#include "Comun.h"
#include "Reservaciones.h"
#include "consultasUsuarios.h"
#include "pagosUsuarios.h"

namespace Proyecto_3_ED {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Collections::Generic;
	using namespace System::IO;

	/// <summary>
	/// Resumen de menuUsuarios
	/// </summary>
	public ref class menuUsuarios : public System::Windows::Forms::Form
	{
	private:
		Persona^ persona;
		ArbolBinario^ paises;
		ArbolBinario^ hoteles;
		ArbolBinario^ pisos;
		ArbolBinario^ habitaciones;
		ArbolBinario^ agencias;
		ArbolBinario^ flotillas;
		ArbolBinario^ carros;
		List<String^>^ images;  // Lista de rutas de imágenes
		listaSimple^ resHotel;
		listaSimple^ resAgencia;
		listaSimple^ resTodoIncluido;
		String^ cliente;

	private: System::Windows::Forms::PictureBox^ pictureBox3;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label4;



		   int currentIndex;


	public:
		menuUsuarios(Persona^ p, ArbolBinario^ pais, ArbolBinario^ hotel, ArbolBinario^ piso, ArbolBinario^ hab,
			ArbolBinario^ ag, ArbolBinario^ fl, ArbolBinario^ car, listaSimple^ resH, listaSimple^ resA, listaSimple^ resT, String^ client)
		{
			persona = p;
			paises = pais;
			hoteles = hotel;
			pisos = piso;
			habitaciones = hab;
			agencias = ag;
			flotillas = fl;
			carros = car;
			resHotel = resH;
			resAgencia = resA;
			resTodoIncluido = resT;
			cliente = client;

			InitializeComponent();
			
			images = gcnew List<String^>();
			images->Add("Images/imagen1.jpg");
			images->Add("Images/imagen2.jpg");
			images->Add("Images/imagen3.jpg");
			images->Add("Images/imagen4.jpg");
			images->Add("Images/imagen5.jpg");

			currentIndex = 0;  // Empezamos en la primera imagen

			// Cargar la primera imagen
			String^ testPath = Path::Combine(Application::StartupPath, "Images\\imagen1.jpg");
			imagenesVarias->Image = Image::FromFile(testPath);
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se estén usando.
		/// </summary>
		~menuUsuarios()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panel2;
	protected:


	private: System::Windows::Forms::Button^ button9;
	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Button^ button7;
	private: System::Windows::Forms::Panel^ panelMenu;
	private: System::Windows::Forms::PictureBox^ pictureBox2;

	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button2;

	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::PictureBox^ imagenesVarias;

	private: System::Windows::Forms::Button^ Izq;
	private: System::Windows::Forms::Button^ Der;

	private:
		/// <summary>
		/// Variable del diseñador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Método necesario para admitir el Diseñador. No se puede modificar
		/// el contenido de este método con el editor de código.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(menuUsuarios::typeid));
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->panelMenu = (gcnew System::Windows::Forms::Panel());
			this->pictureBox3 = (gcnew System::Windows::Forms::PictureBox());
			this->Izq = (gcnew System::Windows::Forms::Button());
			this->Der = (gcnew System::Windows::Forms::Button());
			this->imagenesVarias = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->panel2->SuspendLayout();
			this->panelMenu->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->imagenesVarias))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->panel2->Controls->Add(this->button9);
			this->panel2->Controls->Add(this->button8);
			this->panel2->Controls->Add(this->button7);
			this->panel2->Dock = System::Windows::Forms::DockStyle::Left;
			this->panel2->Location = System::Drawing::Point(0, 0);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(67, 611);
			this->panel2->TabIndex = 2;
			// 
			// button9
			// 
			this->button9->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->button9->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button9->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button9->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button9->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button9.Image")));
			this->button9->Location = System::Drawing::Point(0, 145);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(67, 46);
			this->button9->TabIndex = 2;
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &menuUsuarios::button9_Click);
			// 
			// button8
			// 
			this->button8->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->button8->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button8->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button8->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button8->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button8.Image")));
			this->button8->Location = System::Drawing::Point(0, 81);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(67, 46);
			this->button8->TabIndex = 1;
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &menuUsuarios::button8_Click);
			// 
			// button7
			// 
			this->button7->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->button7->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button7->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button7->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button7->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"button7.Image")));
			this->button7->Location = System::Drawing::Point(0, 17);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(67, 46);
			this->button7->TabIndex = 0;
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &menuUsuarios::button7_Click);
			// 
			// panelMenu
			// 
			this->panelMenu->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(221)), static_cast<System::Int32>(static_cast<System::Byte>(230)),
				static_cast<System::Int32>(static_cast<System::Byte>(237)));
			this->panelMenu->Controls->Add(this->label5);
			this->panelMenu->Controls->Add(this->label4);
			this->panelMenu->Controls->Add(this->pictureBox3);
			this->panelMenu->Controls->Add(this->Izq);
			this->panelMenu->Controls->Add(this->Der);
			this->panelMenu->Controls->Add(this->imagenesVarias);
			this->panelMenu->Controls->Add(this->pictureBox2);
			this->panelMenu->Controls->Add(this->button4);
			this->panelMenu->Controls->Add(this->button3);
			this->panelMenu->Controls->Add(this->button2);
			this->panelMenu->Controls->Add(this->label3);
			this->panelMenu->Controls->Add(this->label2);
			this->panelMenu->Controls->Add(this->label1);
			this->panelMenu->Controls->Add(this->pictureBox1);
			this->panelMenu->Dock = System::Windows::Forms::DockStyle::Right;
			this->panelMenu->Location = System::Drawing::Point(66, 0);
			this->panelMenu->Name = L"panelMenu";
			this->panelMenu->Size = System::Drawing::Size(878, 611);
			this->panelMenu->TabIndex = 3;
			// 
			// pictureBox3
			// 
			this->pictureBox3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(175)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(202)));
			this->pictureBox3->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->pictureBox3->Location = System::Drawing::Point(51, 167);
			this->pictureBox3->Name = L"pictureBox3";
			this->pictureBox3->Size = System::Drawing::Size(575, 54);
			this->pictureBox3->TabIndex = 36;
			this->pictureBox3->TabStop = false;
			// 
			// Izq
			// 
			this->Izq->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"Izq.BackgroundImage")));
			this->Izq->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->Izq->FlatAppearance->BorderSize = 0;
			this->Izq->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Izq->Location = System::Drawing::Point(8, 377);
			this->Izq->Name = L"Izq";
			this->Izq->Size = System::Drawing::Size(37, 37);
			this->Izq->TabIndex = 35;
			this->Izq->UseVisualStyleBackColor = true;
			this->Izq->Click += gcnew System::EventHandler(this, &menuUsuarios::Izq_Click);
			// 
			// Der
			// 
			this->Der->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"Der.BackgroundImage")));
			this->Der->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->Der->FlatAppearance->BorderSize = 0;
			this->Der->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Der->Location = System::Drawing::Point(632, 377);
			this->Der->Name = L"Der";
			this->Der->Size = System::Drawing::Size(37, 37);
			this->Der->TabIndex = 34;
			this->Der->UseVisualStyleBackColor = true;
			this->Der->Click += gcnew System::EventHandler(this, &menuUsuarios::Der_Click);
			// 
			// imagenesVarias
			// 
			this->imagenesVarias->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->imagenesVarias->Location = System::Drawing::Point(51, 262);
			this->imagenesVarias->Name = L"imagenesVarias";
			this->imagenesVarias->Size = System::Drawing::Size(575, 270);
			this->imagenesVarias->SizeMode = System::Windows::Forms::PictureBoxSizeMode::CenterImage;
			this->imagenesVarias->TabIndex = 33;
			this->imagenesVarias->TabStop = false;
			// 
			// pictureBox2
			// 
			this->pictureBox2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(175)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(202)));
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(23, 23);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(232, 51);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::CenterImage;
			this->pictureBox2->TabIndex = 32;
			this->pictureBox2->TabStop = false;
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button4->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button4->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(157)),
				static_cast<System::Int32>(static_cast<System::Byte>(178)), static_cast<System::Int32>(static_cast<System::Byte>(191)));
			this->button4->FlatAppearance->BorderSize = 3;
			this->button4->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F));
			this->button4->ForeColor = System::Drawing::SystemColors::ControlLight;
			this->button4->Location = System::Drawing::Point(689, 433);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(177, 150);
			this->button4->TabIndex = 30;
			this->button4->Text = L"Pagos";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &menuUsuarios::button4_Click);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button3->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button3->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(157)),
				static_cast<System::Int32>(static_cast<System::Byte>(178)), static_cast<System::Int32>(static_cast<System::Byte>(191)));
			this->button3->FlatAppearance->BorderSize = 3;
			this->button3->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button3->ForeColor = System::Drawing::SystemColors::ControlLight;
			this->button3->Location = System::Drawing::Point(689, 121);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(177, 150);
			this->button3->TabIndex = 29;
			this->button3->Text = L"Consultas";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &menuUsuarios::button3_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->button2->Cursor = System::Windows::Forms::Cursors::Hand;
			this->button2->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(157)),
				static_cast<System::Int32>(static_cast<System::Byte>(178)), static_cast<System::Int32>(static_cast<System::Byte>(191)));
			this->button2->FlatAppearance->BorderSize = 3;
			this->button2->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F));
			this->button2->ForeColor = System::Drawing::SystemColors::ControlLight;
			this->button2->Location = System::Drawing::Point(689, 277);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(177, 150);
			this->button2->TabIndex = 28;
			this->button2->Text = L"Reservaciones";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &menuUsuarios::button2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(48, 32);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(0, 13);
			this->label3->TabIndex = 9;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(32, 23);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(0, 13);
			this->label2->TabIndex = 8;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(17, 13);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(0, 13);
			this->label1->TabIndex = 7;
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(175)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(202)));
			this->pictureBox1->Location = System::Drawing::Point(0, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(880, 95);
			this->pictureBox1->TabIndex = 20;
			this->pictureBox1->TabStop = false;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(175)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(202)));
			this->label4->Font = (gcnew System::Drawing::Font(L"Century Gothic", 21.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(82)), static_cast<System::Int32>(static_cast<System::Byte>(109)),
				static_cast<System::Int32>(static_cast<System::Byte>(130)));
			this->label4->Location = System::Drawing::Point(115, 175);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(443, 36);
			this->label4->TabIndex = 37;
			this->label4->Text = L"Reservaciones Hoteles y Autos";
			this->label4->Click += gcnew System::EventHandler(this, &menuUsuarios::label4_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(214, 559);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(0, 13);
			this->label5->TabIndex = 38;
			// 
			// menuUsuarios
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(944, 611);
			this->Controls->Add(this->panelMenu);
			this->Controls->Add(this->panel2);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->Name = L"menuUsuarios";
			this->Text = L"menuUsuarios";
			this->panel2->ResumeLayout(false);
			this->panelMenu->ResumeLayout(false);
			this->panelMenu->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->imagenesVarias))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
		template<class T>
		void AbrirPanel(T^ FormHijo)
		{
			// Si hay controles en el panel, ocultamos el primero sin eliminarlo
			if (this->panelMenu->Controls->Count > 0) {
				auto currentForm = dynamic_cast<Form^>(this->panelMenu->Controls[0]);
				if (currentForm != nullptr) {
					currentForm->Hide(); // Oculta el formulario actual
				}
			}

			// Configuramos el nuevo formulario
			FormHijo->TopLevel = false; // Permitimos que sea un control hijo
			FormHijo->Dock = DockStyle::Fill; // Lo hacemos llenar el panel
			this->panelMenu->Controls->Add(FormHijo); // Añadimos el nuevo formulario
			this->panelMenu->Tag = FormHijo; // Opcional: guardar referencia al formulario
			FormHijo->Show(); // Mostramos el nuevo formulario
			FormHijo->BringToFront(); // Asegúrate de que está al frente
		}

	private: System::Void Izq_Click(System::Object^ sender, System::EventArgs^ e) {
		currentIndex = (currentIndex - 1 + images->Count) % images->Count;
		String^ absolutePath = Path::Combine(Application::StartupPath, images[currentIndex]);

		if (File::Exists(absolutePath)) {
			imagenesVarias->Image = Image::FromFile(absolutePath);
		}
		else {
			MessageBox::Show("La imagen no se encontró: " + absolutePath, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}

	}
private: System::Void Der_Click(System::Object^ sender, System::EventArgs^ e) {
	currentIndex = (currentIndex + 1) % images->Count;
	String^ absolutePath = Path::Combine(Application::StartupPath, images[currentIndex]);

	if (File::Exists(absolutePath)) {
		imagenesVarias->Image = Image::FromFile(absolutePath);
	}
	else {
		MessageBox::Show("La imagen no se encontró: " + absolutePath, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}

}
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	auto nuevoMenu = gcnew Proyecto_3_ED::consultasUsuarios(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros);   // Aseg�rate de que Insertar sea el formulario correcto

	// Llama a AbrirPanel con la nueva instancia
	this->AbrirPanel(nuevoMenu);

	// Habilitar el bot�n de nuevo (puedes hacer esto despu�s de que el panel se haya mostrado)
	button4->Enabled = true;
}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {

	auto nuevoMenu = gcnew Proyecto_3_ED::Reservaciones(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, resHotel, resAgencia, resTodoIncluido, cliente);   // Aseg�rate de que Insertar sea el formulario correcto

	// Llama a AbrirPanel con la nueva instancia
	this->AbrirPanel(nuevoMenu);

	// Habilitar el bot�n de nuevo (puedes hacer esto despu�s de que el panel se haya mostrado)
	button4->Enabled = true;
}
private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e) {
	auto nuevoMenu = gcnew Proyecto_3_ED::Reservaciones(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, resHotel, resAgencia, resTodoIncluido, cliente);   // Aseg�rate de que Insertar sea el formulario correcto

	// Llama a AbrirPanel con la nueva instancia
	this->AbrirPanel(nuevoMenu);

	// Habilitar el bot�n de nuevo (puedes hacer esto despu�s de que el panel se haya mostrado)
	button4->Enabled = true;
}
private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e) {
	auto nuevoMenu = gcnew Proyecto_3_ED::consultasUsuarios(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros);   // Aseg�rate de que Insertar sea el formulario correcto

	// Llama a AbrirPanel con la nueva instancia
	this->AbrirPanel(nuevoMenu);

	// Habilitar el bot�n de nuevo (puedes hacer esto despu�s de que el panel se haya mostrado)
	button4->Enabled = true;
}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	auto nuevoMenu = gcnew Proyecto_3_ED::pagosUsuarios(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, resHotel, resAgencia, resTodoIncluido, cliente);   // Aseg�rate de que Insertar sea el formulario correcto

	// Llama a AbrirPanel con la nueva instancia
	this->AbrirPanel(nuevoMenu);

	// Habilitar el bot�n de nuevo (puedes hacer esto despu�s de que el panel se haya mostrado)
	button4->Enabled = true;
}
private: System::Void button9_Click(System::Object^ sender, System::EventArgs^ e) {
	auto nuevoMenu = gcnew Proyecto_3_ED::pagosUsuarios(persona, paises, hoteles, pisos, habitaciones, agencias, flotillas, carros, resHotel, resAgencia, resTodoIncluido, cliente);   // Aseg�rate de que Insertar sea el formulario correcto

	// Llama a AbrirPanel con la nueva instancia
	this->AbrirPanel(nuevoMenu);

	// Habilitar el bot�n de nuevo (puedes hacer esto despu�s de que el panel se haya mostrado)
	button4->Enabled = true;
}
private: System::Void label4_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Visible = true;
	this->Text = "Reservaciones Hoteles y Autos";
}
};
}
