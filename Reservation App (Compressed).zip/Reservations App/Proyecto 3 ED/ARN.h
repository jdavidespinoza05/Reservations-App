#pragma once

#include "NodoARN.h"
#include "ArbolAA.h"
#include "ABB.h"
#include "ArbolAVL.h"

class ArbolRojoNegro {
private:
    NodoRB* raiz;
    NodoRB* TNULL;
    NodoRB* ultimoInsertado;

    void inicializarNNULL();
    void inOrdenHelperH(NodoRB* nodo);
    void inOrdenHelperC(NodoRB* nodo);
    void balancearInsercion(NodoRB* nodo);
    void rotarIzquierda(NodoRB* x);
    void rotarDerecha(NodoRB* x);
    void balancearBorrado(NodoRB* nodo);
    void borrarNodo(NodoRB* nodo, int valor);
    void transplantar(NodoRB* u, NodoRB* v);
    NodoRB* encontrarMinimo(NodoRB* nodo);
    NodoRB* buscar(NodoRB* nodo, int valor);

public:
    ArbolRojoNegro();
    void insertar(int valor, string codPais, string codHotel, string numPiso, string tipoCuarto, string numCamas, string precioHab, string estadoHab);
    void insertar(int valor, string codPais, string codHotel, string numPiso, string tipoCuarto, string numCamas, string anho, string precioHab, string estadoHab);
    void borrar(int valor);
    NodoRB* obtenerUltimoInsertado();
    bool buscar(int clave);
    void inOrdenH();
    void inOrdenC();

    void leerHabitacion(const string& nombreArchivo);
    void leerCarros(const string& nombreArchivo);
    /*
    void insertarHabitacion(ArbolAA& paises, ABB& hoteles, ArbolAVL& pisos);
    void insertarCarro(ArbolAA& paises, ABB& agencias, ArbolAVL& flotillas);

    void modificarHabitacion(ArbolAA& paises, ABB& hoteles, ArbolAVL& pisos);
    void modificarCarro(ArbolAA& paises, ABB& agencias, ArbolAVL& flotillas);
    */
    bool buscarCodH(NodoRB* nodo, int clave, int cod);
    bool buscarCodH(NodoRB* nodo, const string& codHotel);
    bool buscarHotel(NodoRB* nodo, const string& codHotel);
    bool buscarPiso(NodoRB* nodo, const string& numPiso);
    NodoRB* buscarCarro(NodoRB* nodo, int valor);
    void consultarHab();
    void consultarCarrosT();
    void ultimo();
    void ultimoC();
    void cantidadAsientos();
    void cantidadAsientosAux(NodoRB* nodo, string placa);
    NodoRB* buscarHab(NodoRB* nodo, const string& codHotel, int numPiso);
    bool buscarPais(NodoRB* nodo, const string& numPiso);
};